import httpx
import pytest

from openmcp_sdk.context import current_context
from openmcp_sdk.envelope import ConnectorError, ErrorCode
from openmcp_sdk.identity.gateway import GatewayIdentity
from openmcp_sdk.manifest import Manifest
from openmcp_sdk.secrets.base import Resolved
from openmcp_sdk.transport.http import build_http_app

_INTERNAL_TOKEN = "t" * 32
_PUBLIC_SAFE_TEST_TOKEN = "p" * 32


def _apply_middlewares(app, middleware):
    for item in reversed(middleware or []):
        app = item.cls(app, *item.args, **item.kwargs)
    return app


class FakeCreds:
    def resolve(self, principal):
        return Resolved({}, {})

    def invalidate(self, sub):
        pass


class VersionedFakeCreds(FakeCreds):
    def __init__(self):
        self.versions = []

    def resolve(self, principal):
        self.versions.append(principal.credential_version)
        if principal.credential_version is None:
            raise ConnectorError(ErrorCode.FORBIDDEN, "missing exact version")
        return Resolved({"api_key": "k"}, {"instance": "demo"})


class FakeMCP:
    auth = None

    def http_app(self, path, middleware=None, stateless_http=None):
        assert stateless_http is True

        async def app(scope, receive, send):
            status = 200 if scope["path"].rstrip("/") == path.rstrip("/") else 404
            await send({"type": "http.response.start", "status": status, "headers": []})
            await send({"type": "http.response.body", "body": b""})

        return _apply_middlewares(app, middleware)


def _manifest():
    return Manifest.model_validate(
        {
            "slug": "raynet",
            "name": "RAYNET",
            "version": "1.0.0",
            "credentials": [
                {"key": "api_key", "secret": True, "required": True},
                {"key": "instance", "required": True},
            ],
            "user_config": [
                {
                    "key": "region",
                    "type": "enum",
                    "choices": ["cz", "sk"],
                    "default": "cz",
                }
            ],
            "operator_config": [{"key": "read_only", "type": "bool", "default": True}],
            "capabilities": {"supports_test": True},
        }
    )


def _build(callback):
    return build_http_app(
        FakeMCP(),
        GatewayIdentity(_INTERNAL_TOKEN),
        FakeCreds(),
        allowed_origins=["https://claude.ai"],
        test_connection=callback,
        manifest=_manifest(),
        test_auth_token=_INTERNAL_TOKEN,
        operator_env={"RAYNET_READ_ONLY": "true"},
    )


def _headers(token=_INTERNAL_TOKEN):
    return {"X-OpenMCP-Test-Token": token}


def _body():
    return {
        "secrets": {"api_key": "k"},
        "config": {"instance": "demo", "region": "sk"},
    }


@pytest.mark.anyio
async def test_test_endpoint_success_with_typed_immutable_context():
    def callback():
        ctx = current_context()
        assert ctx.config["read_only"] is True
        assert ctx.config["region"] == "sk"
        return f"OK {ctx.config['instance']}"

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(_build(callback)), base_url="http://test"
    ) as client:
        response = await client.post("/test", headers=_headers(), json=_body())
    assert response.status_code == 200
    assert response.json() == {"ok": True, "message": "OK demo"}


@pytest.mark.anyio
async def test_test_endpoint_supports_async_callback():
    async def callback():
        return f"OK {current_context().config['instance']}"

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(_build(callback)), base_url="http://test"
    ) as client:
        response = await client.post("/test", headers=_headers(), json=_body())
    assert response.json()["ok"] is True


@pytest.mark.anyio
async def test_test_endpoint_requires_internal_token():
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(_build(lambda: "ok")), base_url="http://test"
    ) as client:
        missing = await client.post("/test", json=_body())
        wrong = await client.post("/test", headers=_headers("x" * 32), json=_body())
    assert missing.status_code == wrong.status_code == 403


@pytest.mark.anyio
async def test_test_endpoint_validates_required_fields_and_secret_placement():
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(_build(lambda: "ok")), base_url="http://test"
    ) as client:
        missing = await client.post(
            "/test",
            headers=_headers(),
            json={"secrets": {}, "config": {"instance": "demo"}},
        )
        misplaced = await client.post(
            "/test",
            headers=_headers(),
            json={"secrets": {}, "config": {"api_key": "k", "instance": "demo"}},
        )
    assert missing.status_code == misplaced.status_code == 400


@pytest.mark.anyio
async def test_connector_error_is_structured_but_unexpected_error_is_generic():
    def known_failure():
        raise ConnectorError(ErrorCode.INVALID_INPUT, "špatný klíč")

    def unknown_failure():
        raise RuntimeError("password=must-not-leak")

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(_build(known_failure)), base_url="http://test"
    ) as client:
        known = await client.post("/test", headers=_headers(), json=_body())
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(_build(unknown_failure)), base_url="http://test"
    ) as client:
        unknown = await client.post("/test", headers=_headers(), json=_body())
    assert known.json() == {"ok": False, "code": "invalid_input", "message": "špatný klíč"}
    assert unknown.status_code == 500
    assert "must-not-leak" not in unknown.text


@pytest.mark.anyio
async def test_unsupported_test_endpoint_is_not_mounted():
    app = build_http_app(
        FakeMCP(),
        GatewayIdentity(_INTERNAL_TOKEN),
        FakeCreds(),
        allowed_origins=["https://claude.ai"],
    )
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app), base_url="http://test"
    ) as client:
        response = await client.post("/test", headers=_headers(), json={})
    assert response.status_code == 404


@pytest.mark.anyio
async def test_exact_credential_test_uses_trusted_explicit_version_without_body():
    creds = VersionedFakeCreds()

    def callback():
        assert current_context().principal.credential_version == 23
        return "provider read test passed"

    app = build_http_app(
        FakeMCP(),
        GatewayIdentity(_INTERNAL_TOKEN),
        creds,
        allowed_origins=["https://claude.ai"],
        test_connection=callback,
        manifest=_manifest(),
        test_auth_token=_INTERNAL_TOKEN,
        credential_version_test=True,
    )
    headers = {
        "X-OpenMCP-Test-Token": _INTERNAL_TOKEN,
        "X-OpenMCP-Gateway-Token": _INTERNAL_TOKEN,
        "X-OpenMCP-Sub": "00000000-0000-0000-0000-000000000001",
        "X-OpenMCP-Credential-Version": "23",
        "X-OpenMCP-Credential-Owner-Kind": "user",
        "X-OpenMCP-Credential-Owner-Id": "00000000-0000-0000-0000-000000000001",
    }
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app), base_url="http://test"
    ) as client:
        response = await client.post("/internal/credential-test", headers=headers)
    assert response.status_code == 200
    assert response.json() == {"ok": True, "message": "provider read test passed"}
    assert creds.versions == [23]

    # Hosted mode exposes only the exact Vault-version test. The legacy route
    # accepted raw secrets in a JSON body and must not coexist with it.
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app), base_url="http://test"
    ) as client:
        legacy = await client.post("/test", headers=headers, json={"secrets": {}})
    assert legacy.status_code == 404


@pytest.mark.anyio
async def test_exact_credential_test_fails_closed_without_version_or_gateway_proof():
    app = build_http_app(
        FakeMCP(),
        GatewayIdentity(_INTERNAL_TOKEN),
        VersionedFakeCreds(),
        allowed_origins=[],
        manifest=_manifest(),
        test_auth_token=_INTERNAL_TOKEN,
        credential_version_test=True,
    )
    base = {
        "X-OpenMCP-Test-Token": _INTERNAL_TOKEN,
        "X-OpenMCP-Gateway-Token": _INTERNAL_TOKEN,
        "X-OpenMCP-Sub": "00000000-0000-0000-0000-000000000001",
    }
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app), base_url="http://test"
    ) as client:
        missing_version = await client.post("/internal/credential-test", headers=base)
        forged = await client.post(
            "/internal/credential-test",
            headers={
                **base,
                "X-OpenMCP-Gateway-Token": "x" * 32,
                "X-OpenMCP-Credential-Version": "1",
            },
        )
    assert missing_version.status_code == forged.status_code == 403


@pytest.mark.anyio
async def test_exact_credential_test_rejects_body_query_and_duplicate_auth_headers():
    creds = VersionedFakeCreds()
    app = build_http_app(
        FakeMCP(),
        GatewayIdentity(_INTERNAL_TOKEN),
        creds,
        allowed_origins=[],
        manifest=_manifest(),
        test_auth_token=_INTERNAL_TOKEN,
        credential_version_test=True,
    )
    headers = [
        ("X-OpenMCP-Test-Token", _INTERNAL_TOKEN),
        ("X-OpenMCP-Gateway-Token", _INTERNAL_TOKEN),
        ("X-OpenMCP-Sub", "00000000-0000-0000-0000-000000000001"),
        ("X-OpenMCP-Credential-Version", "23"),
        ("X-OpenMCP-Credential-Owner-Kind", "user"),
        ("X-OpenMCP-Credential-Owner-Id", "00000000-0000-0000-0000-000000000001"),
    ]
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app), base_url="http://test"
    ) as client:
        body = await client.post(
            "/internal/credential-test", headers=dict(headers), content=b"ignored"
        )
        query = await client.post(
            "/internal/credential-test?version=23", headers=dict(headers)
        )
        duplicate = await client.post(
            "/internal/credential-test",
            headers=[*headers, ("X-OpenMCP-Credential-Version", "24")],
        )
    assert body.status_code == query.status_code == 400
    assert duplicate.status_code == 403
    assert creds.versions == []


def _build_public_safe_test(callback, token=_PUBLIC_SAFE_TEST_TOKEN):
    return build_http_app(
        FakeMCP(),
        GatewayIdentity(_INTERNAL_TOKEN),
        FakeCreds(),
        allowed_origins=[],
        public_safe_test=callback,
        public_safe_test_token=token,
    )


def _public_safe_headers(token=_PUBLIC_SAFE_TEST_TOKEN):
    return {"X-OpenMCP-Public-Safe-Test-Token": token}


@pytest.mark.anyio
async def test_public_safe_test_has_no_input_or_provider_output():
    calls = 0

    def callback():
        nonlocal calls
        calls += 1
        return {"provider": "payload-must-be-discarded"}

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(_build_public_safe_test(callback)),
        base_url="http://test",
    ) as client:
        response = await client.post(
            "/internal/public-safe-test", headers=_public_safe_headers()
        )
    assert response.status_code == 200
    assert response.json() == {"ok": True, "code": "safe_test_passed"}
    assert "payload-must-be-discarded" not in response.text
    assert calls == 1


@pytest.mark.anyio
async def test_public_safe_test_rejects_missing_or_wrong_dedicated_token():
    calls = 0

    def callback():
        nonlocal calls
        calls += 1

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(_build_public_safe_test(callback)),
        base_url="http://test",
    ) as client:
        missing = await client.post("/internal/public-safe-test")
        wrong = await client.post(
            "/internal/public-safe-test",
            headers=_public_safe_headers("x" * 32),
        )
    assert missing.status_code == wrong.status_code == 403
    assert missing.json() == wrong.json() == {
        "ok": False,
        "code": "safe_test_unavailable",
    }
    assert calls == 0


@pytest.mark.anyio
async def test_public_safe_test_rejects_all_customer_input():
    calls = 0

    def callback():
        nonlocal calls
        calls += 1

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(_build_public_safe_test(callback)),
        base_url="http://test",
    ) as client:
        body = await client.post(
            "/internal/public-safe-test",
            headers=_public_safe_headers(),
            json={"ico": "customer-controlled"},
        )
        query = await client.post(
            "/internal/public-safe-test?ico=customer-controlled",
            headers=_public_safe_headers(),
        )
    assert body.status_code == query.status_code == 400
    assert calls == 0


@pytest.mark.anyio
async def test_public_safe_test_normalizes_failures_without_raw_content(caplog):
    leaked = "provider-payload-must-not-leak"

    def provider_failure():
        raise ConnectorError(ErrorCode.UPSTREAM_ERROR, leaked)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(_build_public_safe_test(provider_failure)),
        base_url="http://test",
    ) as client:
        response = await client.post(
            "/internal/public-safe-test", headers=_public_safe_headers()
        )
    assert response.status_code == 502
    assert response.json() == {"ok": False, "code": "provider_unavailable"}
    assert leaked not in response.text
    assert leaked not in caplog.text


@pytest.mark.anyio
async def test_public_safe_test_hides_instance_and_credential_configuration_details():
    for code in (
        ErrorCode.CREDENTIAL_INVALID,
        ErrorCode.INSTANCE_UNKNOWN,
        ErrorCode.PROVIDER_PERMISSION_DENIED,
    ):
        def configuration_failure(code=code):
            raise ConnectorError(code, "configuration detail must not cross")

        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(
                _build_public_safe_test(configuration_failure)
            ),
            base_url="http://test",
        ) as client:
            response = await client.post(
                "/internal/public-safe-test", headers=_public_safe_headers()
            )
        assert response.json() == {"ok": False, "code": "safe_test_unavailable"}
        assert "configuration detail" not in response.text


def test_public_safe_test_refuses_short_or_missing_token_at_startup():
    for token in (None, "short"):
        with pytest.raises(ValueError, match="public_safe_test_token"):
            _build_public_safe_test(lambda: None, token)
