"""Sdílený HTTP klient pro upstream API konektorů.

Nahrazuje tři téměř identické `client.py` (raynet 196 ř., dotykacka 214,
upgates 144). Z každého bere to, co měl nejlepší:

* **raynet** — zápisy se záměrně neopakují (duplicitní záznam je horší než
  chybová hláška) a retry respektuje ``Retry-After``;
* **dotykacka** — injektovatelný ``transport`` (testy přes ``httpx.MockTransport``
  místo stubování privátního ``_client``), jednorázové obnovení tokenu
  při 401 a percent-encoding segmentů **v klientovi**;
* **upgates** — validace base URL v konstruktoru;
* **ares** — :meth:`UpstreamClient.get_dict`, pojistka na 200 s HTML/polem
  místo objektu.

Dva vědomé rozdíly oproti dnešku:

1. Chyby jsou ``ConnectorError``, ne vlastní typ konektoru. ``ConnectorError``
   nese ``status`` pro strukturovanou klasifikaci (``test_connection``).
2. **Tělo upstream odpovědi se nikdy nedostane do chybové zprávy.** Raynet i
   upgates dnes lepí ``resp.text[:500]`` do zprávy, kterou čte model — to je
   injection kanál. Tělo jde do logu (přes ``logging.redact``), ven jde typová
   hláška.
"""

from __future__ import annotations

import logging
import random
import time
import urllib.parse
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Protocol, Self

import httpx

from openmcp_sdk.context import invalidate_current_credentials
from openmcp_sdk.envelope import ConnectorError, ErrorCode

logger = logging.getLogger(__name__)

DEFAULT_RATE_LIMIT_HEADERS: tuple[str, ...] = (
    "X-Ratelimit-Limit",
    "X-Ratelimit-Remaining",
    "X-Ratelimit-Reset",
)

# Metody, které jsou bezpečně opakovatelné. Všechno ostatní je potenciální zápis.
_IDEMPOTENT_METHODS = frozenset({"GET", "HEAD", "OPTIONS"})


def _invalidate_if_active() -> None:
    try:
        invalidate_current_credentials()
    except ConnectorError:
        # Helper se dá volat i mimo OpenMCP request kontext.
        pass


def raise_for_status(response: httpx.Response) -> None:
    """Namapuj HTTP stav na typovaný :class:`ConnectorError`.

    Zpráva nikdy neobsahuje tělo odpovědi — jen stav. Tělo může obsahovat
    text, který napsal cizí uživatel, a putovalo by rovnou do kontextu
    modelu.
    """
    status = response.status_code
    if 200 <= status < 300:
        return
    if status == 401:
        _invalidate_if_active()
        raise ConnectorError(
            ErrorCode.FORBIDDEN, "upstream odmítl přístupové údaje", status=status
        )
    if status == 403:
        raise ConnectorError(
            ErrorCode.FORBIDDEN, "upstream odmítl přístup", status=status
        )
    if status == 429:
        raise ConnectorError(
            ErrorCode.RATE_LIMITED,
            "upstream odmítl request pro rate limit",
            status=status,
        )
    if status in {404, 410}:
        # Kód zůstává INVALID_INPUT (kontrakt `ErrorCode` nemá `not_found`
        # a platforma ho mapuje na `credential_invalid`), ale zpráva musí
        # říct pravdu: 404 neznamená chybný tvar vstupu. Reálný případ —
        # RAYNET vrací na neexistující instanci `404 Instance not found`,
        # a hláška „upstream odmítl vstup" posílala diagnostiku k argumentům
        # nástroje místo ke konfiguraci připojení. Volající, který umí
        # rozlišit víc, čte `ConnectorError.status`.
        raise ConnectorError(
            ErrorCode.INVALID_INPUT,
            f"upstream nenašel požadovaný zdroj (stav {status})",
            status=status,
        )
    if status == 409:
        raise ConnectorError(
            ErrorCode.INVALID_INPUT,
            "upstream odmítl operaci kvůli konfliktu (stav 409)",
            status=status,
        )
    if status in {400, 422}:
        raise ConnectorError(
            ErrorCode.INVALID_INPUT,
            f"upstream odmítl vstup se stavem {status}",
            status=status,
        )
    if 400 <= status < 500:
        raise ConnectorError(
            ErrorCode.UPSTREAM_ERROR,
            f"upstream odmítl request se stavem {status}",
            status=status,
        )
    raise ConnectorError(
        ErrorCode.UPSTREAM_ERROR, f"upstream selhal se stavem {status}", status=status
    )


def map_http_exc(exc: Exception) -> ConnectorError:
    if isinstance(exc, ConnectorError):
        return exc
    if isinstance(exc, httpx.HTTPStatusError):
        try:
            raise_for_status(exc.response)
        except ConnectorError as mapped:
            return mapped
    if isinstance(exc, httpx.TimeoutException):
        return ConnectorError(ErrorCode.UPSTREAM_UNAVAILABLE, "upstream neodpověděl včas")
    if isinstance(exc, httpx.RequestError):
        return ConnectorError(ErrorCode.UPSTREAM_UNAVAILABLE, "upstream je nedostupný")
    return ConnectorError(ErrorCode.INTERNAL, "neočekávaná interní chyba")


@dataclass(frozen=True, slots=True)
class RetryPolicy:
    """Politika opakování jednoho volání."""

    max_attempts: int = 4
    backoff_base: float = 0.5
    backoff_cap: float = 8.0
    jitter: float = 0.25
    retry_statuses: frozenset[int] = frozenset({429, 500, 502, 503, 504})
    respect_retry_after: bool = True

    def __post_init__(self) -> None:
        if self.max_attempts < 1:
            raise ValueError("max_attempts musí být alespoň 1")

    def sleep_for(self, attempt: int, response: httpx.Response | None) -> float:
        if self.respect_retry_after and response is not None:
            after = response.headers.get("Retry-After", "")
            if after.isdigit():
                return min(float(after), self.backoff_cap)
        delay = min(self.backoff_base * (2 ** (attempt - 1)), self.backoff_cap)
        return delay + random.uniform(0, delay * self.jitter)


#: Výchozí politika pro čtení.
READ_RETRY = RetryPolicy()
#: Zápisy: přesně jeden pokus. Po 5xx nebo timeoutu nevíme, jestli požadavek
#: neprošel, nebo se jen ztratila odpověď — opakování by mohlo založit
#: duplicitní záznam. Duplicita v cizím systému je horší než chybová hláška.
NO_RETRY = RetryPolicy(max_attempts=1)
#: Jen serverové chyby; 429 se neřeší opakováním (dotykacka).
SERVER_ERRORS_ONLY = RetryPolicy(retry_statuses=frozenset({500, 502, 503, 504}))


class TokenProvider(Protocol):
    """Kontrakt runtime OAuth klienta (``current_context().oauth``)."""

    def access_token(self) -> str: ...

    def invalidate(self) -> None: ...


#: Skaláry, které dávají smysl jako identifikátor v cestě. Cokoli jiné
#: (``None``, list, dict) je chyba volajícího, ne hodnota na zakódování.
_SEGMENT_TYPES = (str, int, float)


def encode_segment(value: Any, label: str = "id") -> str:
    """Znormalizuj hodnotu na bezpečný segment cesty.

    Percent-encoding zneškodní ``/``, takže se z parametru nedá vyskočit jinam
    v API. Patří do klienta, ne do ``server.py`` — jinak ochrana závisí na tom,
    jestli si na ni volající vzpomene.

    **Dot-segmenty kódování nezneškodní.** ``.`` a ``..`` jsou v RFC 3986
    „unreserved", takže jejich ``quote()`` nechá být — a httpx je při stavění URL
    normalizuje, takže ``/company/../detail`` skončí jako ``/detail``. Jediná
    obrana je takové segmenty odmítnout; jako identifikátor stejně nikdy nedávají
    smysl.
    """
    if isinstance(value, bool) or not isinstance(value, _SEGMENT_TYPES):
        raise ConnectorError(
            ErrorCode.INVALID_INPUT,
            f"{label} v ceste musí být řetězec nebo číslo",
        )
    text = str(value).strip()
    if not text:
        raise ConnectorError(ErrorCode.INVALID_INPUT, f"prázdné {label} v ceste")
    if not text.strip("."):
        raise ConnectorError(
            ErrorCode.INVALID_INPUT,
            f"{label} v ceste nesmí být dot-segment ({text!r})",
        )
    return urllib.parse.quote(text, safe="")


class UpstreamClient:
    """Synchronní HTTP klient s retry, mapováním chyb a rate-limit telemetrií."""

    def __init__(
        self,
        *,
        base_url: str,
        auth: httpx.Auth | tuple[str, str] | None = None,
        token_provider: TokenProvider | None = None,
        headers: Mapping[str, str] | None = None,
        timeout: float = 30.0,
        connect_timeout: float = 10.0,
        transport: httpx.BaseTransport | None = None,
        retry: RetryPolicy = READ_RETRY,
        rate_limit_headers: Sequence[str] = DEFAULT_RATE_LIMIT_HEADERS,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        # POZOR: `urlsplit` sám ořezává okolní whitespace, httpx ne — bez
        # této kontroly by "  https://host" prošlo a všechny requesty by pak
        # mířily na relativní adresu `%20%20https://host/`.
        if base_url != base_url.strip():
            raise ConnectorError(
                ErrorCode.INVALID_INPUT, "base_url nesmí mít okolní mezery"
            )
        parsed = urllib.parse.urlsplit(base_url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ConnectorError(
                ErrorCode.INVALID_INPUT,
                "base_url musí být absolutní http(s) adresa",
            )
        if parsed.query or parsed.fragment:
            # httpx query z base URL nesloučí — zamotala by se do cesty.
            raise ConnectorError(
                ErrorCode.INVALID_INPUT, "base_url nesmí obsahovat query ani fragment"
            )
        if parsed.username or parsed.password:
            # httpx z userinfo auth neudělá nic, jen ho nechá v každé URL — tedy
            # i v logu. Credentials patří do `auth=`, ne do base URL.
            raise ConnectorError(
                ErrorCode.INVALID_INPUT,
                "base_url nesmí obsahovat přihlašovací údaje — použij auth=",
            )
        self._retry = retry
        self._token_provider = token_provider
        self._rate_limit_headers = tuple(rate_limit_headers)
        # `sleep` je injektovatelný, aby retry testy nemusely reálně čekat.
        self._sleep = sleep
        # `transport` je injektovatelný kvůli testům (httpx.MockTransport);
        # v provozu zůstává None a httpx použije reálný síťový transport.
        self._client = httpx.Client(
            base_url=base_url,
            auth=auth,
            headers={"Accept": "application/json", **dict(headers or {})},
            timeout=httpx.Timeout(timeout, connect=connect_timeout),
            transport=transport,
        )
        #: Poslední viděné rate-limit hlavičky (diagnostika).
        self.rate_limit: dict[str, str] = {}

    # -- lifecycle -------------------------------------------------------------
    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> Self:
        # `Self`, ne `UpstreamClient` — jinak se při `with Client(...) as c`
        # ztratí podtyp a metody konkrétního konektoru zmizí.
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()

    # -- veřejné API -----------------------------------------------------------
    seg = staticmethod(encode_segment)

    def get_json(self, path: str, params: Mapping[str, Any] | None = None) -> Any:
        # Přes `_json()`, ne `.json()` — jinak by při 200 s HTML tělem (chybová
        # stránka z proxy) vyletěla netypovaná `JSONDecodeError` místo
        # `ConnectorError` a její text by šel modelu.
        return self._json(self.request("GET", path, params=params))

    def get_dict(self, path: str, params: Mapping[str, Any] | None = None) -> dict[str, Any]:
        """Jako :meth:`get_json`, ale trvá na tom, že tělo je objekt.

        Upstream může při chybě nebo přes proxy vrátit 200 s polem, skalárem
        nebo rovnou HTML chybovou stránkou. To je ``internal``, ne neošetřený
        ``TypeError`` na ``Model(**payload)``.
        """
        payload = self._json(self.request("GET", path, params=params))
        if not isinstance(payload, dict):
            raise ConnectorError(
                ErrorCode.INTERNAL, "upstream vrátil neočakávaný tvar odpovědi (ne objekt)"
            )
        return payload

    def post_json(
        self, path: str, body: Any, *, retry: RetryPolicy | None = None
    ) -> Any:
        return self._json(self.request("POST", path, json=body, retry=retry))

    def put_json(self, path: str, body: Any, *, retry: RetryPolicy | None = None) -> Any:
        return self._json(self.request("PUT", path, json=body, retry=retry))

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        json: Any = None,
        content: str | bytes | None = None,
        headers: Mapping[str, str] | None = None,
        retry: RetryPolicy | None = None,
        same_origin_redirects: int = 0,
    ) -> httpx.Response:
        """Proveď volání s retry a namapuj selhání na ``ConnectorError``.

        Pokud ``retry`` není zadané, non-GET metody dostanou :data:`NO_RETRY`.
        Neopakování zápisů je výchozí chování SDK, ne věc disciplíny konektoru.

        ``content`` je tělo pro upstreamy s jiným formátem než JSON (např. XML
        obálka ABRA Flexi) — Content-Type si volající nastaví přes ``headers``.
        ``json`` a ``content`` se vzájemně vylučují.

        ``same_origin_redirects`` povolí následovat až N přesměrování, ale
        VÝHRADNĚ v rámci stejného scheme+host+port. Výchozí 0: přesměrování je
        chyba — klient s Basic auth nesmí credentials odnést na cizí origin,
        proto tu není žádné plošné ``follow_redirects``. Jen pro GET.
        """
        if json is not None and content is not None:
            raise ConnectorError(
                ErrorCode.INTERNAL, "request nesmí dostat json i content zároveň"
            )
        upper = method.upper()
        if same_origin_redirects and upper != "GET":
            raise ConnectorError(
                ErrorCode.INTERNAL, "same_origin_redirects je jen pro GET"
            )
        policy = retry if retry is not None else (
            self._retry if upper in _IDEMPOTENT_METHODS else NO_RETRY
        )
        clean: dict[str, Any] | None = {
            k: v for k, v in (params or {}).items() if v is not None
        }
        refreshed = False
        redirects_left = max(0, same_origin_redirects)

        attempt = 0
        while attempt < policy.max_attempts:
            attempt += 1
            request_headers = dict(headers or {})
            if self._token_provider is not None:
                # Selhání OAuth klienta musí ven jako `ConnectorError`. Jinak by
                # se `str(exc)` (např. „refresh token expired for tenant X")
                # dostal přes fastmcp rovnou do kontextu modelu.
                try:
                    token = self._token_provider.access_token()
                except ConnectorError:
                    raise
                except Exception:
                    # Provider exceptions may embed refresh/access tokens or
                    # response data. Never persist their traceback or text.
                    logger.warning("získání access tokenu selhalo")
                    raise ConnectorError(
                        ErrorCode.FORBIDDEN,
                        "nepodařilo se získat přístupový token — zkus konektor "
                        "znovu propojit",
                    ) from None
                request_headers["Authorization"] = f"Bearer {token}"

            try:
                response = self._client.request(
                    upper,
                    path,
                    params=clean,
                    json=json,
                    content=content,
                    headers=request_headers,
                )
            except httpx.RequestError as exc:
                if attempt < policy.max_attempts:
                    self._wait(
                        policy,
                        attempt,
                        None,
                        upper,
                        path,
                        reason=type(exc).__name__,
                    )
                    continue
                raise map_http_exc(exc) from exc

            self._record_rate_limit(response)

            # Same-origin přesměrování (např. FlexiBee 301 z `ext:` ID na
            # kanonickou URL záznamu). Cross-origin Location se NIKDY
            # nenásleduje — spadne níže v `raise_for_status` jako chyba.
            if (
                redirects_left > 0
                and response.status_code in {301, 302, 303, 307, 308}
            ):
                location = response.headers.get("Location", "")
                target = self._same_origin_location(location)
                if target is not None:
                    redirects_left -= 1
                    attempt -= 1  # přesměrování není retry pokus
                    path = target
                    # Query nese cílová URL. Musí být None, ne {} — httpx by
                    # prázdnými params query cílové URL smazal.
                    clean = None
                    continue

            # Vypršelý access token → jednou zahoď cache a zkus znovu. Nepočítá se
            # to jako retry pokus: token mohl vypršet i při prvním volání a
            # zbytečně by to vyčerpalo rozpočet pokusů.
            if (
                response.status_code == 401
                and self._token_provider is not None
                and not refreshed
            ):
                refreshed = True
                attempt -= 1
                try:
                    self._token_provider.invalidate()
                except ConnectorError:
                    raise
                except Exception:
                    logger.warning("invalidace access tokenu selhala")
                    raise ConnectorError(
                        ErrorCode.UPSTREAM_UNAVAILABLE,
                        "nepodařilo se obnovit přístupový token",
                    ) from None
                logger.info("upstream 401 — obnovuji access token a zkouším znovu")
                continue

            if (
                response.status_code in policy.retry_statuses
                and attempt < policy.max_attempts
            ):
                self._wait(
                    policy,
                    attempt,
                    response,
                    upper,
                    path,
                    reason=f"HTTP {response.status_code}",
                )
                continue

            raise_for_status(response)
            return response

        # Nedosažitelné: obě `continue` větve jsou strážené
        # `attempt < policy.max_attempts` a 401-refresh `attempt` dekrementuje,
        # takže smyčka vždy odchází přes `return` nebo `raise` výše.
        # Ověřeno sys.settrace nad maticí stavů a politik. Zůstává jako
        # pojistka proti budoucí úpravě podmínek — ne jako očekávaná cesta.
        raise ConnectorError(  # pragma: no cover
            ErrorCode.INTERNAL, "retry smyčka skončila bez výsledku"
        )

    # -- interní ---------------------------------------------------------------
    def _same_origin_location(self, location: str) -> str | None:
        """Absolutní URL přesměrování, pokud zůstává na stejném originu.

        Relativní ``Location`` se vztahuje k base_url klienta (stejný origin
        z definice). Pro absolutní se porovnává scheme+host+port; cokoli
        jiného vrací ``None`` a volající nechá odpověď spadnout jako chybu.
        """
        if not location:
            return None
        target = urllib.parse.urlsplit(location)
        if not target.scheme and not target.netloc:
            return location
        base = self._client.base_url
        base_port = base.port or (443 if base.scheme == "https" else 80)
        try:
            target_port = target.port or (443 if target.scheme == "https" else 80)
        except ValueError:
            # ``urlsplit`` odloží validaci rozsahu portu až na přístup k
            # ``.port``. Location řídí upstream, takže z něj nesmí uniknout
            # netypovaný ValueError do MCP odpovědi ani credential testu.
            logger.warning("přesměrování má neplatný port")
            return None
        if (
            target.scheme == base.scheme
            and (target.hostname or "").lower() == (base.host or "").lower()
            and target_port == base_port
            # Userinfo není součást originu, ale v cílové URL by se mohl
            # propsat do Authorization nebo diagnostiky. Redirect ho nikdy
            # nepotřebuje a bezpečný klient ho musí odmítnout i na stejném
            # hostu.
            and target.username is None
            and target.password is None
        ):
            return location
        logger.warning("přesměrování na cizí origin se nenásleduje")
        return None

    def _wait(
        self,
        policy: RetryPolicy,
        attempt: int,
        response: httpx.Response | None,
        method: str,
        path: str,
        *,
        reason: str,
    ) -> None:
        delay = policy.sleep_for(attempt, response)
        logger.warning(
            "%s %s selhalo (%s), pokus %d/%d — opakuji za %.1fs",
            method,
            path,
            reason,
            attempt,
            policy.max_attempts,
            delay,
        )
        self._sleep(delay)

    def _record_rate_limit(self, response: httpx.Response) -> None:
        for header in self._rate_limit_headers:
            if header in response.headers:
                self.rate_limit[header] = response.headers[header]

    @staticmethod
    def _json(response: httpx.Response) -> Any:
        try:
            return response.json()
        except ValueError:
            # Provider content can contain PII or secrets. Keep it out of both
            # the model response and logs; request correlation is sufficient.
            logger.warning("upstream vrátil neplatný JSON")
            raise ConnectorError(
                ErrorCode.INTERNAL, "upstream vrátil odpověď, která není platný JSON"
            ) from None


__all__ = [
    "DEFAULT_RATE_LIMIT_HEADERS",
    "NO_RETRY",
    "READ_RETRY",
    "SERVER_ERRORS_ONLY",
    "RetryPolicy",
    "TokenProvider",
    "UpstreamClient",
    "encode_segment",
    "map_http_exc",
    "raise_for_status",
]
