import threading
import time

from openmcp_sdk.secrets.cache import TTLCache


def test_caches_within_ttl_and_reloads_after_expiry():
    cache = TTLCache()
    calls = []

    def loader():
        calls.append(1)
        return "v"

    assert cache.get_or_load("k", loader, ttl=60, now=100) == "v"
    assert cache.get_or_load("k", loader, ttl=60, now=130) == "v"
    assert cache.get_or_load("k", loader, ttl=60, now=161) == "v"
    assert len(calls) == 2


def test_invalidate_and_bound():
    cache = TTLCache(max_entries=2)
    cache.get_or_load("a", lambda: "a", 60, now=0)
    cache.get_or_load("b", lambda: "b", 60, now=0)
    cache.get_or_load("c", lambda: "c", 60, now=0)
    assert len(cache) == 2
    cache.invalidate("b")
    assert len(cache) == 1


def test_singleflight_loads_once_for_concurrent_callers():
    cache = TTLCache()
    start = threading.Barrier(5)
    calls = []
    results = []

    def loader():
        calls.append(1)
        time.sleep(0.03)
        return "value"

    def worker():
        start.wait()
        results.append(cache.get_or_load("same", loader, ttl=60))

    threads = [threading.Thread(target=worker) for _ in range(5)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    assert results == ["value"] * 5
    assert calls == [1]
