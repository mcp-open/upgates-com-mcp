from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

import pytest
import yaml

from openmcp_sdk.release_gate import (
    bind_trivy_report,
    build_contents_manifest,
    build_provenance_statement,
    build_withdrawal_statement,
    verify_release_gate,
)

SOURCE_COMMIT = "a" * 40
SOURCE_REPOSITORY = "https://github.com/mcp-open/demo-mcp"
BUILDER = (
    "https://github.com/mcp-open/demo-mcp/"
    ".github/workflows/distribution-release.yml@refs/heads/main"
)


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data), encoding="utf-8")


def _fixture(tmp_path: Path, *, vulnerabilities: list[dict] | None = None):
    artifact = tmp_path / "dist/demo.zip"
    artifact.parent.mkdir()
    artifact.write_bytes(b"artifact")
    lock = tmp_path / "uv.lock"
    lock.write_text("locked", encoding="utf-8")
    sbom = tmp_path / "evidence/demo.spdx.json"
    _write_json(
        sbom,
        {
            "spdxVersion": "SPDX-2.3",
            "name": "demo.zip",
            "documentNamespace": "https://openmcp.cz/sbom/demo",
            "creationInfo": {"created": "2026-07-23T00:00:00Z"},
            "packages": [
                {
                    "name": "demo.zip",
                    "SPDXID": "SPDXRef-demo",
                    "checksums": [
                        {
                            "algorithm": "SHA256",
                            "checksumValue": _sha(artifact),
                        }
                    ],
                }
            ],
            "relationships": [
                {
                    "spdxElementId": "SPDXRef-DOCUMENT",
                    "relationshipType": "DESCRIBES",
                    "relatedSpdxElement": "SPDXRef-demo",
                }
            ],
        },
    )
    scan = tmp_path / "evidence/demo.trivy.json"
    _write_json(
        scan,
        {
            "SchemaVersion": 2,
            "Trivy": {"Version": "0.72.0"},
            "ArtifactName": "dist/demo.zip",
            "Results": [
                {
                    "Target": "demo.zip",
                    "Vulnerabilities": vulnerabilities or [],
                }
            ],
        },
    )
    contents = tmp_path / "evidence/demo.contents.json"
    _write_json(
        contents,
        build_contents_manifest(
            artifact=artifact,
            artifact_name="dist/demo.zip",
            build_inputs=[("uv.lock", lock)],
        ),
    )
    _write_json(
        scan,
        bind_trivy_report(
            report=scan,
            artifact_name="dist/demo.zip",
            contents_manifest=contents,
            required_targets=["demo.zip"],
        ),
    )
    signature = tmp_path / "evidence/demo.sigstore.json"
    signature.write_text("{}", encoding="utf-8")
    provenance = tmp_path / "evidence/demo.provenance.json"
    statement = build_provenance_statement(
        artifact=artifact,
        artifact_name="dist/demo.zip",
        source_repository=SOURCE_REPOSITORY,
        source_commit=SOURCE_COMMIT,
        builder_identity=BUILDER,
        invocation_id="https://github.com/mcp-open/demo-mcp/actions/runs/1",
        target="gemini_remote",
        lockfiles=[
            ("uv.lock", lock),
            ("evidence/demo.spdx.json", sbom),
            ("evidence/demo.trivy.json", scan),
            ("evidence/demo.contents.json", contents),
        ],
    )
    _write_json(provenance, statement)
    provenance_signature = tmp_path / "evidence/demo.provenance.sigstore.json"
    provenance_signature.write_text("{}", encoding="utf-8")
    fake_cosign = tmp_path / "cosign"
    fake_cosign.write_text(
        '#!/bin/sh\nprintf \'%s\\n\' "$*" >> "$COSIGN_CALLS"\nexit 0\n',
        encoding="utf-8",
    )
    fake_cosign.chmod(0o755)
    return {
        "artifact": artifact,
        "lock": lock,
        "sbom": sbom,
        "scan": scan,
        "contents": contents,
        "signature": signature,
        "provenance": provenance,
        "provenance_signature": provenance_signature,
        "cosign": fake_cosign,
    }


def _gate(tmp_path: Path, *, approvals: bool = False) -> Path:
    data = {
        "schema_version": 1,
        "source_repository": SOURCE_REPOSITORY,
        "builder_identity": BUILDER,
        "oidc_issuer": "https://token.actions.githubusercontent.com",
        "trivy_version": "0.72.0",
        "high_approvers": ["security@example.com"],
        "artifacts": [
            {
                "target": "gemini_remote",
                "artifact": "dist/demo.zip",
                "sbom": "evidence/demo.spdx.json",
                "scan": "evidence/demo.trivy.json",
                "contents_manifest": "evidence/demo.contents.json",
                "scan_targets": ["demo.zip"],
                "signature_bundle": "evidence/demo.sigstore.json",
                "provenance": "evidence/demo.provenance.json",
                "provenance_bundle": ("evidence/demo.provenance.sigstore.json"),
                "lockfiles": (
                    ["uv.lock", "evidence/high-approvals.yaml"]
                    if approvals
                    else ["uv.lock"]
                ),
            }
        ],
    }
    if approvals:
        data["high_approvals"] = "evidence/high-approvals.yaml"
    path = tmp_path / "release-gate.yaml"
    path.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
    return path


def test_gate_verifies_exact_artifact_scan_signature_and_provenance(
    tmp_path, monkeypatch
):
    fixture = _fixture(tmp_path)
    calls = tmp_path / "cosign-calls"
    monkeypatch.setenv("COSIGN_CALLS", str(calls))

    result = verify_release_gate(
        _gate(tmp_path),
        root=tmp_path,
        source_commit=SOURCE_COMMIT,
        output=tmp_path / "release-evidence.json",
        cosign_binary=str(fixture["cosign"]),
        now=datetime(2026, 7, 23, tzinfo=UTC),
    )

    assert result["status"] == "eligible"
    assert result["artifacts"][0]["sha256"] == _sha(fixture["artifact"])
    assert result["artifacts"][0]["sbom"]["packages"] == 1
    assert result["artifacts"][0]["contents"]["payload_files"] == 1
    assert result["artifacts"][0]["signature"]["status"] == "verified"
    assert result["artifacts"][0]["signature"]["bundle_sha256"] == _sha(
        fixture["signature"]
    )
    assert result["artifacts"][0]["provenance"]["status"] == "verified"
    recorded = calls.read_text(encoding="utf-8")
    assert recorded.count("verify-blob") == 2
    assert str(fixture["artifact"]) in recorded
    assert str(fixture["provenance"]) in recorded
    assert "--certificate-identity " + BUILDER in recorded


def test_gate_blocks_critical_before_crypto(tmp_path, monkeypatch):
    fixture = _fixture(
        tmp_path,
        vulnerabilities=[{"VulnerabilityID": "CVE-CRITICAL", "Severity": "CRITICAL"}],
    )
    calls = tmp_path / "cosign-calls"
    monkeypatch.setenv("COSIGN_CALLS", str(calls))

    with pytest.raises(ValueError, match="CRITICAL"):
        verify_release_gate(
            _gate(tmp_path),
            root=tmp_path,
            source_commit=SOURCE_COMMIT,
            output=tmp_path / "release-evidence.json",
            cosign_binary=str(fixture["cosign"]),
        )
    assert not calls.exists()
    assert not (tmp_path / "release-evidence.json").exists()


def test_gate_blocks_embedded_secret_even_when_reported_lower_severity(
    tmp_path, monkeypatch
):
    fixture = _fixture(tmp_path)
    report = json.loads(fixture["scan"].read_text(encoding="utf-8"))
    report["Results"][0]["Secrets"] = [{"RuleID": "aws-access-key", "Severity": "HIGH"}]
    _write_json(fixture["scan"], report)
    monkeypatch.setenv("COSIGN_CALLS", str(tmp_path / "cosign-calls"))

    with pytest.raises(ValueError, match="SECRET:aws-access-key"):
        verify_release_gate(
            _gate(tmp_path),
            root=tmp_path,
            source_commit=SOURCE_COMMIT,
            output=tmp_path / "release-evidence.json",
            cosign_binary=str(fixture["cosign"]),
        )


def test_gate_requires_approval_for_failed_high_misconfiguration(tmp_path, monkeypatch):
    fixture = _fixture(tmp_path)
    report = json.loads(fixture["scan"].read_text(encoding="utf-8"))
    report["Results"][0]["Misconfigurations"] = [
        {"ID": "CFG-001", "Severity": "HIGH", "Status": "FAIL"}
    ]
    _write_json(fixture["scan"], report)
    monkeypatch.setenv("COSIGN_CALLS", str(tmp_path / "cosign-calls"))

    with pytest.raises(ValueError, match="MISCONFIG:CFG-001"):
        verify_release_gate(
            _gate(tmp_path),
            root=tmp_path,
            source_commit=SOURCE_COMMIT,
            output=tmp_path / "release-evidence.json",
            cosign_binary=str(fixture["cosign"]),
        )


def test_gate_requires_bound_unexpired_high_approval(tmp_path, monkeypatch):
    fixture = _fixture(
        tmp_path,
        vulnerabilities=[{"VulnerabilityID": "CVE-HIGH", "Severity": "HIGH"}],
    )
    calls = tmp_path / "cosign-calls"
    monkeypatch.setenv("COSIGN_CALLS", str(calls))

    with pytest.raises(ValueError, match="platné časově omezené"):
        verify_release_gate(
            _gate(tmp_path),
            root=tmp_path,
            source_commit=SOURCE_COMMIT,
            output=tmp_path / "release-evidence.json",
            cosign_binary=str(fixture["cosign"]),
            now=datetime(2026, 7, 23, tzinfo=UTC),
        )

    approvals = tmp_path / "evidence/high-approvals.yaml"
    approvals.write_text(
        yaml.safe_dump(
            [
                {
                    "artifact_sha256": _sha(fixture["artifact"]),
                    "vulnerability_id": "CVE-HIGH",
                    "approved_by": "security@example.com",
                    "reason": "Upstream fix pending; no reachable code path.",
                    "expires_at": "2026-07-30T00:00:00Z",
                }
            ],
            sort_keys=False,
        ),
        encoding="utf-8",
    )
    statement = build_provenance_statement(
        artifact=fixture["artifact"],
        artifact_name="dist/demo.zip",
        source_repository=SOURCE_REPOSITORY,
        source_commit=SOURCE_COMMIT,
        builder_identity=BUILDER,
        invocation_id="https://github.com/mcp-open/demo-mcp/actions/runs/1",
        target="gemini_remote",
        lockfiles=[
            ("uv.lock", fixture["lock"]),
            ("evidence/high-approvals.yaml", approvals),
            ("evidence/demo.spdx.json", fixture["sbom"]),
            ("evidence/demo.trivy.json", fixture["scan"]),
            ("evidence/demo.contents.json", fixture["contents"]),
        ],
    )
    _write_json(fixture["provenance"], statement)

    result = verify_release_gate(
        _gate(tmp_path, approvals=True),
        root=tmp_path,
        source_commit=SOURCE_COMMIT,
        output=tmp_path / "release-evidence.json",
        cosign_binary=str(fixture["cosign"]),
        now=datetime(2026, 7, 23, tzinfo=UTC),
    )
    assert result["status"] == "eligible"
    assert result["artifacts"][0]["scan"]["severity_counts"]["HIGH"] == 1


def test_gate_rejects_provenance_for_other_commit(tmp_path, monkeypatch):
    fixture = _fixture(tmp_path)
    provenance = json.loads(fixture["provenance"].read_text(encoding="utf-8"))
    provenance["predicate"]["buildDefinition"]["resolvedDependencies"][0]["digest"][
        "gitCommit"
    ] = "b" * 40
    _write_json(fixture["provenance"], provenance)
    monkeypatch.setenv("COSIGN_CALLS", str(tmp_path / "cosign-calls"))

    with pytest.raises(ValueError, match="source commitem"):
        verify_release_gate(
            _gate(tmp_path),
            root=tmp_path,
            source_commit=SOURCE_COMMIT,
            output=tmp_path / "release-evidence.json",
            cosign_binary=str(fixture["cosign"]),
        )


def test_gate_rejects_scan_changed_after_signed_provenance(tmp_path, monkeypatch):
    fixture = _fixture(tmp_path)
    report = json.loads(fixture["scan"].read_text(encoding="utf-8"))
    report["ReportID"] = "tampered-after-provenance"
    _write_json(fixture["scan"], report)
    monkeypatch.setenv("COSIGN_CALLS", str(tmp_path / "cosign-calls"))

    with pytest.raises(ValueError, match="lockfile evidence/demo.trivy.json"):
        verify_release_gate(
            _gate(tmp_path),
            root=tmp_path,
            source_commit=SOURCE_COMMIT,
            output=tmp_path / "release-evidence.json",
            cosign_binary=str(fixture["cosign"]),
        )


def test_gate_rejects_unpinned_trivy_report_version(tmp_path, monkeypatch):
    fixture = _fixture(tmp_path)
    report = json.loads(fixture["scan"].read_text(encoding="utf-8"))
    report["Trivy"]["Version"] = "0.73.0"
    _write_json(fixture["scan"], report)
    monkeypatch.setenv("COSIGN_CALLS", str(tmp_path / "cosign-calls"))

    with pytest.raises(ValueError, match="schema, targets nebo content binding"):
        verify_release_gate(
            _gate(tmp_path),
            root=tmp_path,
            source_commit=SOURCE_COMMIT,
            output=tmp_path / "release-evidence.json",
            cosign_binary=str(fixture["cosign"]),
        )


def test_gate_rejects_content_manifest_that_no_longer_matches_artifact(
    tmp_path, monkeypatch
):
    fixture = _fixture(tmp_path)
    manifest = json.loads(fixture["contents"].read_text(encoding="utf-8"))
    manifest["payload"][0]["sha256"] = "0" * 64
    _write_json(fixture["contents"], manifest)
    monkeypatch.setenv("COSIGN_CALLS", str(tmp_path / "cosign-calls"))

    with pytest.raises(ValueError, match="přesnému artifact payloadu"):
        verify_release_gate(
            _gate(tmp_path),
            root=tmp_path,
            source_commit=SOURCE_COMMIT,
            output=tmp_path / "release-evidence.json",
            cosign_binary=str(fixture["cosign"]),
        )


def test_trivy_binding_requires_analyzed_dependency_target(tmp_path):
    report = tmp_path / "report.json"
    _write_json(
        report,
        {
            "SchemaVersion": 2,
            "Trivy": {"Version": "0.72.0"},
            "ArtifactName": "scan-root",
            "Results": [{"Target": "other.lock"}],
        },
    )
    manifest = tmp_path / "contents.json"
    _write_json(manifest, {"schema": "openmcp.artifact-contents.v1"})

    with pytest.raises(ValueError, match="povinné targety"):
        bind_trivy_report(
            report=report,
            artifact_name="dist/demo.zip",
            contents_manifest=manifest,
            required_targets=["uv.lock"],
        )


def test_gate_rejects_builder_outside_source_repository(tmp_path):
    _fixture(tmp_path)
    gate = yaml.safe_load(_gate(tmp_path).read_text(encoding="utf-8"))
    gate["builder_identity"] = (
        "https://github.com/attacker/repo/"
        ".github/workflows/distribution-release.yml@refs/heads/main"
    )
    path = tmp_path / "invalid-gate.yaml"
    path.write_text(yaml.safe_dump(gate), encoding="utf-8")

    with pytest.raises(ValueError, match="source repository"):
        verify_release_gate(
            path,
            root=tmp_path,
            source_commit=SOURCE_COMMIT,
            output=tmp_path / "release-evidence.json",
        )


def test_gate_fails_when_cosign_rejects_bundle(tmp_path, monkeypatch):
    fixture = _fixture(tmp_path)
    fixture["cosign"].write_text("#!/bin/sh\nexit 1\n", encoding="utf-8")
    monkeypatch.setenv("COSIGN_CALLS", str(tmp_path / "cosign-calls"))

    with pytest.raises(ValueError, match="cosign verify-blob"):
        verify_release_gate(
            _gate(tmp_path),
            root=tmp_path,
            source_commit=SOURCE_COMMIT,
            output=tmp_path / "release-evidence.json",
            cosign_binary=str(fixture["cosign"]),
        )


def test_gate_rejects_symlinked_evidence(tmp_path, monkeypatch):
    fixture = _fixture(tmp_path)
    real = fixture["scan"]
    alias = real.with_name("scan-link.json")
    alias.symlink_to(real)
    gate = yaml.safe_load(_gate(tmp_path).read_text(encoding="utf-8"))
    gate["artifacts"][0]["scan"] = "evidence/scan-link.json"
    (tmp_path / "release-gate.yaml").write_text(yaml.safe_dump(gate), encoding="utf-8")
    monkeypatch.setenv("COSIGN_CALLS", str(tmp_path / "cosign-calls"))

    with pytest.raises(ValueError, match="symlink"):
        verify_release_gate(
            tmp_path / "release-gate.yaml",
            root=tmp_path,
            source_commit=SOURCE_COMMIT,
            output=tmp_path / "release-evidence.json",
            cosign_binary=str(fixture["cosign"]),
        )


def test_provenance_builder_rejects_unbound_or_unsafe_inputs(tmp_path):
    artifact = tmp_path / "demo.zip"
    artifact.write_bytes(b"artifact")
    lock = tmp_path / "uv.lock"
    lock.write_text("locked", encoding="utf-8")

    with pytest.raises(ValueError, match="release target"):
        build_provenance_statement(
            artifact=artifact,
            artifact_name="dist/demo.zip",
            source_repository=SOURCE_REPOSITORY,
            source_commit=SOURCE_COMMIT,
            builder_identity=BUILDER,
            invocation_id="https://github.com/mcp-open/demo-mcp/actions/runs/1",
            target="unknown",
            lockfiles=[("uv.lock", lock)],
        )
    with pytest.raises(ValueError, match="unikátní lockfiles"):
        build_provenance_statement(
            artifact=artifact,
            artifact_name="dist/demo.zip",
            source_repository=SOURCE_REPOSITORY,
            source_commit=SOURCE_COMMIT,
            builder_identity=BUILDER,
            invocation_id="https://github.com/mcp-open/demo-mcp/actions/runs/1",
            target="gemini_remote",
            lockfiles=[("uv.lock", lock), ("uv.lock", lock)],
        )


def test_withdrawal_binds_exact_release_evidence_and_artifacts(tmp_path):
    evidence = tmp_path / "release-evidence.json"
    _write_json(
        evidence,
        {
            "schema": "openmcp.release-evidence.v1",
            "status": "eligible",
            "source": {
                "repository": SOURCE_REPOSITORY,
                "commit": SOURCE_COMMIT,
                "builder": BUILDER,
            },
            "artifacts": [
                {
                    "target": "gemini_remote",
                    "artifact": "dist/demo.zip",
                    "sha256": "b" * 64,
                }
            ],
        },
    )
    bundle = tmp_path / "release-evidence.sigstore.json"
    bundle.write_text("{}", encoding="utf-8")
    cosign = tmp_path / "cosign-withdrawal"
    cosign.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
    cosign.chmod(0o755)

    statement = build_withdrawal_statement(
        release_evidence=evidence,
        evidence_bundle=bundle,
        release_reference="demo@1.2.3",
        reason="Security incident requires immediate withdrawal.",
        actor="security@example.com",
        certificate_identity=BUILDER,
        oidc_issuer="https://token.actions.githubusercontent.com",
        cosign_binary=str(cosign),
        incident_url="https://openmcp.cz/incidents/INC-1",
        now=datetime(2026, 7, 23, tzinfo=UTC),
    )

    assert statement["schema"] == "openmcp.release-withdrawal.v1"
    assert statement["status"] == "withdrawn"
    assert statement["release_evidence"]["sha256"] == _sha(evidence)
    assert statement["artifacts"] == [
        {
            "target": "gemini_remote",
            "artifact": "dist/demo.zip",
            "sha256": "b" * 64,
        }
    ]
    assert statement["withdrawn_at"] == "2026-07-23T00:00:00Z"


def test_withdrawal_rejects_noneligible_or_symlinked_evidence(tmp_path):
    evidence = tmp_path / "release-evidence.json"
    _write_json(
        evidence,
        {
            "schema": "openmcp.release-evidence.v1",
            "status": "withdrawn",
            "artifacts": [],
        },
    )
    bundle = tmp_path / "release-evidence.sigstore.json"
    bundle.write_text("{}", encoding="utf-8")
    cosign = tmp_path / "cosign-withdrawal"
    cosign.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
    cosign.chmod(0o755)
    with pytest.raises(ValueError, match="eligible"):
        build_withdrawal_statement(
            release_evidence=evidence,
            evidence_bundle=bundle,
            release_reference="demo@1.2.3",
            reason="Security incident requires withdrawal.",
            actor="security@example.com",
            certificate_identity=BUILDER,
            oidc_issuer="https://token.actions.githubusercontent.com",
            cosign_binary=str(cosign),
        )
    alias = tmp_path / "evidence-link.json"
    alias.symlink_to(evidence)
    with pytest.raises(ValueError, match="neexistuje"):
        build_withdrawal_statement(
            release_evidence=alias,
            evidence_bundle=bundle,
            release_reference="demo@1.2.3",
            reason="Security incident requires withdrawal.",
            actor="security@example.com",
            certificate_identity=BUILDER,
            oidc_issuer="https://token.actions.githubusercontent.com",
            cosign_binary=str(cosign),
        )
