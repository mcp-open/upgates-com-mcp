import httpx
import pytest

from openmcp_sdk.context import Principal, RequestContext, reset_context, set_context
from openmcp_sdk.envelope import ConnectorError, ErrorCode
from openmcp_sdk.http import map_http_exc, raise_for_status


def _response(code):
    return httpx.Response(code, request=httpx.Request("GET", "https://upstream.test"))


@pytest.mark.parametrize(
    ("status", "code"),
    [
        (400, ErrorCode.INVALID_INPUT),
        (404, ErrorCode.NOT_FOUND),
        (410, ErrorCode.NOT_FOUND),
        (429, ErrorCode.RATE_LIMITED),
        (500, ErrorCode.UPSTREAM_ERROR),
        (302, ErrorCode.UPSTREAM_ERROR),
    ],
)
def test_status_mapping(status, code):
    with pytest.raises(ConnectorError) as error:
        raise_for_status(_response(status))
    assert error.value.code == code


@pytest.mark.parametrize(
    ("status", "fragment"),
    [
        (400, "odmítl vstup"),
        (422, "odmítl vstup"),
        (404, "nenašel požadovaný zdroj"),
        (410, "nenašel požadovaný zdroj"),
        (409, "konfliktu"),
    ],
)
def test_client_error_message_distinguishes_cause(status, fragment):
    """Zpráva nesmí lhát o příčině a not-found není vadný vstup.

    404 z upstreamu typicky znamená neexistující zdroj nebo špatně
    nakonfigurované připojení (RAYNET: „Instance not found"), ne chybný
    tvar argumentů nástroje.
    """
    with pytest.raises(ConnectorError) as error:
        raise_for_status(_response(status))
    expected = ErrorCode.NOT_FOUND if status in {404, 410} else ErrorCode.INVALID_INPUT
    assert error.value.code == expected
    assert fragment in error.value.message
    assert error.value.status == status


def test_401_invalidates_current_credentials():
    calls = []
    token = set_context(
        RequestContext(Principal("u1"), {}, {}, lambda: calls.append("u1"))
    )
    try:
        with pytest.raises(ConnectorError) as error:
            raise_for_status(_response(401))
    finally:
        reset_context(token)
    assert error.value.code == ErrorCode.FORBIDDEN
    assert calls == ["u1"]


def test_http_exception_mapping_never_exposes_raw_message():
    assert (
        map_http_exc(httpx.TimeoutException("token=super-secret")).code
        == ErrorCode.UPSTREAM_UNAVAILABLE
    )
    error = map_http_exc(RuntimeError("password=hunter2"))
    assert error.code == ErrorCode.INTERNAL
    assert "hunter2" not in error.message


def test_ok_does_not_raise():
    raise_for_status(_response(204))
