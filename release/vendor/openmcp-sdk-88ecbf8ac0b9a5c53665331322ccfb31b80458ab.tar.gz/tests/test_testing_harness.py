import pytest

from openmcp_sdk.context import AccessPolicy, WriteDecision, current_context
from openmcp_sdk.testing import FakeElicitation, FakeOAuth, elicitation, with_context


def test_with_context_keeps_positional_backwards_compatibility():
    with with_context({"api_key": "k"}, {"region": "cz"}, "user-9") as ctx:
        assert ctx.principal.sub == "user-9"
        assert ctx.secrets["api_key"] == "k"
        assert ctx.config["region"] == "cz"


def test_with_context_exposes_policy_and_oauth():
    """Bez těchto dvou se nedal otestovat write gating ani delegovaný OAuth."""
    oauth = FakeOAuth(cloud_id="cloud-7")
    policy = AccessPolicy(mode="approval_required")
    with with_context(policy=policy, oauth=oauth, request_id="req-1") as ctx:
        assert current_context() is ctx
        assert ctx.policy.write_decision("x") is WriteDecision.REQUIRE_APPROVAL
        assert ctx.oauth.cloud_id == "cloud-7"
        assert ctx.request_id == "req-1"


def test_context_is_restored_after_block():
    from openmcp_sdk.envelope import ConnectorError

    with with_context(sub="a"):
        pass
    with pytest.raises(ConnectorError):
        current_context()


def test_fake_oauth_rotates_token_on_invalidate():
    oauth = FakeOAuth(tokens=["stale", "fresh"])
    assert oauth.access_token() == "stale"
    oauth.invalidate()
    assert oauth.access_token() == "fresh"
    assert oauth.invalidated == 1


@pytest.mark.anyio
async def test_fake_elicitation_accept():
    fake = FakeElicitation("accept")
    result = await fake.elicit("potvrdit?")
    assert getattr(result, "action", None) == "accept"
    assert fake.messages == ["potvrdit?"]


@pytest.mark.anyio
async def test_fake_elicitation_unsupported_raises():
    with pytest.raises(RuntimeError):
        await FakeElicitation("unsupported").elicit("x")


@pytest.mark.anyio
async def test_elicitation_context_manager_installs_and_restores():
    import fastmcp.server.dependencies as deps

    original = deps.get_context
    with elicitation("decline") as fake:
        assert deps.get_context() is fake
    assert deps.get_context is original


def test_pii_salt_fixture_is_autouse():
    """Autouse salt — bez něj by testy padaly na fail-closed `require_salt`."""
    import os

    from openmcp_sdk.pii import SALT_ENV

    assert os.environ.get(SALT_ENV)
