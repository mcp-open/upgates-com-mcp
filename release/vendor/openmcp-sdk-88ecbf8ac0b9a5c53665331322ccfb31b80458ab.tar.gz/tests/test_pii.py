"""Testy pseudonymizace.

Těžiště je na **bitové identitě s původními implementacemi konektorů**. Token
je navenek viditelný, dlouhodobě stabilní kontrakt: kdyby se odvození byť jen
posunulo, uživatel by po deployi viděl jiné ID pro stejná data a historie
konverzací by přestala sedět.

Zlaté hodnoty níže jsou spočítané **původním raynetovým a dotykačkovým kódem**
(`connector.pii` v těch repozitářích) se saltem ``zlaty-salt-pro-test``, ne
tímto modulem — jinak by test jen porovnával implementaci se sebou samou.
"""

import pytest

from openmcp_sdk.envelope import ConnectorError, ErrorCode
from openmcp_sdk.pii import (
    SALT_ENV,
    TOKEN_RE,
    ConditionalName,
    PiiPolicy,
    Pseudonymizer,
    assert_no_tokens,
    contains_token,
    derive_key,
    require_salt,
)

GOLDEN_SALT = "zlaty-salt-pro-test"
GOLDEN_SUB = "user-42"
# Spočítané původním raynet/connector/pii.py
GOLDEN_KEY_HEX = "ec2f57989f6c9c8780faadd6a23c9f7a7481610ab87308c82d9c8142cd6e4186"
GOLDEN_TOKENS = {
    ("EMAIL", "alice@example.com"): "<EMAIL_a8e7085b246f>",
    ("PHONE", "+420 777 123 456"): "<PHONE_c56fc8a0ea81>",
    ("NAME", "Alice Nováková"): "<NAME_f6a2b67b2c4f>",
    ("ADDR", "Dlouhá 5, Praha"): "<ADDR_f49779e2a5b5>",
}
GOLDEN_SCRUB_IN = "napiš na bob@firma.cz nebo +420 608 111 222"
GOLDEN_SCRUB_OUT = "napiš na <EMAIL_b76304d8a945> nebo <PHONE_638887a9a64c>"
# Spočítané původním dotykacka/connector/pii.py: derive_key("user-42:cloud-7")
GOLDEN_TENANT_KEY_HEX = (
    "45649bcade4f1ce7207bbbe0b16dacbe7cb541d3557606f657db77709caa367d"
)


@pytest.fixture
def salt_env(monkeypatch):
    monkeypatch.setenv(SALT_ENV, GOLDEN_SALT)


def _pseudonymizer(policy: PiiPolicy | None = None, **kwargs) -> Pseudonymizer:
    key = bytes.fromhex(GOLDEN_KEY_HEX)
    return Pseudonymizer(key, policy or PiiPolicy(), **kwargs)


# -- bitová identita s původními implementacemi ----------------------------------


def test_derive_key_matches_original_single_scope(salt_env):
    assert derive_key(GOLDEN_SUB).hex() == GOLDEN_KEY_HEX


def test_derive_key_matches_original_tenant_scope(salt_env):
    """`derive_key(sub, cloud)` musí dát totéž, co dotykačkovo `sub:cloud`."""
    assert derive_key(GOLDEN_SUB, "cloud-7").hex() == GOLDEN_TENANT_KEY_HEX


def test_derive_key_accepts_explicit_salt_without_env():
    assert derive_key(GOLDEN_SUB, salt=GOLDEN_SALT).hex() == GOLDEN_KEY_HEX


@pytest.mark.parametrize("pair,expected", sorted(GOLDEN_TOKENS.items()))
def test_token_matches_original(pair, expected):
    category, value = pair
    assert _pseudonymizer().token(category, value) == expected


def test_scrub_text_matches_original():
    assert _pseudonymizer().scrub_text(GOLDEN_SCRUB_IN) == GOLDEN_SCRUB_OUT


def test_tenant_scope_isolates_tokens(salt_env):
    """Propojení jiného tenanta nesmí dát korelovatelné tokeny."""
    a = Pseudonymizer(derive_key(GOLDEN_SUB, "cloud-1"), PiiPolicy())
    b = Pseudonymizer(derive_key(GOLDEN_SUB, "cloud-2"), PiiPolicy())
    assert a.token("EMAIL", "x@y.cz") != b.token("EMAIL", "x@y.cz")


def test_token_is_stable_across_instances(salt_env):
    a = Pseudonymizer(derive_key(GOLDEN_SUB), PiiPolicy())
    b = Pseudonymizer(derive_key(GOLDEN_SUB), PiiPolicy())
    assert a.token("EMAIL", "x@y.cz") == b.token("EMAIL", "x@y.cz")


# -- salt fail-closed ----------------------------------------------------------


@pytest.mark.parametrize("value", ["", "   "])
def test_require_salt_refuses_empty(monkeypatch, value):
    monkeypatch.setenv(SALT_ENV, value)
    with pytest.raises(RuntimeError, match=SALT_ENV):
        require_salt()


def test_require_salt_refuses_missing(monkeypatch):
    monkeypatch.delenv(SALT_ENV, raising=False)
    with pytest.raises(RuntimeError):
        require_salt()


def test_derive_key_rejects_empty_scope():
    with pytest.raises(ValueError):
        derive_key(salt=GOLDEN_SALT)
    with pytest.raises(ValueError):
        derive_key("", salt=GOLDEN_SALT)


# -- token guard ---------------------------------------------------------------


@pytest.mark.parametrize(
    "value",
    [
        "<EMAIL_a8e7085b246f>",
        "text s <NAME_f6a2b67b2c4f> uprostred",
        {"a": ["x", "<ADDR_f49779e2a5b5>"]},
        [{"deep": "<PHONE_c56fc8a0ea81>"}],
    ],
)
def test_contains_token_finds_nested(value):
    assert contains_token(value) is True


@pytest.mark.parametrize("value", ["čistý text", {"a": 1}, [None, True], "<EMAIL_xx>"])
def test_contains_token_ignores_non_tokens(value):
    assert contains_token(value) is False


def test_assert_no_tokens_blocks_write():
    with pytest.raises(ConnectorError) as excinfo:
        assert_no_tokens({"email": "<EMAIL_a8e7085b246f>"})
    assert excinfo.value.code is ErrorCode.INVALID_INPUT


# -- pořadí vyhodnocení ------------------------------------------------------


def test_exact_category_wins_over_freetext():
    """Kanonické pořadí: kategorie před freetextem (raynetovo chování)."""
    policy = PiiPolicy(field_category={"othercontact": "CONTACT"})
    out = _pseudonymizer(policy).sanitize({"othercontact": "volajte 777 123 456"})
    assert out["othercontact"].startswith("<CONTACT_")


def test_policy_validate_rejects_field_in_both_sets():
    """Pole v obou množinách je téměř vždy překlep — freetext by byl mrtvý."""
    policy = PiiPolicy(
        field_category={"othercontact": "CONTACT"},
        freetext_fields=frozenset({"othercontact"}),
    )
    with pytest.raises(ValueError, match="othercontact"):
        policy.validate()


def test_substring_fallback_catches_custom_fields():
    """upgates: `*_invoice`, `*_postal` – přesná shoda nezafunguje."""
    policy = PiiPolicy(pattern_category=(("_invoice", "ADDR"),))
    out = _pseudonymizer(policy).sanitize({"street_invoice": "Dlouhá 5"})
    assert out["street_invoice"].startswith("<ADDR_")


def test_exact_category_beats_substring():
    policy = PiiPolicy(
        field_category={"email_invoice": "EMAIL"},
        pattern_category=(("_invoice", "ADDR"),),
    )
    out = _pseudonymizer(policy).sanitize({"email_invoice": "a@b.cz"})
    assert out["email_invoice"].startswith("<EMAIL_")


# -- průchod ------------------------------------------------------------------


def test_unknown_fields_still_scrubbed_fail_closed():
    """Nevyjmenované pole nesmí propustit e-mail v otevřené podobě."""
    out = _pseudonymizer().sanitize({"uplne_neznamé": "pište na x@y.cz"})
    assert "x@y.cz" not in out["uplne_neznamé"]


def test_booleans_and_empty_values_pass_through():
    policy = PiiPolicy(field_category={"email": "EMAIL"})
    out = _pseudonymizer(policy).sanitize({"email": "", "flag": True, "nic": None})
    assert out == {"email": "", "flag": True, "nic": None}


def test_list_of_pii_values_is_tokenized():
    policy = PiiPolicy(field_category={"emails": "EMAIL"})
    out = _pseudonymizer(policy).sanitize({"emails": ["a@b.cz", "c@d.cz"]})
    assert all(TOKEN_RE.fullmatch(item) for item in out["emails"])
    assert out["emails"][0] != out["emails"][1]


def test_codebook_object_value_is_tokenized_fail_closed():
    """PII pole dodané jako {id, value} nesmí projít otevřené."""
    policy = PiiPolicy(field_category={"email": "EMAIL"})
    out = _pseudonymizer(policy).sanitize({"email": {"id": 3, "value": "a@b.cz"}})
    assert out["email"]["value"].startswith("<EMAIL_")


def test_sensitive_object_field():
    policy = PiiPolicy(sensitive_object_fields=frozenset({"maritalstatus"}))
    out = _pseudonymizer(policy).sanitize(
        {"maritalStatus": {"id": 1, "value": "ženatý"}}
    )
    assert out["maritalStatus"]["value"].startswith("<MARITALSTATUS_")


def test_nested_category_photo_filename():
    """Fotka osoby prozradí jméno; přílohy jsou byznys dokumenty a zůstávají."""
    policy = PiiPolicy(nested_categories={"photo": {"filename": "FILE"}})
    out = _pseudonymizer(policy).sanitize(
        {"photo": {"fileName": "alice.png"}, "attachment": {"fileName": "nabidka.xlsx"}}
    )
    assert out["photo"]["fileName"].startswith("<FILE_")
    assert out["attachment"]["fileName"] == "nabidka.xlsx"


# -- jména ----------------------------------------------------------------------


def test_names_not_redacted_by_default():
    policy = PiiPolicy(name_fields=frozenset({"firstname"}))
    out = _pseudonymizer(policy).sanitize({"firstName": "Alice"})
    assert out["firstName"] == "Alice"


def test_names_redacted_when_enabled():
    policy = PiiPolicy(name_fields=frozenset({"firstname"}))
    out = _pseudonymizer(policy, redact_names=True).sanitize({"firstName": "Alice"})
    assert out["firstName"].startswith("<NAME_")


def test_conditional_name_person_true():
    """raynet: OSVČ vedená jako klient má v `name` jméno člověka."""
    policy = PiiPolicy(
        conditional_names=(ConditionalName("person", True, "name"),),
    )
    p = _pseudonymizer(policy, redact_names=True)
    assert p.sanitize({"person": True, "name": "Alice"})["name"].startswith("<NAME_")
    assert p.sanitize({"person": False, "name": "ACME s.r.o."})["name"] == "ACME s.r.o."


def test_person_scope_promotes_generic_name_field():
    """dotykacka: `name` uvnitř záznamu zákazníka je jméno osoby."""
    policy = PiiPolicy(person_scope_fields=frozenset({"customer"}))
    out = _pseudonymizer(policy, redact_names=True).sanitize(
        {"name": "Provozovna Brno", "customer": {"name": "Alice"}}
    )
    assert out["name"] == "Provozovna Brno"
    assert out["customer"]["name"].startswith("<NAME_")


def test_sanitize_person_scope_forces_scope_at_top_level():
    """dotykacka: `list_customers` vrací rovnou pole osob, bez obalového klíče —
    `person_scope_fields` samo o sobě to nezachytí, protože se aktivuje jen na
    vnořeném klíči. `sanitize(..., person_scope=True)` vynutí scope od kořene."""
    policy = PiiPolicy(person_scope_fields=frozenset({"customer"}))
    p = _pseudonymizer(policy, redact_names=True)
    out = p.sanitize([{"name": "Alice"}, {"name": "Bob"}], person_scope=True)
    assert out[0]["name"].startswith("<NAME_")
    assert out[1]["name"].startswith("<NAME_")
    # bez person_scope=True se generické `name` (mimo person_scope_fields) netokenizuje
    assert p.sanitize([{"name": "Alice"}])[0]["name"] == "Alice"


def test_known_name_propagates_into_freetext_when_enabled():
    policy = PiiPolicy(
        name_fields=frozenset({"firstname"}),
        freetext_fields=frozenset({"note"}),
        propagate_known_names=True,
    )
    p = _pseudonymizer(policy, redact_names=True)
    out = p.sanitize({"firstName": "Alice", "note": "Alice"})
    assert out["note"] == out["firstName"]


def test_known_names_registry_is_capped():
    """Po dosažení stropu degraduje propagace, ne redakce."""
    policy = PiiPolicy(
        name_fields=frozenset({"n"}), propagate_known_names=True, max_known_names=2
    )
    p = _pseudonymizer(policy, redact_names=True)
    for i in range(5):
        assert p.sanitize({"n": f"osoba{i}"})["n"].startswith("<NAME_")
    assert len(p._known_names) == 2


# -- volný text ----------------------------------------------------------------


def test_untrusted_label_added_to_long_freetext():
    policy = PiiPolicy(freetext_fields=frozenset({"note"}), untrusted_label="data z CRM")
    long_text = "x" * 40
    out = _pseudonymizer(policy).sanitize({"note": long_text})
    assert out["note"].startswith("[data z CRM] ")


def test_untrusted_label_skipped_for_short_text():
    policy = PiiPolicy(freetext_fields=frozenset({"note"}), untrusted_label="data z CRM")
    out = _pseudonymizer(policy).sanitize({"note": "krátke"})
    assert out["note"] == "krátke"


def test_untrusted_label_disabled_by_default():
    policy = PiiPolicy(freetext_fields=frozenset({"note"}))
    out = _pseudonymizer(policy).sanitize({"note": "y" * 40})
    assert out["note"] == "y" * 40


# -- falešné shody telefonu ----------------------------------------------------


@pytest.mark.parametrize("text", ["2022-06-18 13", "objednávka 1234", "kód 12-34-56"])
def test_datelike_and_short_numbers_are_not_phones(text):
    assert _pseudonymizer().scrub_text(text) == text


# -- hook konektoru ------------------------------------------------------------


def test_connector_hook_can_override():
    class Custom(Pseudonymizer):
        def handle_field(self, key, value, *, person_scope):
            if key == "special":
                return "PREPÍSANÉ"
            return self.UNHANDLED

    out = Custom(bytes.fromhex(GOLDEN_KEY_HEX), PiiPolicy()).sanitize(
        {"special": "a@b.cz", "iné": "a@b.cz"}
    )
    assert out["special"] == "PREPÍSANÉ"
    assert out["iné"].startswith("<EMAIL_")


# -- validace politiky --------------------------------------------------------


def test_policy_validate_rejects_bad_category():
    with pytest.raises(ValueError):
        PiiPolicy(field_category={"a": "lower"}).validate()


def test_policy_validate_rejects_uppercase_key():
    with pytest.raises(ValueError):
        PiiPolicy(field_category={"Email": "EMAIL"}).validate()


def test_policy_validate_accepts_clean_policy():
    PiiPolicy(
        field_category={"email": "EMAIL"},
        name_fields=frozenset({"firstname"}),
        freetext_fields=frozenset({"note"}),
        pattern_category=(("_invoice", "ADDR"),),
    ).validate()


# -- úniky, které našel bug scan -----------------------------------------------


@pytest.mark.parametrize(
    "payload",
    [
        ("x", "leak@example.com"),
        {"leak@example.com"},
        frozenset({"leak@example.com"}),
        ({"note": "leak@example.com"},),
        (["leak@example.com"],),
        [("leak@example.com",)],
        {"k": {"leak@example.com"}},
        {"leak@example.com": "v"},
        b"leak@example.com",
        bytearray(b"leak@example.com"),
        [[["leak@example.com"]]],
    ],
)
def test_sanitize_never_lets_pii_through_any_container(payload):
    """Fail-closed musí platit pro každý tvar, nejen pro dict/list/str.

    `sanitize` je veřejné API — konektor běžně sahá na `dict.keys()`, `set()`
    dedup nebo `bytes` z cache, ne jen na to, co přijde z JSON-u.
    """
    out = _pseudonymizer().sanitize(payload)
    assert "leak@example.com" not in repr(out)


def test_contains_token_checks_mapping_keys():
    """Custom-field mapy bývají klíčované hodnotou — token se dostane do klíče."""
    assert contains_token({"<EMAIL_a8e7085b246f>": "v"}) is True
    with pytest.raises(ConnectorError):
        assert_no_tokens({"<EMAIL_a8e7085b246f>": "v"})


def test_sensitive_object_field_also_scrubs_siblings():
    """Sourozenci vedle `value` se nesmí ztratit z průchodu."""
    policy = PiiPolicy(sensitive_object_fields=frozenset({"maritalstatus"}))
    out = _pseudonymizer(policy).sanitize(
        {"maritalStatus": {"id": 1, "value": "single", "note": "a@b.cz"}}
    )
    assert out["maritalStatus"]["value"].startswith("<MARITALSTATUS_")
    assert "a@b.cz" not in out["maritalStatus"]["note"]


def test_same_value_gives_same_token_regardless_of_shape():
    """Skalár i codebook objekt musí dát stejný token.

    Jinak se HMAC počítá z už zoscrubovaného tokenu a tatáž osoba vypadá pro
    model jako dvě různé — čímž padá důvod, proč jsou tokeny stabilní.
    """
    policy = PiiPolicy(field_category={"email": "EMAIL"})
    p = _pseudonymizer(policy)
    scalar = p.sanitize({"email": "a@b.cz"})["email"]
    codebook = p.sanitize({"email": {"id": 1, "value": "a@b.cz"}})["email"]["value"]
    assert scalar == codebook


def test_freetext_wins_over_substring_fallback():
    """`description_invoice` je volný text, ne adresa."""
    policy = PiiPolicy(
        freetext_fields=frozenset({"description_invoice"}),
        pattern_category=(("_invoice", "ADDR"),),
    )
    text = "Poznamka pro fakturu, volny text delsi nez dvadsatstyri znakov"
    out = _pseudonymizer(policy).sanitize({"description_invoice": text})
    assert out["description_invoice"] == text


def test_policy_validate_rejects_substring_shadowing_freetext():
    policy = PiiPolicy(
        freetext_fields=frozenset({"description_invoice"}),
        pattern_category=(("_invoice", "ADDR"),),
    )
    with pytest.raises(ValueError, match="description_invoice"):
        policy.validate()


@pytest.mark.parametrize("blank", ["   ", "\n\t "])
def test_blank_name_does_not_poison_known_names(blank):
    """Jméno ze samých mezer by v registru matchlo každý prázdný string."""
    policy = PiiPolicy(name_fields=frozenset({"fullname"}), propagate_known_names=True)
    p = _pseudonymizer(policy, redact_names=True)
    out = p.sanitize({"fullname": blank, "x": "", "y": "  "})
    assert out["fullname"] == blank
    assert out["x"] == ""
    assert out["y"] == "  "
    assert p._known_names == set()


def test_single_char_name_does_not_poison_known_names():
    """Jednopísmenné jméno by v registru matchlo číselníkové kódy.

    Reálný nález: osoba se jménem „A" v CRM způsobila, že se rating „A"
    všude přepsal na NAME token a statistika přestala dávat smysl. Jméno
    se dál tokenizuje — jen se nešíří na každý shodný řetězec jinde.
    """
    policy = PiiPolicy(name_fields=frozenset({"fullname"}), propagate_known_names=True)
    p = _pseudonymizer(policy, redact_names=True)
    out = p.sanitize({"fullname": "A", "rating": "A"})
    assert out["fullname"].startswith("<NAME_")
    assert out["rating"] == "A"
    assert p._known_names == set()


def test_two_char_name_still_propagates():
    """Dvouznaková jména jsou reálná (CJK) — propagace u nich zůstává."""
    policy = PiiPolicy(
        name_fields=frozenset({"fullname"}),
        freetext_fields=frozenset({"note"}),
        propagate_known_names=True,
    )
    p = _pseudonymizer(policy, redact_names=True)
    out = p.sanitize({"fullname": "齐岩", "note": "齐岩"})
    assert out["note"] == out["fullname"]


@pytest.mark.parametrize(
    ("min_len", "name", "should_propagate"),
    [(1, "A", True), (2, "A", False), (3, "Li", False), (2, "齐岩", True)],
)
def test_min_known_name_len_controls_propagation(min_len, name, should_propagate):
    """Nastavitelný práh se skutečně čte z policy, ne z konstanty."""
    policy = PiiPolicy(
        name_fields=frozenset({"fullname"}),
        freetext_fields=frozenset({"note"}),
        propagate_known_names=True,
        min_known_name_len=min_len,
    )
    p = _pseudonymizer(policy, redact_names=True)
    out = p.sanitize({"fullname": name, "note": name})
    assert out["fullname"].startswith("<NAME_")
    assert (out["note"] == out["fullname"]) is should_propagate


class _FakeOAuth:
    def __init__(self, cloud_id):
        self.cloud_id = cloud_id


@pytest.mark.parametrize("bad", [None, "", "   "])
def test_tenant_scope_rejects_missing_cloud_id(salt_env, bad):
    """`None` by prošlo jako literál 'None' — společný pseudo-tenant pro všechny."""
    from openmcp_sdk.context import Principal, RequestContext
    from openmcp_sdk.pii import scope_by_sub_and_tenant

    ctx = RequestContext(principal=Principal(sub="alice"), oauth=_FakeOAuth(bad))
    with pytest.raises(ConnectorError):
        scope_by_sub_and_tenant(ctx)
