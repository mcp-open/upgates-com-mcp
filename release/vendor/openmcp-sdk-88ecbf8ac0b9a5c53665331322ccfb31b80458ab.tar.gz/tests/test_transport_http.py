import threading

import httpx
import pytest

from openmcp_sdk.context import current_context, invalidate_current_credentials
from openmcp_sdk.envelope import ConnectorError, ErrorCode
from openmcp_sdk.identity.gateway import GatewayIdentity
from openmcp_sdk.identity.oidc import OidcIdentity
from openmcp_sdk.secrets.base import Resolved
from openmcp_sdk.transport.http import build_http_app

_INTERNAL_TOKEN = "i" * 32


def _apply_middlewares(app, middleware):
    for item in reversed(middleware or []):
        app = item.cls(app, *item.args, **item.kwargs)
    return app


class FakeCreds:
    def __init__(self):
        self.resolve_threads = []
        self.invalidated = []
        self.subjects = []

    def resolve(self, principal):
        self.resolve_threads.append(threading.get_ident())
        self.subjects.append(principal.sub)
        return Resolved({"api_key": "k"}, {"region": "cz", "_sub": principal.sub})

    def invalidate(self, sub):
        self.invalidated.append(sub)


class ConnectorCredentialFailureCreds(FakeCreds):
    def resolve(self, principal):
        del principal
        raise ConnectorError(ErrorCode.CREDENTIAL_INVALID, "provider detail")


class FakeMCP:
    auth = None

    def __init__(self):
        self.stateless_http = None

    def http_app(self, path, middleware=None, stateless_http=None):
        self.stateless_http = stateless_http

        async def app(scope, receive, send):
            if scope["path"].rstrip("/") != path.rstrip("/"):
                await send(
                    {"type": "http.response.start", "status": 404, "headers": []}
                )
                await send({"type": "http.response.body", "body": b""})
                return
            ctx = current_context()
            body = f"sub={ctx.principal.sub};key={ctx.secrets['api_key']}".encode()
            await send({"type": "http.response.start", "status": 200, "headers": []})
            await send({"type": "http.response.body", "body": body})

        return _apply_middlewares(app, middleware)


class InvalidatingMCP:
    auth = None

    def http_app(self, path, middleware=None, stateless_http=None):
        assert stateless_http is True

        async def app(scope, receive, send):
            del receive
            assert scope["path"].rstrip("/") == path.rstrip("/")
            invalidate_current_credentials()
            await send({"type": "http.response.start", "status": 200, "headers": []})
            await send({"type": "http.response.body", "body": b"invalid"})

        return _apply_middlewares(app, middleware)


def _gateway_headers(sub="u1"):
    return {
        "X-OpenMCP-Sub": sub,
        "X-OpenMCP-Gateway-Token": _INTERNAL_TOKEN,
    }


@pytest.mark.anyio
async def test_context_injected_after_gateway_proof_and_resolve_is_offloaded():
    main_thread = threading.get_ident()
    creds = FakeCreds()
    mcp = FakeMCP()
    app = build_http_app(
        mcp,
        GatewayIdentity(_INTERNAL_TOKEN),
        creds,
        allowed_origins=["https://claude.ai"],
    )
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app), base_url="http://test"
    ) as client:
        response = await client.post("/mcp", headers=_gateway_headers())
        assert response.content == b"sub=u1;key=k"
        assert (await client.get("/healthz")).json() == {"status": "ok"}
    assert creds.resolve_threads and creds.resolve_threads[0] != main_thread
    assert mcp.stateless_http is True
    with pytest.raises(ConnectorError):
        current_context()


@pytest.mark.anyio
async def test_missing_or_forged_gateway_proof_is_rejected_before_credentials():
    creds = FakeCreds()
    app = build_http_app(
        FakeMCP(),
        GatewayIdentity(_INTERNAL_TOKEN),
        creds,
        allowed_origins=["https://claude.ai"],
    )
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app), base_url="http://test"
    ) as client:
        missing = await client.post("/mcp", headers={"X-OpenMCP-Sub": "victim"})
        forged = await client.post(
            "/mcp",
            headers={
                "X-OpenMCP-Sub": "victim",
                "X-OpenMCP-Gateway-Token": "x" * 32,
            },
        )
    assert missing.status_code == forged.status_code == 403
    assert creds.resolve_threads == []


@pytest.mark.anyio
async def test_connector_credential_failure_does_not_trigger_mcp_oauth_reauthentication():
    app = build_http_app(
        FakeMCP(),
        GatewayIdentity(_INTERNAL_TOKEN),
        ConnectorCredentialFailureCreds(),
        allowed_origins=["https://claude.ai"],
    )
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app), base_url="http://test"
    ) as client:
        response = await client.post("/mcp", headers=_gateway_headers())
    assert response.status_code == 424
    assert response.json()["error"]["code"] == "credential_invalid"
    assert "provider detail" not in response.text


@pytest.mark.anyio
async def test_duplicate_trusted_identity_header_is_rejected_before_credentials():
    creds = FakeCreds()
    app = build_http_app(
        FakeMCP(),
        GatewayIdentity(_INTERNAL_TOKEN),
        creds,
        allowed_origins=["https://claude.ai"],
    )
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app), base_url="http://test"
    ) as client:
        response = await client.post(
            "/mcp",
            headers=[
                ("X-OpenMCP-Gateway-Token", _INTERNAL_TOKEN),
                ("X-OpenMCP-Sub", "u1"),
                ("X-OpenMCP-Sub", "u2"),
            ],
        )
    assert response.status_code == 403
    assert creds.resolve_threads == []


@pytest.mark.anyio
async def test_health_endpoint_bypasses_identity_and_credentials():
    creds = FakeCreds()
    app = build_http_app(
        FakeMCP(),
        GatewayIdentity(_INTERNAL_TOKEN),
        creds,
        allowed_origins=["https://claude.ai"],
    )
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app), base_url="http://test"
    ) as client:
        assert (await client.get("/healthz")).status_code == 200
    assert creds.resolve_threads == []


@pytest.mark.anyio
async def test_upstream_credential_rejection_emits_only_exact_version_health_signal():
    owner = "11111111-1111-1111-1111-111111111111"
    creds = FakeCreds()
    app = build_http_app(
        InvalidatingMCP(),
        GatewayIdentity(_INTERNAL_TOKEN),
        creds,
        allowed_origins=["https://claude.ai"],
    )
    headers = _gateway_headers(owner)
    headers.update(
        {
            "X-OpenMCP-Credential-Version": "7",
            "X-OpenMCP-Credential-Owner-Kind": "user",
            "X-OpenMCP-Credential-Owner-Id": owner,
        }
    )
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app), base_url="http://test"
    ) as client:
        response = await client.post("/mcp", headers=headers)

    assert response.status_code == 200
    assert response.headers["x-openmcp-credential-health"] == "invalid"
    assert creds.invalidated == [owner]


@pytest.mark.anyio
async def test_real_fastmcp_auth_runs_before_oidc_context_and_headers_cannot_spoof_sub():
    from fastmcp import FastMCP
    from fastmcp.server.auth.providers.jwt import JWTVerifier, RSAKeyPair

    key_pair = RSAKeyPair.generate()
    token = key_pair.create_token(
        subject="verified-user",
        issuer="https://issuer.example",
        audience="raynet",
        additional_claims={"email": "verified@example.com"},
    )
    auth = JWTVerifier(
        public_key=key_pair.public_key,
        issuer="https://issuer.example",
        audience="raynet",
    )
    creds = FakeCreds()
    app = build_http_app(
        FastMCP("auth-order"),
        OidcIdentity(
            "https://issuer.example",
            "https://issuer.example/jwks",
            "raynet",
        ),
        creds,
        allowed_origins=["https://claude.ai"],
        auth=auth,
    )
    transport = httpx.ASGITransport(app, raise_app_exceptions=False)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        await client.post(
            "/mcp",
            headers={
                "Authorization": f"Bearer {token}",
                "X-OpenMCP-Sub": "attacker-chosen-sub",
                "Content-Type": "application/json",
            },
            content="{}",
        )
        seen_after_valid = len(creds.resolve_threads)
        await client.post(
            "/mcp",
            headers={
                "Authorization": "Bearer invalid",
                "X-OpenMCP-Sub": "victim",
                "Content-Type": "application/json",
            },
            content="{}",
        )
    assert seen_after_valid == 1
    assert len(creds.resolve_threads) == 1
    assert creds.subjects == ["verified-user"]
