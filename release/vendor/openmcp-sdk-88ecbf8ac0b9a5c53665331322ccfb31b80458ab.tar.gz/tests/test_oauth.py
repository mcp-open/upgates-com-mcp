import httpx
import pytest

from openmcp_sdk.envelope import ConnectorError, ErrorCode
from openmcp_sdk.manifest import Manifest
from openmcp_sdk.oauth import DelegatedOAuthCache, DelegatedOAuthClient, build_delegated_oauth
from openmcp_sdk.providers import available_providers, get_provider
from openmcp_sdk.providers.dotykacka import DEFAULT_EXPIRES_IN, DotykackaProvider


class FakeClock:
    def __init__(self):
        self.now = 1000.0

    def __call__(self):
        return self.now


class CountingProvider:
    name = "counting"

    def __init__(self, ttl=3300):
        self.calls = 0
        self.ttl = ttl

    def exchange(self, refresh_token, cloud_id):
        self.calls += 1
        return f"token-{self.calls}-{cloud_id}", self.ttl


def test_access_token_caches_until_expiry_then_re_exchanges():
    clock = FakeClock()
    provider = CountingProvider(ttl=3300)
    client = DelegatedOAuthClient(
        provider, "refresh", "cloud-9", leeway=60, clock=clock
    )

    first = client.access_token()
    assert first == "token-1-cloud-9"
    assert provider.calls == 1
    assert client.cloud_id == "cloud-9"

    # V cachi v rámci TTL okna (3300 - 60 leeway = platné 3240s).
    clock.now += 3000
    assert client.access_token() == "token-1-cloud-9"
    assert provider.calls == 1

    # Po efektivním vypršení -> nová výměna.
    clock.now += 300
    assert client.access_token() == "token-2-cloud-9"
    assert provider.calls == 2


def test_invalidate_forces_re_exchange():
    clock = FakeClock()
    provider = CountingProvider()
    client = DelegatedOAuthClient(provider, "refresh", "c", clock=clock)

    assert client.access_token() == "token-1-c"
    client.invalidate()
    assert client.access_token() == "token-2-c"
    assert provider.calls == 2


def test_client_rejects_empty_secrets():
    provider = CountingProvider()
    with pytest.raises(ConnectorError) as error:
        DelegatedOAuthClient(provider, "", "cloud")
    assert error.value.code == ErrorCode.FORBIDDEN
    with pytest.raises(ConnectorError):
        DelegatedOAuthClient(provider, "refresh", "")


def _oauth_manifest():
    return Manifest.model_validate(
        {
            "slug": "dotykacka",
            "name": "Dotykačka",
            "version": "0.1.0",
            "auth": {
                "type": "oauth_delegated",
                "provider": "dotykacka",
                "operator_fields": [
                    {"key": "client_id"},
                    {"key": "client_secret", "secret": True},
                ],
                "runtime_secrets": ["refresh_token", "cloud_id"],
            },
        }
    )


def test_build_delegated_oauth_from_secrets():
    client = build_delegated_oauth(
        _oauth_manifest(),
        {"refresh_token": "r", "cloud_id": "c"},
    )
    assert isinstance(client, DelegatedOAuthClient)
    assert client.cloud_id == "c"
    assert client.provider_name == "dotykacka"


def test_build_delegated_oauth_none_for_credentials_manifest():
    manifest = Manifest.model_validate(
        {"slug": "demo", "name": "X", "version": "1.0.0"}
    )
    assert build_delegated_oauth(manifest, {"api_key": "k"}) is None
    assert build_delegated_oauth(None, {}) is None


def test_build_delegated_oauth_requires_runtime_secrets():
    with pytest.raises(ConnectorError) as error:
        build_delegated_oauth(_oauth_manifest(), {"refresh_token": "r"})
    assert error.value.code == ErrorCode.FORBIDDEN


def test_delegated_oauth_cache_reuses_client_without_storing_plaintext_key():
    cache = DelegatedOAuthCache(max_entries=2)
    manifest = _oauth_manifest()
    first = build_delegated_oauth(manifest, {"refresh_token": "secret-r", "cloud_id": "c"}, cache)
    second = build_delegated_oauth(manifest, {"refresh_token": "secret-r", "cloud_id": "c"}, cache)
    changed = build_delegated_oauth(manifest, {"refresh_token": "secret-r2", "cloud_id": "c"}, cache)
    assert first is second
    assert changed is not first
    assert all("secret-r" not in key for key in cache._items)


def test_delegated_oauth_cache_is_bounded():
    cache = DelegatedOAuthCache(max_entries=1)
    manifest = _oauth_manifest()
    first = build_delegated_oauth(manifest, {"refresh_token": "r1", "cloud_id": "c"}, cache)
    build_delegated_oauth(manifest, {"refresh_token": "r2", "cloud_id": "c"}, cache)
    rebuilt = build_delegated_oauth(manifest, {"refresh_token": "r1", "cloud_id": "c"}, cache)
    assert rebuilt is not first


def test_dotykacka_provider_is_registered():
    assert "dotykacka" in available_providers()
    provider = get_provider("dotykacka")
    assert provider.signin_url == "https://api.dotykacka.cz/v2/signin/token"
    assert provider.base_url == "https://api.dotykacka.cz/v2"


def test_get_provider_rejects_unknown():
    with pytest.raises(ConnectorError) as error:
        get_provider("nope")
    assert error.value.code == ErrorCode.INTERNAL


def test_dotykacka_exchange_posts_and_parses(monkeypatch):
    captured = {}

    def fake_post(url, *, headers, json, timeout):
        captured["url"] = url
        captured["headers"] = headers
        captured["json"] = json
        return httpx.Response(201, json={"accessToken": "at-123"})

    monkeypatch.setattr("openmcp_sdk.providers.dotykacka.httpx.post", fake_post)
    token, ttl = DotykackaProvider().exchange("refresh-abc", "cloud-7")

    assert token == "at-123"
    assert ttl == DEFAULT_EXPIRES_IN
    assert captured["url"] == "https://api.dotykacka.cz/v2/signin/token"
    assert captured["headers"]["Authorization"] == "User refresh-abc"
    assert captured["headers"]["Content-Type"] == "application/json"
    assert captured["json"] == {"_cloudId": "cloud-7"}


def test_dotykacka_exchange_maps_401_to_forbidden(monkeypatch):
    monkeypatch.setattr(
        "openmcp_sdk.providers.dotykacka.httpx.post",
        lambda url, **kw: httpx.Response(401, json={"error": "revoked"}),
    )
    with pytest.raises(ConnectorError) as error:
        DotykackaProvider().exchange("bad", "cloud")
    assert error.value.code == ErrorCode.FORBIDDEN


def test_dotykacka_exchange_rejects_missing_access_token(monkeypatch):
    monkeypatch.setattr(
        "openmcp_sdk.providers.dotykacka.httpx.post",
        lambda url, **kw: httpx.Response(201, json={"nope": True}),
    )
    with pytest.raises(ConnectorError) as error:
        DotykackaProvider().exchange("r", "c")
    assert error.value.code == ErrorCode.UPSTREAM_ERROR


def test_vault_resolves_runtime_secrets_for_oauth_delegated():
    from openmcp_sdk.context import Principal
    from openmcp_sdk.secrets.vault import VaultProvider

    user_id = "00000000-0000-0000-0000-000000000001"

    def read_fn(path, version):
        assert path == f"users/{user_id}/dotykacka"
        assert version == 2
        return {"refresh_token": "r-token", "cloud_id": "c-42"}

    provider = VaultProvider(
        _oauth_manifest(), addr="http://vault", role="dotykacka", read_fn=read_fn
    )
    resolved = provider.resolve(
        Principal(
            user_id,
            credential_version=2,
            credential_owner_kind="user",
            credential_owner_id=user_id,
        )
    )
    assert resolved.secrets == {"refresh_token": "r-token", "cloud_id": "c-42"}

    client = build_delegated_oauth(_oauth_manifest(), resolved.secrets)
    assert client.cloud_id == "c-42"


def test_vault_rejects_unknown_blob_keys_for_oauth_delegated():
    from openmcp_sdk.context import Principal
    from openmcp_sdk.secrets.vault import VaultProvider

    provider = VaultProvider(
        _oauth_manifest(),
        addr="http://vault",
        role="dotykacka",
        read_fn=lambda path, version: {
            "refresh_token": "r",
            "cloud_id": "c",
            "stray": "x",
        },
    )
    with pytest.raises(ConnectorError) as error:
        user_id = "00000000-0000-0000-0000-000000000001"
        provider.resolve(
            Principal(
                user_id,
                credential_version=1,
                credential_owner_kind="user",
                credential_owner_id=user_id,
            )
        )
    assert error.value.code == ErrorCode.INVALID_INPUT


def test_client_end_to_end_with_dotykacka_provider(monkeypatch):
    calls = {"n": 0}

    def fake_post(url, **kw):
        calls["n"] += 1
        return httpx.Response(201, json={"accessToken": f"at-{calls['n']}"})

    monkeypatch.setattr("openmcp_sdk.providers.dotykacka.httpx.post", fake_post)
    clock = FakeClock()
    client = DelegatedOAuthClient(
        DotykackaProvider(), "refresh", "cloud", clock=clock
    )
    assert client.access_token() == "at-1"
    assert client.access_token() == "at-1"  # z cache
    client.invalidate()
    assert client.access_token() == "at-2"
    assert calls["n"] == 2
