import textwrap

import pytest

from openmcp_sdk.cli import main

COMPLETE = """
slug: demo
name: Demo
version: 1.0.0
sdk_min_version: 0.4.0
display:
  schema_version: 1
  tools:
    - name: ping
      description: Ověří spojení
  locales:
    cs:
      name: Demo
      description: Testovací konektor
      capabilities: [Ověření spojení]
      permissions: [Pouze čtení]
      data_handling: Neukládá data.
      example_query: Ověř spojení.
      fields: []
      tools: [{name: ping, description: Ověří spojení}]
    sk:
      name: Demo
      description: Testovací konektor
      capabilities: [Overenie spojenia]
      permissions: [Iba čítanie]
      data_handling: Neukladá údaje.
      example_query: Over spojenie.
      fields: []
      tools: [{name: ping, description: Overí spojenie}]
egress:
  host: api.example.com
  port: 443
"""


def _write(tmp_path, body, name="connector.yaml"):
    path = tmp_path / name
    path.write_text(textwrap.dedent(body).lstrip(), encoding="utf-8")
    return str(path)


def test_validate_accepts_complete_manifest(tmp_path, capsys):
    assert main(["validate", _write(tmp_path, COMPLETE)]) == 0
    assert "valid: demo 1.0.0" in capsys.readouterr().out


def test_validate_reports_runtime_block(tmp_path, capsys):
    body = COMPLETE + "runtime:\n  pii_salt: true\n  vault_ttl: 5\n"
    assert main(["validate", _write(tmp_path, body)]) == 0
    out = capsys.readouterr().out
    assert "pii_salt=true" in out
    assert "vault_ttl=5" in out


def test_validate_manifest_failure(tmp_path, capsys):
    assert main(["validate", str(tmp_path / "missing.yaml")]) == 2
    assert "invalid manifest" in capsys.readouterr().err


# -- invarianty platformy ------------------------------------------------------


@pytest.mark.parametrize(
    "body,expected",
    [
        # dnešní šablona: `egress: {}` — ParseSpec ji odmítne
        ("slug: demo\nname: Demo\nversion: 1.0.0\negress: {}\n", "egress"),
        # bez display.tools operátor nezaklasifikuje policies
        (
            "slug: demo\nname: Demo\nversion: 1.0.0\n"
            "egress: {host: api.example.com, port: 443}\n",
            "display.tools",
        ),
    ],
)
def test_validate_rejects_what_platform_rejects(tmp_path, capsys, body, expected):
    """`validate` smí říct OK jen tehdy, když to platforma přijme.

    Jinak svádí důvěřovat: schéma SDK projde a API to vzápětí odmítne.
    """
    assert main(["validate", _write(tmp_path, body)]) == 2
    assert expected in capsys.readouterr().err


def test_sdk_only_skips_platform_invariants(tmp_path, capsys):
    body = "slug: demo\nname: Demo\nversion: 1.0.0\n"
    assert main(["validate", _write(tmp_path, body), "--sdk-only"]) == 0


# -- Dockerfile ↔ slug ---------------------------------------------------------


def test_validate_catches_template_dockerfile_left_behind(tmp_path, capsys):
    """Přesně ta chyba, na které padne každý scaffold ze šablony.

    Nový konektor zdědí `COPY template ./template`, build kontext ale
    adresář přejmenuje na slug — a build selže až v CI.
    """
    path = _write(tmp_path, COMPLETE)
    (tmp_path / "Dockerfile").write_text(
        "FROM python:3.13-slim\nCOPY sdk ./sdk\nCOPY template ./template\n",
        encoding="utf-8",
    )
    assert main(["validate", path]) == 2
    err = capsys.readouterr().err
    assert "Dockerfile" in err and "template" in err


def test_validate_accepts_matching_dockerfile(tmp_path, capsys):
    path = _write(tmp_path, COMPLETE)
    (tmp_path / "Dockerfile").write_text(
        "FROM python:3.13-slim\nCOPY sdk ./sdk\nCOPY demo ./demo\n",
        encoding="utf-8",
    )
    assert main(["validate", path]) == 0


def test_validate_ignores_missing_dockerfile(tmp_path):
    assert main(["validate", _write(tmp_path, COMPLETE)]) == 0


@pytest.mark.parametrize(
    "copy_line",
    [
        "COPY template ./template",
        "COPY template/ ./template/",
        "COPY --chown=10001:10001 template ./template",
        "COPY ./template ./template",
    ],
)
def test_dockerfile_check_sees_all_common_copy_forms(tmp_path, capsys, copy_line):
    """Předchozí regex tvary `--chown` a `./` přehlížel.

    Tichý falešný negativ je horší než žádná kontrola: scaffold s nezměněným
    adresářem by prošel a build spadl až v CI.
    """
    body = COMPLETE.replace("slug: demo", "slug: zasilkovna")
    path = _write(tmp_path, body)
    (tmp_path / "Dockerfile").write_text(
        f"FROM python:3.13-slim\nCOPY sdk ./sdk\n{copy_line}\n", encoding="utf-8"
    )
    assert main(["validate", path]) == 2
    assert "Dockerfile" in capsys.readouterr().err


@pytest.mark.parametrize("copy_line", ["COPY demo ./demo", "COPY demo/ ./demo/"])
def test_dockerfile_check_has_no_false_positive_on_slash(tmp_path, copy_line):
    path = _write(tmp_path, COMPLETE)
    (tmp_path / "Dockerfile").write_text(
        f"FROM python:3.13-slim\nCOPY sdk ./sdk\n{copy_line}\n", encoding="utf-8"
    )
    assert main(["validate", path]) == 0


def test_dockerfile_check_ignores_multistage_copy(tmp_path):
    path = _write(tmp_path, COMPLETE)
    (tmp_path / "Dockerfile").write_text(
        "FROM python:3.13-slim\nCOPY --from=builder /app /app\n"
        "COPY sdk ./sdk\nCOPY demo ./demo\n",
        encoding="utf-8",
    )
    assert main(["validate", path]) == 0
