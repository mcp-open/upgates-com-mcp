import pytest

from openmcp_sdk.logging import redact, safe, setup


def test_safe_masks_middle_and_zero_fully_masks():
    value = "sk-abcdef123456"
    result = safe(value)
    assert result.startswith("sk") and result.endswith("56")
    assert len(result) == len(value)
    assert safe(value, keep=0) == "*" * len(value)


def test_safe_rejects_negative_keep_and_handles_empty():
    with pytest.raises(ValueError):
        safe("secret", keep=-1)
    assert safe(None) == ""
    assert safe("") == ""


def test_redact_removes_tokens_passwords_and_emails():
    text = (
        "Authorization: Bearer abc.def api_key=secret123 user=a@b.cz password: hunter2"
    )
    result = redact(text)
    assert "abc.def" not in result
    assert "secret123" not in result
    assert "a@b.cz" not in result
    assert "hunter2" not in result
    assert "<EMAIL>" in result


@pytest.mark.parametrize(
    "text, secret",
    [
        ("Authorization: Basic dXNlcjpzdXBlci1zZWNyZXQ=", "dXNlcjpzdXBlci1zZWNyZXQ="),
        ("Authorization: User dotykacka-refresh-secret", "dotykacka-refresh-secret"),
        ("'proxy-authorization': 'Bearer proxy-secret'", "proxy-secret"),
    ],
)
def test_redact_removes_all_authorization_schemes(text, secret):
    result = redact(text)
    assert secret not in result
    assert "<redacted>" in result


def test_setup_does_not_raise():
    setup("DEBUG")


def test_setup_suppresses_http_client_urls_with_query_pii():
    setup("DEBUG")
    assert __import__("logging").getLogger("httpx").getEffectiveLevel() >= 30
    assert __import__("logging").getLogger("httpcore").getEffectiveLevel() >= 30
