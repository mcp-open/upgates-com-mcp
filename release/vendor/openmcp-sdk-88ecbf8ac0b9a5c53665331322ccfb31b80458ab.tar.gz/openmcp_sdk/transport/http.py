"""Zabezpečený Streamable HTTP transport pro OpenMCP connectory."""

from __future__ import annotations

import inspect
import json
import logging
from collections.abc import Awaitable, Callable, Mapping
from functools import partial
from secrets import compare_digest
from typing import Any

from pydantic import BaseModel, ConfigDict, ValidationError
from starlette.applications import Starlette
from starlette.concurrency import run_in_threadpool
from starlette.middleware import Middleware
from starlette.middleware.cors import CORSMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Mount, Route

from openmcp_sdk.context import (
    AccessPolicy,
    Principal,
    RequestContext,
    reset_context,
    set_context,
)
from openmcp_sdk.envelope import ConnectorError, ErrorCode
from openmcp_sdk.manifest import SERVED_HEALTH_PATHS, Manifest
from openmcp_sdk.oauth import DelegatedOAuthCache, build_delegated_oauth
from openmcp_sdk.secrets.base import Resolved, resolve_fields

logger = logging.getLogger(__name__)

_STATUS_BY_CODE: dict[ErrorCode, int] = {
    ErrorCode.FORBIDDEN: 403,
    ErrorCode.INVALID_INPUT: 400,
    ErrorCode.NOT_FOUND: 404,
    ErrorCode.CREDENTIAL_INVALID: 401,
    ErrorCode.INSTANCE_UNKNOWN: 404,
    ErrorCode.PROVIDER_PERMISSION_DENIED: 403,
    ErrorCode.RATE_LIMITED: 429,
    ErrorCode.UPSTREAM_UNAVAILABLE: 503,
    ErrorCode.UPSTREAM_ERROR: 502,
    ErrorCode.INTERNAL: 500,
}
# A 401 on the MCP data plane asks remote clients to repeat OAuth. Connector
# credential/config failures are a dependency problem, not a client-session
# authentication failure, so they must never trigger that re-authentication.
_MCP_CONTEXT_STATUS_BY_CODE: dict[ErrorCode, int] = {
    **_STATUS_BY_CODE,
    ErrorCode.CREDENTIAL_INVALID: 424,
    ErrorCode.INSTANCE_UNKNOWN: 424,
    ErrorCode.PROVIDER_PERMISSION_DENIED: 424,
}


def _mcp_context_message(code: ErrorCode) -> str:
    """Return fixed data-plane copy; provider/Vault details never cross."""

    if code in {
        ErrorCode.CREDENTIAL_INVALID,
        ErrorCode.INSTANCE_UNKNOWN,
        ErrorCode.PROVIDER_PERMISSION_DENIED,
    }:
        return "přístup konektoru není dostupný"
    if code is ErrorCode.FORBIDDEN:
        return "požadavek není povolený"
    if code is ErrorCode.INVALID_INPUT:
        return "kontext požadavku je neplatný"
    return "kontext požadavku se nedá připravit"
_TEST_TOKEN_HEADER = "x-openmcp-test-token"
_PUBLIC_SAFE_TEST_TOKEN_HEADER = "x-openmcp-public-safe-test-token"
_MAX_TEST_BODY_BYTES = 64 * 1024
_TRUSTED_SINGLETON_HEADERS = frozenset(
    {
        "authorization",
        "x-openmcp-gateway-token",
        "x-openmcp-sub",
        "x-openmcp-credential-version",
        "x-openmcp-credential-owner-kind",
        "x-openmcp-credential-owner-id",
        "x-openmcp-policy-mode",
        "x-openmcp-policy-tools",
        "x-openmcp-policy-approval",
        "x-openmcp-test-token",
        "x-openmcp-public-safe-test-token",
    }
)


def _has_duplicate_trusted_headers(scope: Mapping[str, Any]) -> bool:
    """Reject ambiguous identity/auth headers before converting them to a map."""

    seen: set[str] = set()
    for raw_name, _ in scope.get("headers", []):
        name = raw_name.decode("latin-1").lower()
        if name not in _TRUSTED_SINGLETON_HEADERS:
            continue
        if name in seen:
            return True
        seen.add(name)
    return False


def _has_request_input(request: Request) -> bool:
    """Internal safe tests are header-only and never accept customer input."""

    content_length = request.headers.get("content-length")
    return bool(
        request.url.query
        or request.headers.get("transfer-encoding") is not None
        or content_length not in (None, "0")
    )


async def _resolve_credentials(creds: Any, principal: Principal) -> Resolved:
    resolve = creds.resolve
    if inspect.iscoroutinefunction(resolve):
        result = await resolve(principal)
    else:
        result = await run_in_threadpool(resolve, principal)
    if inspect.isawaitable(result):
        result = await result
    if not isinstance(result, Resolved):
        raise ConnectorError(
            ErrorCode.INTERNAL, "credential provider vrátil neplatný výsledek"
        )
    return result


class ContextMiddleware:
    """Vloží neměnný request context výhradně pro MCP endpoint.

    FastMCP instaluje tento middleware *až po* AuthenticationMiddleware a
    AuthContextMiddleware. OidcIdentity proto může číst ověřené claims
    z access tokenu, zatímco veřejné OAuth metadata routes zůstávají mimo
    tento context.
    """

    def __init__(
        self,
        app: Any,
        identity: Any,
        creds: Any,
        protected_path: str,
        manifest: Manifest | None = None,
    ) -> None:
        self.app = app
        self.identity = identity
        self.creds = creds
        self.manifest = manifest
        self.protected_path = protected_path.rstrip("/") or "/"
        self.oauth_cache = DelegatedOAuthCache()

    async def __call__(self, scope: dict[str, Any], receive: Any, send: Any) -> None:
        path = (scope.get("path") or "").rstrip("/") or "/"
        if scope.get("type") != "http" or path != self.protected_path:
            await self.app(scope, receive, send)
            return

        headers: Mapping[str, str] = {
            key.decode("latin-1").lower(): value.decode("latin-1")
            for key, value in scope.get("headers", [])
        }
        try:
            if _has_duplicate_trusted_headers(scope):
                raise ConnectorError(
                    ErrorCode.FORBIDDEN, "duplicitní důvěryhodná hlavička"
                )
            principal = self.identity.principal_from_headers(headers)
            resolved = await _resolve_credentials(self.creds, principal)
            oauth = build_delegated_oauth(self.manifest, resolved.secrets, self.oauth_cache)
        except ConnectorError as exc:
            response = JSONResponse(
                {
                    "error": {
                        "code": exc.code.value,
                        "message": _mcp_context_message(exc.code),
                    }
                },
                status_code=_MCP_CONTEXT_STATUS_BY_CODE.get(exc.code, 500),
            )
            await response(scope, receive, send)
            return
        except Exception:
            # Provider exceptions can include response content. The bounded
            # request ID is enough to correlate an internal initialization
            # failure without persisting a possibly secret-bearing traceback.
            logger.error("inicializace request contextu selhala")
            response = JSONResponse(
                {
                    "error": {
                        "code": ErrorCode.INTERNAL.value,
                        "message": "kontext se nedá připravit",
                    }
                },
                status_code=500,
            )
            await response(scope, receive, send)
            return

        invalidate_principal = getattr(self.creds, "invalidate_principal", None)
        invalidate = getattr(self.creds, "invalidate", None)
        if callable(invalidate_principal):
            callback = partial(invalidate_principal, principal)
        else:
            callback = partial(invalidate, principal.sub) if callable(invalidate) else None

        # Upstream 401 is observed inside the connector process. Propagate only
        # a one-bit, metadata-only signal on the internal gateway response; the
        # gateway binds it to the exact owner/version it supplied and performs
        # the durable state change. No provider body, token or actor value is
        # copied into this signal.
        credential_invalid = False

        def invalidate_and_signal() -> None:
            nonlocal credential_invalid
            credential_invalid = True
            if callback is not None:
                callback()

        async def health_send(message: dict[str, Any]) -> None:
            if (
                message.get("type") == "http.response.start"
                and credential_invalid
                and principal.credential_version is not None
            ):
                headers = [
                    (name, value)
                    for name, value in message.get("headers", [])
                    if name.lower() != b"x-openmcp-credential-health"
                ]
                headers.append((b"x-openmcp-credential-health", b"invalid"))
                message = {**message, "headers": headers}
            await send(message)

        token = set_context(
            RequestContext(
                principal,
                resolved.secrets,
                resolved.config,
                invalidate_credentials=invalidate_and_signal,
                request_id=_request_id(scope),
                policy=_request_policy(
                    headers, default_read_only=bool(resolved.config.get("read_only", True))
                ),
                oauth=oauth,
            )
        )
        try:
            await self.app(scope, receive, health_send)
        finally:
            reset_context(token)


def _request_id(scope: Mapping[str, Any]) -> str:
    """Vrátí omezené caller ID, nebo pro trace korelaci vygeneruje nové."""

    from uuid import uuid4

    for key, value in scope.get("headers", []):
        if key.lower() == b"x-request-id":
            candidate = value.decode("latin-1").strip()
            if 1 <= len(candidate) <= 128 and all(
                char.isalnum() or char in "._:-" for char in candidate
            ):
                return candidate
            break
    return uuid4().hex


def _request_policy(
    headers: Mapping[str, str], *, default_read_only: bool = True
) -> AccessPolicy:
    """Parsuje gateway policy headers; chybná nebo chybějící policy je read-only."""

    mode = headers.get(
        "x-openmcp-policy-mode", "read_only" if default_read_only else "allow_write"
    )
    if mode not in {"read_only", "allow_write", "approval_required", "disabled"}:
        mode = "read_only"
    raw_tools = headers.get("x-openmcp-policy-tools", "")
    tools = frozenset(
        item.strip()
        for item in raw_tools.split(",")
        if item.strip() and len(item.strip()) <= 128
    )
    return AccessPolicy(
        mode=mode,
        allowed_tools=tools,
        require_approval=headers.get("x-openmcp-policy-approval", "false").lower()
        == "true",
    )


async def _healthz(request: Request) -> JSONResponse:
    del request
    return JSONResponse({"status": "ok"})


class _TestPayload(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    secrets: dict[str, str]
    config: dict[str, Any]


async def _read_test_payload(request: Request) -> _TestPayload:
    data = bytearray()
    async for chunk in request.stream():
        if len(data) + len(chunk) > _MAX_TEST_BODY_BYTES:
            raise ConnectorError(
                ErrorCode.INVALID_INPUT, "test payload je příliš velký"
            )
        data.extend(chunk)
    try:
        raw = json.loads(data)
        return _TestPayload.model_validate(raw)
    except (
        json.JSONDecodeError,
        UnicodeDecodeError,
        ValidationError,
        TypeError,
    ) as exc:
        raise ConnectorError(ErrorCode.INVALID_INPUT, "neplatný test payload") from exc


async def _invoke_test_connection(
    callback: Callable[[], str | Awaitable[str]],
) -> str:
    if inspect.iscoroutinefunction(callback):
        result = await callback()
    else:
        result = await run_in_threadpool(callback)
    if inspect.isawaitable(result):
        result = await result
    if not isinstance(result, str) or not result.strip():
        raise TypeError("test_connection musí vrátit neprázdný string")
    return result


def _make_test_endpoint(
    test_connection: Callable[[], str | Awaitable[str]],
    manifest: Manifest,
    auth_token: str,
    operator_env: Mapping[str, str] | None,
):
    secret_keys = {field.key for field in manifest.credentials if field.secret}
    secret_keys |= set(manifest.auth.runtime_secrets)
    config_keys = {
        field.key
        for field in manifest.credentials + manifest.user_config
        if not field.secret
    }

    async def _test(request: Request) -> JSONResponse:
        if _has_duplicate_trusted_headers(request.scope):
            return JSONResponse(
                {"ok": False, "code": ErrorCode.FORBIDDEN.value, "message": "zakázáno"},
                status_code=403,
            )
        supplied_token = request.headers.get(_TEST_TOKEN_HEADER, "")
        if not compare_digest(supplied_token, auth_token):
            return JSONResponse(
                {"ok": False, "code": ErrorCode.FORBIDDEN.value, "message": "zakázáno"},
                status_code=403,
            )
        try:
            payload = await _read_test_payload(request)
            duplicate = set(payload.secrets) & set(payload.config)
            misplaced = (set(payload.secrets) - secret_keys) | (
                set(payload.config) - config_keys
            )
            if duplicate or misplaced:
                raise ConnectorError(
                    ErrorCode.INVALID_INPUT,
                    "test payload nesprávně rozděluje secrets a config",
                )
            values: dict[str, Any] = {**payload.config, **payload.secrets}
            resolved = resolve_fields(
                manifest,
                values,
                environ=operator_env,
                reject_unknown=True,
                location="test payload",
            )
        except ConnectorError as exc:
            return JSONResponse(
                {"ok": False, "code": exc.code.value, "message": exc.message},
                status_code=_STATUS_BY_CODE.get(exc.code, 400),
            )

        context_token = set_context(
            RequestContext(
                Principal("test"),
                resolved.secrets,
                resolved.config,
                oauth=build_delegated_oauth(manifest, resolved.secrets),
            )
        )
        try:
            message = await _invoke_test_connection(test_connection)
        except ConnectorError as exc:
            return JSONResponse(
                {"ok": False, "code": exc.code.value, "message": exc.message}
            )
        except Exception:
            logger.error("test callback connectoru selhal")
            return JSONResponse(
                {
                    "ok": False,
                    "code": ErrorCode.INTERNAL.value,
                    "message": "test spojení selhal",
                },
                status_code=500,
            )
        finally:
            reset_context(context_token)
        return JSONResponse({"ok": True, "message": message})

    return _test


def _make_credential_version_test_endpoint(
    identity: Any,
    creds: Any,
    manifest: Manifest,
    auth_token: str,
    test_connection: Callable[[], str | Awaitable[str]] | None,
):
    """Build the secret-free control-plane safe-test endpoint.

    The API supplies only a trusted subject and an explicit published/staged
    Vault KV v2 version. The connector resolves that exact version itself, so
    neither the credential nor a ``latest`` read crosses the API boundary.
    """

    async def _credential_test(request: Request) -> JSONResponse:
        if _has_duplicate_trusted_headers(request.scope):
            return JSONResponse(
                {"ok": False, "code": ErrorCode.FORBIDDEN.value, "message": "zakázáno"},
                status_code=403,
            )
        supplied_token = request.headers.get(_TEST_TOKEN_HEADER, "")
        if not compare_digest(supplied_token, auth_token):
            return JSONResponse(
                {"ok": False, "code": ErrorCode.FORBIDDEN.value, "message": "zakázáno"},
                status_code=403,
            )
        if _has_request_input(request):
            return JSONResponse(
                {
                    "ok": False,
                    "code": ErrorCode.INVALID_INPUT.value,
                    "message": "test nepřijímá vstupní data",
                },
                status_code=400,
            )
        try:
            principal = identity.principal_from_headers(request.headers)
            resolved = await _resolve_credentials(creds, principal)
            oauth = build_delegated_oauth(
                manifest, resolved.secrets, DelegatedOAuthCache()
            )
        except ConnectorError as exc:
            return JSONResponse(
                {"ok": False, "code": exc.code.value, "message": exc.message},
                status_code=_STATUS_BY_CODE.get(exc.code, 500),
            )
        except Exception:
            logger.error("exact credential safe-test initialization failed")
            return JSONResponse(
                {
                    "ok": False,
                    "code": ErrorCode.INTERNAL.value,
                    "message": "test přihlašovacích údajů selhal",
                },
                status_code=500,
            )

        context_token = set_context(
            RequestContext(
                principal,
                resolved.secrets,
                resolved.config,
                oauth=oauth,
            )
        )
        try:
            message = (
                await _invoke_test_connection(test_connection)
                if test_connection is not None
                else "Přihlašovací údaje byly bezpečně načteny"
            )
        except ConnectorError as exc:
            return JSONResponse(
                {"ok": False, "code": exc.code.value, "message": exc.message}
            )
        except Exception:
            logger.error("exact credential safe-test callback failed")
            return JSONResponse(
                {
                    "ok": False,
                    "code": ErrorCode.INTERNAL.value,
                    "message": "test přihlašovacích údajů selhal",
                },
                status_code=500,
            )
        finally:
            reset_context(context_token)
        return JSONResponse({"ok": True, "message": message})

    return _credential_test


async def _invoke_public_safe_test(callback: Callable[[], Any]) -> None:
    if inspect.iscoroutinefunction(callback):
        result = await callback()
    else:
        result = await run_in_threadpool(callback)
    if inspect.isawaitable(result):
        await result


def _public_safe_reason(code: ErrorCode) -> str:
    return {
        ErrorCode.RATE_LIMITED: "provider_rate_limited",
        ErrorCode.UPSTREAM_UNAVAILABLE: "provider_unavailable",
        ErrorCode.UPSTREAM_ERROR: "provider_unavailable",
        ErrorCode.INVALID_INPUT: "runtime_unavailable",
        ErrorCode.NOT_FOUND: "safe_test_unavailable",
        ErrorCode.CREDENTIAL_INVALID: "safe_test_unavailable",
        ErrorCode.INSTANCE_UNKNOWN: "safe_test_unavailable",
        ErrorCode.PROVIDER_PERMISSION_DENIED: "safe_test_unavailable",
        ErrorCode.INTERNAL: "runtime_unavailable",
        ErrorCode.FORBIDDEN: "safe_test_unavailable",
    }[code]


def _make_public_safe_test_endpoint(
    callback: Callable[[], Any],
    auth_token: str,
):
    """Build a no-input synthetic test endpoint for public connectors.

    The connector callback owns the fixed public fixture. Neither request data
    nor provider output is accepted/returned, so this endpoint cannot become a
    generic tool-call proxy or an evidence-content side channel.
    """

    async def _public_safe_test(request: Request) -> JSONResponse:
        if _has_duplicate_trusted_headers(request.scope):
            return JSONResponse(
                {"ok": False, "code": "safe_test_unavailable"},
                status_code=403,
            )
        supplied_token = request.headers.get(_PUBLIC_SAFE_TEST_TOKEN_HEADER, "")
        if not compare_digest(supplied_token, auth_token):
            return JSONResponse(
                {"ok": False, "code": "safe_test_unavailable"},
                status_code=403,
            )
        if _has_request_input(request):
            return JSONResponse(
                {"ok": False, "code": "invalid_request"},
                status_code=400,
            )
        try:
            await _invoke_public_safe_test(callback)
        except ConnectorError as exc:
            return JSONResponse(
                {"ok": False, "code": _public_safe_reason(exc.code)},
                status_code=_STATUS_BY_CODE.get(exc.code, 500),
            )
        except Exception:
            # Deliberately omit exception text/trace: a provider exception can
            # carry response content and this synthetic path stores no raw data.
            logger.error("public connector safe-test failed")
            return JSONResponse(
                {"ok": False, "code": "runtime_unavailable"},
                status_code=500,
            )
        return JSONResponse({"ok": True, "code": "safe_test_passed"})

    return _public_safe_test


def build_http_app(
    mcp: Any,
    identity: Any,
    creds: Any,
    allowed_origins: list[str],
    *,
    auth: Any = None,
    test_connection: Callable[[], str | Awaitable[str]] | None = None,
    manifest: Manifest | None = None,
    test_auth_token: str | None = None,
    operator_env: Mapping[str, str] | None = None,
    credential_version_test: bool = False,
    public_safe_test: Callable[[], Any] | None = None,
    public_safe_test_token: str | None = None,
):
    # Hosted credential testing is Vault-version-only. Never mount the legacy
    # raw `{secrets, config}` endpoint alongside the exact-version endpoint.
    if test_connection is not None and not credential_version_test:
        if manifest is None:
            raise ValueError("manifest je povinný pro test endpoint")
        if test_auth_token is None or len(test_auth_token) < 32:
            raise ValueError("test_auth_token musí mít alespoň 32 znaků")
    if credential_version_test:
        if manifest is None:
            raise ValueError("manifest je povinný pro exact credential test")
        if test_auth_token is None or len(test_auth_token) < 32:
            raise ValueError("test_auth_token musí mít alespoň 32 znaků")
    if public_safe_test is not None and (
        public_safe_test_token is None or len(public_safe_test_token) < 32
    ):
        raise ValueError("public_safe_test_token musí mít alespoň 32 znaků")

    if auth is not None:
        mcp.auth = auth

    context_middleware = Middleware(
        ContextMiddleware,
        identity=identity,
        creds=creds,
        protected_path="/mcp",
        manifest=manifest,
    )
    # Hosted connectors run behind a Kubernetes Service with multiple replicas.
    # FastMCP's default Streamable HTTP mode keeps the MCP session in process,
    # so a follow-up request routed to another pod fails with 404. The gateway
    # performs a fresh upstream handshake for every tool call and does not need
    # server-side session state; make that deployment contract explicit.
    mcp_app = mcp.http_app(
        path="/mcp",
        middleware=[context_middleware],
        stateless_http=True,
    )

    # Jediný zdroj pravdy sdílený s `manifest.Runtime.health_path` — validátor
    # manifestu odmítne cestu, kterou tu neservírujeme.
    routes: list[Any] = [
        Route(path, _healthz, methods=["GET"]) for path in sorted(SERVED_HEALTH_PATHS)
    ]
    if test_connection is not None and not credential_version_test:
        routes.append(
            Route(
                "/test",
                _make_test_endpoint(
                    test_connection,
                    manifest,
                    test_auth_token,
                    operator_env,
                ),
                methods=["POST"],
            )
        )
    if credential_version_test:
        routes.append(
            Route(
                "/internal/credential-test",
                _make_credential_version_test_endpoint(
                    identity,
                    creds,
                    manifest,
                    test_auth_token,
                    test_connection,
                ),
                methods=["POST"],
            )
        )
    if public_safe_test is not None:
        # Startup validation above guarantees this; keep the local narrowing so
        # future route refactors cannot accidentally mount an unauthenticated
        # endpoint and static type checkers see a concrete token.
        if public_safe_test_token is None:
            raise RuntimeError("public safe-test token validation was bypassed")
        routes.append(
            Route(
                "/internal/public-safe-test",
                _make_public_safe_test_endpoint(
                    public_safe_test,
                    public_safe_test_token,
                ),
                methods=["POST"],
            )
        )
    routes.append(Mount("/", app=mcp_app))

    lifespan = getattr(mcp_app, "lifespan", None)
    app = (
        Starlette(routes=routes, lifespan=lifespan)
        if lifespan is not None
        else Starlette(routes=routes)
    )
    return CORSMiddleware(
        app,
        allow_origins=allowed_origins,
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=[
            "authorization",
            "content-type",
            "mcp-protocol-version",
            "mcp-session-id",
        ],
        expose_headers=["mcp-session-id"],
    )
