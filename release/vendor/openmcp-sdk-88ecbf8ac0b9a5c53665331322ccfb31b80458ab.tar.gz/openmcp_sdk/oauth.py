"""Klient pro delegovaný OAuth access token.

:class:`DelegatedOAuthClient` obaluje per-user refresh token a
:class:`~openmcp_sdk.providers.Provider`. Refresh token líně vymění za
krátkodobý upstream access token a v paměti si ho drží v cache až do doby
těsně před vypršením. Connector nástroje ho získají přes
``current_context().oauth``::

    ctx = current_context()
    token = ctx.oauth.access_token()
    cloud = ctx.oauth.cloud_id
    ...  # Authorization: Bearer {token}

Při upstream 401 by měl nástroj zavolat ``ctx.oauth.invalidate()``, aby se při
dalším volání token znovu vyměnil. Klient je thread-safe: probíhající výměna
je serializovaná, takže souběžná volání nástrojů nikdy nespustí stampede
tokenů.
"""

from __future__ import annotations

import threading
import time
import hashlib
from collections import OrderedDict
from collections.abc import Callable

from openmcp_sdk.envelope import ConnectorError, ErrorCode
from openmcp_sdk.manifest import Manifest
from openmcp_sdk.providers import Provider, get_provider

#: O kolik sekund předem obnovit token před nahlášeným vypršením, aby se
#: absorbovala odchylka hodin a latence requestu.
DEFAULT_LEEWAY = 60


class DelegatedOAuthCache:
    """Omezená procesová cache OAuth klientů podle credentials.

    HTTP request kontexty jsou krátkodobé, zatímco upstream access tokeny žijí
    asi hodinu. Znovupoužití klienta zabrání jedné výměně refresh tokenu na
    každé volání MCP nástroje. Klíče obsahují jen digest, nikdy samotný
    refresh token.
    """

    def __init__(
        self,
        *,
        max_entries: int = 1024,
        idle_ttl: float = 3600,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self._max_entries = max(1, int(max_entries))
        self._idle_ttl = max(float(idle_ttl), 1.0)
        self._clock = clock
        self._lock = threading.Lock()
        self._items: OrderedDict[str, tuple[float, DelegatedOAuthClient]] = OrderedDict()

    def get(self, provider: Provider, refresh_token: str, cloud_id: str) -> "DelegatedOAuthClient":
        digest = hashlib.sha256(
            f"{provider.name}\0{cloud_id}\0{refresh_token}".encode("utf-8")
        ).hexdigest()
        now = self._clock()
        with self._lock:
            expired = [key for key, (used, _) in self._items.items() if now - used >= self._idle_ttl]
            for key in expired:
                self._items.pop(key, None)
            hit = self._items.pop(digest, None)
            if hit is not None:
                client = hit[1]
                self._items[digest] = (now, client)
                return client
            client = DelegatedOAuthClient(provider, refresh_token, cloud_id)
            self._items[digest] = (now, client)
            while len(self._items) > self._max_entries:
                self._items.popitem(last=False)
            return client


class DelegatedOAuthClient:
    def __init__(
        self,
        provider: Provider,
        refresh_token: str,
        cloud_id: str,
        *,
        leeway: float = DEFAULT_LEEWAY,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        if not refresh_token:
            raise ConnectorError(ErrorCode.FORBIDDEN, "chybí delegovaný refresh token")
        if not cloud_id:
            raise ConnectorError(ErrorCode.FORBIDDEN, "chybí delegovaný cloud_id")
        self._provider = provider
        self._refresh_token = refresh_token
        self._cloud_id = cloud_id
        self._leeway = max(float(leeway), 0.0)
        self._clock = clock
        self._lock = threading.Lock()
        self._token: str | None = None
        self._expires_at = 0.0

    @property
    def cloud_id(self) -> str:
        return self._cloud_id

    @property
    def provider_name(self) -> str:
        return self._provider.name

    def access_token(self) -> str:
        """Vrať platný access token — líně jej vymění a při zásahu vrátí z cache."""

        with self._lock:
            now = self._clock()
            if self._token is not None and now < self._expires_at:
                return self._token
            token, expires_in = self._provider.exchange(
                self._refresh_token, self._cloud_id
            )
            if not isinstance(token, str) or not token:
                raise ConnectorError(
                    ErrorCode.UPSTREAM_ERROR, "OAuth exchange nevrátil access token"
                )
            self._token = token
            self._expires_at = now + max(float(expires_in) - self._leeway, 0.0)
            return token

    def invalidate(self) -> None:
        """Zahoď token uložený v cache; další volání ho znovu vymění. Idempotentní."""

        with self._lock:
            self._token = None
            self._expires_at = 0.0


def build_delegated_oauth(
    manifest: Manifest | None,
    secrets: object,
    cache: DelegatedOAuthCache | None = None,
) -> DelegatedOAuthClient | None:
    """Vytvoř klienta pro oauth_delegated konektory, jinak ``None``.

    ``secrets`` je vyřešené mapování secrets pro daný request. U delegated-OAuth
    konektoru nese runtime secrets, které platforma zapsala do per-user Vault
    blobu (``refresh_token`` + ``cloud_id``).
    """

    if manifest is None or manifest.auth.type != "oauth_delegated":
        return None
    provider = get_provider(manifest.auth.provider)
    mapping = secrets if hasattr(secrets, "get") else {}
    refresh_token = mapping.get("refresh_token")  # type: ignore[union-attr]
    cloud_id = mapping.get("cloud_id")  # type: ignore[union-attr]
    if not isinstance(refresh_token, str) or not refresh_token:
        raise ConnectorError(ErrorCode.FORBIDDEN, "chybí delegovaný refresh token")
    if not isinstance(cloud_id, str) or not cloud_id:
        raise ConnectorError(ErrorCode.FORBIDDEN, "chybí delegovaný cloud_id")
    if cache is not None:
        return cache.get(provider, refresh_token, cloud_id)
    return DelegatedOAuthClient(provider, refresh_token, cloud_id)
