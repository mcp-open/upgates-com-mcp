"""Hostovaný poskytovatel přihlašovacích údajů, podložený HashiCorp Vault KV v2."""

from __future__ import annotations

from collections.abc import Callable, Mapping
import asyncio
import os
import threading
import time
from typing import Any
from urllib.parse import urlsplit

from openmcp_sdk.context import Principal
from openmcp_sdk.envelope import ConnectorError, ErrorCode
from openmcp_sdk.manifest import Manifest
from openmcp_sdk.secrets.base import Resolved, resolve_fields
from openmcp_sdk.secrets.cache import TTLCache

DEFAULT_TOKEN_PATH = "/var/run/secrets/kubernetes.io/serviceaccount/token"


class VaultProvider:
    def __init__(
        self,
        manifest: Manifest,
        addr: str,
        role: str,
        mount: str = "secret",
        ttl: float = 60,
        token_path: str = DEFAULT_TOKEN_PATH,
        login_fn: Callable[[], str] | None = None,
        read_fn: Callable[[str, int], dict[str, Any]] | None = None,
        environ: Mapping[str, str] | None = None,
        max_cache_entries: int = 1024,
        timeout: float = 10.0,
        ca_cert: str | None = None,
        require_https: bool = False,
        max_retries: int = 2,
        retry_backoff: float = 0.1,
        circuit_failure_threshold: int = 5,
        circuit_reset_timeout: float = 30.0,
    ) -> None:
        if not addr or not role or not mount:
            raise ValueError("Vault addr, role a mount nesmí být prázdné")
        if ttl < 0:
            raise ValueError("Vault TTL nesmí být záporné")
        if timeout <= 0:
            raise ValueError("Vault timeout musí být kladný")
        if max_retries < 0 or retry_backoff < 0:
            raise ValueError("Vault retry nastavení je neplatné")
        if circuit_failure_threshold < 1 or circuit_reset_timeout <= 0:
            raise ValueError("Vault circuit breaker nastavení je neplatné")
        if not isinstance(require_https, bool):
            raise ValueError("Vault require_https musí být boolean")
        parsed_addr = self._validate_addr(addr, require_https=require_https)
        if ca_cert is not None:
            if not isinstance(ca_cert, str) or not ca_cert.strip():
                raise ValueError("Vault CA certifikát musí být neprázdná cesta")
            if ca_cert != ca_cert.strip() or not os.path.isabs(ca_cert):
                raise ValueError("Vault CA certifikát musí být absolutní cesta")
            if not os.path.isfile(ca_cert) or not os.access(ca_cert, os.R_OK):
                raise ValueError("Vault CA certifikát neexistuje nebo není čitelný")
            if parsed_addr.scheme != "https":
                raise ValueError("Vault CA certifikát lze použít jen s https://")
        if (
            require_https
            and parsed_addr.hostname is not None
            and (
                parsed_addr.hostname.endswith(".svc")
                or ".svc." in parsed_addr.hostname
            )
            and ca_cert is None
        ):
            raise ValueError("interní Vault HTTPS vyžaduje explicitní CA certifikát")
        self._manifest = manifest
        self._addr = addr
        self._role = role
        self._mount = mount
        self._ttl = ttl
        self._token_path = token_path
        self._login_fn = login_fn or self._default_login
        self._read_fn = read_fn or self._default_read
        self._environ = environ
        self._timeout = timeout
        self._ca_cert = ca_cert
        self._max_retries = max_retries
        self._retry_backoff = retry_backoff
        self._circuit_failure_threshold = circuit_failure_threshold
        self._circuit_reset_timeout = circuit_reset_timeout
        self._circuit_failures = 0
        self._circuit_opened_at = 0.0
        self._circuit_lock = threading.Lock()
        self._cache: TTLCache[Resolved] = TTLCache(max_entries=max_cache_entries)

    @staticmethod
    def _validate_addr(addr: str, *, require_https: bool):
        """Validate the Vault origin before a workload JWT can leave the pod.

        ``hvac`` accepts URLs containing userinfo, paths and query strings.  A
        typo in a production manifest could therefore send the Kubernetes
        service-account JWT to an unintended endpoint.  Keep HTTP available
        only for an explicitly coordinated migration window; production sets
        ``VAULT_REQUIRE_HTTPS=true``.
        """

        if not isinstance(addr, str) or addr != addr.strip() or any(
            ord(char) < 32 or ord(char) == 127 for char in addr
        ):
            raise ValueError("Vault addr obsahuje neplatné mezery nebo řídicí znaky")
        parsed = urlsplit(addr)
        try:
            port = parsed.port
        except ValueError as exc:
            raise ValueError("Vault addr obsahuje neplatný port") from exc
        del port
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            raise ValueError("Vault addr musí být absolutní http(s) origin")
        if parsed.username is not None or parsed.password is not None:
            raise ValueError("Vault addr nesmí obsahovat přihlašovací údaje")
        if parsed.path not in {"", "/"} or parsed.query or parsed.fragment:
            raise ValueError("Vault addr nesmí obsahovat cestu, query ani fragment")
        if require_https and parsed.scheme != "https":
            raise ValueError("VAULT_REQUIRE_HTTPS vyžaduje Vault addr s https://")
        return parsed

    def _default_login(self) -> str:
        import hvac

        with open(self._token_path, encoding="utf-8") as file:
            jwt = file.read().strip()
        if not jwt:
            raise RuntimeError("prázdný Kubernetes service-account token")
        client = hvac.Client(**self._client_kwargs())
        client.auth.kubernetes.login(role=self._role, jwt=jwt)
        token = client.token
        if not token:
            raise RuntimeError("Vault login nevrátil token")
        return token

    def _default_read(self, path: str, version: int) -> dict[str, Any]:
        import hvac

        # Krátkodobé přihlášení při každém cache miss záměrně zabraňuje
        # udržování procesně sdíleného Vault tokenu. HTTP transport spouští
        # tuto metodu ve worker threadu, aby se neblokoval async event loop.
        token = self._login_fn()
        client = hvac.Client(**self._client_kwargs(token=token))
        response = client.secrets.kv.v2.read_secret_version(
            path=path, version=version, mount_point=self._mount
        )
        data = response.get("data", {}).get("data")
        if not isinstance(data, dict):
            raise RuntimeError("Vault odpověď nemá KV data")
        return data

    def _client_kwargs(self, *, token: str | None = None) -> dict[str, Any]:
        """Sestaví fail-safe hvac transport options pro každý Vault request.

        Requests defaultně ověřuje veřejné CA. ``VAULT_CACERT`` dodává
        soukromý CA bundle použitý in-cluster Vault TLS listenerem; SDK
        nemá přepínač, který by vypnul ověřování certifikátu nebo hostname.
        """
        options: dict[str, Any] = {
            "url": self._addr,
            "timeout": self._timeout,
            "verify": self._ca_cert or True,
        }
        if token is not None:
            options["token"] = token
        return options

    def _load(self, principal: Principal) -> Resolved:
        if principal.credential_version is None:
            # Never read Vault's implicit latest version. It may be a pending
            # rotation that has not passed safe-test or DB publication.
            raise ConnectorError(
                ErrorCode.FORBIDDEN,
                "chybí publikovaná verze přihlašovacích údajů",
            )
        if principal.credential_owner_kind is None or principal.credential_owner_id is None:
            raise ConnectorError(
                ErrorCode.FORBIDDEN, "chybí vlastník přihlašovacích údajů"
            )
        owner_prefix = "users" if principal.credential_owner_kind == "user" else "teams"
        path = f"{owner_prefix}/{principal.credential_owner_id}/{self._manifest.slug}"
        try:
            blob = self._read_fn(path, principal.credential_version)
        except ConnectorError:
            raise
        except Exception as exc:
            # InvalidPath je hvac KV-v2 signál pro chybějící per-user blob.
            # Kontroluje se název třídy, aby testy s vlastním read_fn
            # nepotřebovaly hvac.
            if exc.__class__.__name__ == "InvalidPath":
                raise ConnectorError(
                    ErrorCode.FORBIDDEN, "nemáš přiřazené credentials"
                ) from exc
            raise ConnectorError(
                ErrorCode.UPSTREAM_UNAVAILABLE, "trezor credentials je nedostupný"
            ) from exc
        if not isinstance(blob, dict):
            raise ConnectorError(
                ErrorCode.INTERNAL, "trezor vrátil neplatné credentials"
            )
        return resolve_fields(
            self._manifest,
            blob,
            environ=self._environ,
            reject_unknown=True,
            location="Vault",
        )

    def _circuit_check(self) -> None:
        with self._circuit_lock:
            if not self._circuit_opened_at:
                return
            if time.monotonic() - self._circuit_opened_at < self._circuit_reset_timeout:
                raise ConnectorError(
                    ErrorCode.UPSTREAM_UNAVAILABLE,
                    "trezor credentials je dočasně nedostupný",
                )
            self._circuit_opened_at = 0.0
            self._circuit_failures = 0

    def _record_success(self) -> None:
        with self._circuit_lock:
            self._circuit_failures = 0

    def _record_failure(self) -> None:
        with self._circuit_lock:
            self._circuit_failures += 1
            if self._circuit_failures >= self._circuit_failure_threshold:
                self._circuit_opened_at = time.monotonic()

    def _load_with_retry(self, principal: Principal) -> Resolved:
        self._circuit_check()
        for attempt in range(self._max_retries + 1):
            try:
                result = self._load(principal)
                self._record_success()
                return result
            except ConnectorError as exc:
                if exc.code == ErrorCode.FORBIDDEN:
                    raise
                if attempt >= self._max_retries:
                    self._record_failure()
                    raise
                if self._retry_backoff:
                    time.sleep(self._retry_backoff * (2**attempt))
        raise AssertionError("unreachable")

    def resolve(self, principal: Principal) -> Resolved:
        if principal.credential_version is None:
            return self._load_with_retry(principal)
        cache_key = (
            f"{principal.credential_owner_kind}\x00{principal.credential_owner_id}"
            f"\x00{principal.credential_version}"
        )
        return self._cache.get_or_load(
            cache_key,
            lambda: self._load_with_retry(principal),
            self._ttl,
        )

    def invalidate(self, sub: str) -> None:
        self._cache.invalidate_prefix(f"user\x00{sub}\x00")

    def invalidate_principal(self, principal: Principal) -> None:
        if principal.credential_owner_kind and principal.credential_owner_id:
            self._cache.invalidate_prefix(
                f"{principal.credential_owner_kind}\x00{principal.credential_owner_id}\x00"
            )


class AsyncVaultProvider:
    """Async fasáda pro :class:`VaultProvider`, která neblokuje event loop."""

    def __init__(self, provider: VaultProvider) -> None:
        self._provider = provider

    async def resolve(self, principal: Principal) -> Resolved:
        return await asyncio.to_thread(self._provider.resolve, principal)

    async def invalidate(self, sub: str) -> None:
        await asyncio.to_thread(self._provider.invalidate, sub)
