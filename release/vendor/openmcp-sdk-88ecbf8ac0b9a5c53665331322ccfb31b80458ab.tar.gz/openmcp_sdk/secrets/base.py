"""Kontrakt poskytovatele přihlašovacích údajů a sdílené řešení manifestu."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Protocol

from openmcp_sdk.context import Principal
from openmcp_sdk.envelope import ConnectorError, ErrorCode
from openmcp_sdk.manifest import Field, Manifest

_MISSING = object()


@dataclass(frozen=True)
class Resolved:
    secrets: Mapping[str, str]
    config: Mapping[str, Any]

    def __post_init__(self) -> None:
        object.__setattr__(self, "secrets", MappingProxyType(dict(self.secrets)))
        object.__setattr__(self, "config", MappingProxyType(dict(self.config)))


class CredentialProvider(Protocol):
    def resolve(self, principal: Principal) -> Resolved: ...

    def invalidate(self, sub: str) -> None: ...


def _resolve_value(field: Field, raw: Any, location: str) -> Any:
    if raw is _MISSING or raw is None or raw == "":
        raw = field.default
    if raw is None:
        if field.required:
            raise ConnectorError(
                ErrorCode.INVALID_INPUT,
                f"chybí povinné pole {field.key} ({location})",
            )
        return None
    try:
        return field.parse(raw)
    except ValueError as exc:
        raise ConnectorError(
            ErrorCode.INVALID_INPUT,
            f"neplatné pole {field.key} ({location}): {exc}",
        ) from exc


def resolve_operator_config(
    manifest: Manifest, environ: Mapping[str, str] | None = None
) -> dict[str, Any]:
    environ = environ or {}
    env_names = manifest.operator_env_names()
    result: dict[str, Any] = {}
    for field in manifest.operator_config:
        raw = environ.get(env_names[field.key], _MISSING)
        value = _resolve_value(field, raw, "operator config")
        if value is not None:
            result[field.key] = value
    return result


def resolve_fields(
    manifest: Manifest,
    values: Mapping[str, Any],
    *,
    environ: Mapping[str, str] | None = None,
    reject_unknown: bool = False,
    location: str = "credentials",
) -> Resolved:
    fields = manifest.credentials + manifest.user_config
    runtime_secret_keys = list(manifest.auth.runtime_secrets)
    known = {field.key for field in fields} | set(runtime_secret_keys)
    if reject_unknown:
        unknown = sorted(set(values) - known)
        if unknown:
            raise ConnectorError(
                ErrorCode.INVALID_INPUT,
                f"neznámá pole ({location}): {', '.join(unknown)}",
            )

    secrets: dict[str, str] = {}
    config = resolve_operator_config(manifest, environ)
    secret_keys = {field.key for field in manifest.credentials if field.secret}

    for field in fields:
        value = _resolve_value(field, values.get(field.key, _MISSING), location)
        if value is None:
            continue
        if field.key in secret_keys:
            # Validace manifestu zaručuje, že tajná pole jsou řetězce.
            secrets[field.key] = value
        else:
            config[field.key] = value

    # Runtime secrets delegovaného OAuth jsou neprůhledné řetězce, které do
    # blobu daného uživatele zapisuje platforma (např. refresh_token, cloud_id).
    # Nemají žádné schéma pole, proto se předávají doslovně, bez konverze.
    for key in runtime_secret_keys:
        raw = values.get(key, _MISSING)
        if raw is _MISSING or raw is None or raw == "":
            raise ConnectorError(
                ErrorCode.INVALID_INPUT,
                f"chybí delegovaný OAuth secret {key} ({location})",
            )
        if not isinstance(raw, str):
            raise ConnectorError(
                ErrorCode.INVALID_INPUT,
                f"delegovaný OAuth secret {key} musí být řetězec ({location})",
            )
        secrets[key] = raw
    return Resolved(secrets, config)


def operator_defaults(manifest: Manifest) -> dict[str, Any]:
    """Zpětně kompatibilní alias pro volající, kteří nepoužívají přepisy přes env proměnné."""

    return resolve_operator_config(manifest)
