"""Poskytovatel přihlašovacích údajů pro local-stdio, podložený vloženým mapováním prostředí."""

from __future__ import annotations

import os
from collections.abc import Mapping

from openmcp_sdk.context import Principal
from openmcp_sdk.manifest import Manifest
from openmcp_sdk.secrets.base import Resolved, resolve_fields


class EnvProvider:
    def __init__(
        self, manifest: Manifest, environ: Mapping[str, str] | None = None
    ) -> None:
        self._manifest = manifest
        self._environ = os.environ if environ is None else environ

    def resolve(self, principal: Principal) -> Resolved:
        del principal
        env_names = {
            **self._manifest.env_names(),
            **self._manifest.runtime_secret_env_names(),
        }
        values = {
            key: self._environ[env_name]
            for key, env_name in env_names.items()
            if env_name in self._environ
        }
        return resolve_fields(
            self._manifest,
            values,
            environ=self._environ,
            location="environment",
        )

    def invalidate(self, sub: str) -> None:
        del sub
