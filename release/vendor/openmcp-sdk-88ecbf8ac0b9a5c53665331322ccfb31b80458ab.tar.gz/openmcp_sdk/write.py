"""Zápisová vrstva: politika → rozpočet → diff → potvrzení → audit.

Zobecnění toho, co dnes existuje jen v raynetu (jediný write konektor).
Konektoru zůstává mapování entit a allowlist polí; pořadí obranných vrstev
a jejich fail-closed chování patří do SDK, ne do každého repozitáře zvlášť.

Konektor prompt injection **vyřešit nemůže** — jakýkoli text z cizího
systému v kontextu může model ovlivnit, to je vlastnost LLM. Vrstvy tu jen
ohraničují, co se stane, když injekce vyjde:

1. read-only filter při startu (nástroj se vůbec nezaregistruje),
2. politika workspace (:meth:`AccessPolicy.write_decision`),
3. strop zápisů v okně,
4. **potvrzení člověkem s konkrétním diffem** — jediná vrstva, která injekci
   reálně zastaví, protože odpověď renderuje klient uživateli a model si ji
   nemůže vymyslet.

Dekorátor tu záměrně není: neviděl by allowlistovaný payload bez introspekce
podpisu a implicitní magie na bezpečnostní hranici je špatný obchod.
"""

from __future__ import annotations

import logging
import threading
import time
from collections.abc import Callable, Collection, Iterable, Mapping
from dataclasses import dataclass, field
from typing import Any

from openmcp_sdk.context import WriteDecision, current_context
from openmcp_sdk.envelope import ConnectorError, ErrorCode
from openmcp_sdk.pii import assert_no_tokens

logger = logging.getLogger(__name__)

# Typy odpovědi elicitation se importují při importu modulu, ne při prvním
# zápise — případný rozchod s fastmcp tak spadne při buildu, ne až tehdy, když
# uživatel něco zapisuje. (Raynet to řešil porovnáním `type(x).__name__`,
# co je křehké vůči přejmenování i vůči podtřídám.)
try:  # pragma: no cover — závisí na verzi fastmcp
    from fastmcp.server.elicitation import AcceptedElicitation

    _ACCEPTED: tuple[type, ...] = (AcceptedElicitation,)
except ImportError:  # pragma: no cover
    _ACCEPTED = ()


def _is_accepted(result: Any) -> bool:
    if _ACCEPTED:
        return isinstance(result, _ACCEPTED)
    # Fallback, když fastmcp typy nejsou k dispozici: jen explicitní "accept".
    return getattr(result, "action", None) == "accept"


def build_payload(**fields: Any) -> dict[str, Any]:
    """Sestav payload z výslovně vyjmenovaných polí.

    Payload se **nikdy** neskladá průchodem argumentů. Např. RAYNET
    ``POST /company/{id}/`` přijímá 34 vlastností včetně ``securityLevel``
    a ``owner``; bez allowlistu by jejich model mohl přestavit, kdyby ho o to
    požádal text načtený z cizího systému.

    ``None`` znamená „neměnit" a do payloadu se nedostane.
    """
    payload = {key: value for key, value in fields.items() if value is not None}
    # Tokeny jsou jednosměrné — omylem zapsaný `<EMAIL_…>` by v cizím systému
    # zůstal navždy a původní hodnotu už nikdo nedopočítá.
    assert_no_tokens(payload)
    return payload


@dataclass
class WriteBudget:
    """Strop zápisů v posuvném okně, per principal.

    POCTIVO: čítač je **per-proces v paměti**. Při více replikách nebo po
    restartu se rozejde — není to kvóta, je to pojistka proti runaway smyčce
    v jedné konverzaci. Skutečné kvótování má stav a patří do gatewaye; kdyby
    to SDK předstíralo, vznikla by bezpečnostní záruka, která neplatí.
    """

    limit: int = 10
    window_s: int = 300
    _log: dict[str, list[float]] = field(default_factory=dict, repr=False)
    _clock: Callable[[], float] = field(default=time.monotonic, repr=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def _raise_exhausted(self) -> None:
        raise ConnectorError(
            ErrorCode.FORBIDDEN,
            f"Překročený limit {self.limit} zápisů za "
            f"{max(1, self.window_s // 60)} minut. Pokud to nebyl záměr, "
            "zkontroluj, co asistent zapisoval.",
        )

    def check(self, key: str) -> None:
        """Odmítni, pokud je rozpočet vyčerpaný. **Nic nezapočítá.**

        Započítání je záměrně oddělené (:meth:`record`): zápis, který člověk
        neschválil, se nesmí počítat. Jinak by injekce, která vygeneruje
        deset pokusů a všechny jsou odmítnuté, zablokovala uživateli
        legitimní zápisy na celé okno.
        """
        with self._lock:
            if len(self._recent(key)) >= self.limit:
                self._raise_exhausted()

    def record(self, key: str) -> None:
        """Započítej provedený zápis."""
        with self._lock:
            recent = self._recent(key)
            recent.append(self._clock())
            self._log[key] = recent

    def consume(self, key: str) -> None:
        """Atomicky ověř a započítej jeden zápis.

        Samostatné ``check`` a ``record`` nestačí po asynchronním potvrzení:
        dvě souběžná volání mohou obě projít kontrolou a překročit strop.
        """
        with self._lock:
            recent = self._recent(key)
            if len(recent) >= self.limit:
                self._raise_exhausted()
            recent.append(self._clock())
            self._log[key] = recent

    def _recent(self, key: str) -> list[float]:
        now = self._clock()
        return [t for t in self._log.get(key, []) if now - t < self.window_s]

    def reset(self) -> None:
        """Zahoď historii. Pro testy — jinak se stav přelévá mezi nimi."""
        with self._lock:
            self._log.clear()


#: Sdílený default pro celý proces. Konektor si může podat vlastní.
#:
#: POZOR: je to **modulová instance**, takže ji sdílí všechno v procesu. Pro
#: provoz je to záměr (jeden konektor = jeden pod = jeden rozpočet), v
#: testech je to zdroj přelévání — SDK pytest plugin ji proto před každým
#: testem resetuje.
DEFAULT_BUDGET = WriteBudget()


@dataclass(frozen=True, slots=True)
class WriteTarget:
    """Co se zapisuje — pro diff, potvrzení a audit."""

    entity: str
    record_id: str | int | None = None

    def describe(self) -> str:
        if self.record_id is None:
            return f"nový záznam ({self.entity})"
        return f"{self.entity} #{self.record_id}"


def diff_lines(before: Mapping[str, Any], after: Mapping[str, Any]) -> list[str]:
    """Řádky ``pole: původní → nové`` pro potvrzovací zprávu."""
    return [
        f"  {key}: {before.get(key, '—')!r} → {after[key]!r}" for key in sorted(after)
    ]


async def confirm_write(
    target: WriteTarget,
    after: Mapping[str, Any],
    *,
    before: Mapping[str, Any] | None = None,
    product: str,
    mandatory: bool,
) -> None:
    """Vyžádej si souhlas člověka s konkrétním diffem.

    Zpráva jde přes klienta **rovno člověku, ne do kontextu modelu**, takže smí
    obsahovat skutečné hodnoty. Návratová hodnota nástroje se naopak
    pseudonymizuje jako každá jiná odpověď.

    Fail-closed: když klient elicitation neumí, zápis se **neprovede**.

    ``mandatory=True`` (politika workspace žádá schválení) se nedá obejít
    konektorovým přepínačem — volající ho v tom případě nesmí přeskočit.
    """
    lines = diff_lines(before or {}, after)
    message = "\n".join(
        [
            f"Asistent chce zapsat do {product} — {target.describe()}:",
            *lines,
            "",
            *(
                ["Potvrzení vyžaduje politika tvého pracovního prostoru."]
                if mandatory
                else []
            ),
            "Potvrdit zápis?",
        ]
    )

    try:
        # Import je uvnitř `try`: když fastmcp chybí, musí ven stejná typová
        # hláška jako při klientovi bez elicitation — ne surová `ImportError`,
        # které text by šel modelu.
        from fastmcp.server.dependencies import get_context

        result = await get_context().elicit(message, response_type=None)
    except Exception as exc:
        raise ConnectorError(
            ErrorCode.FORBIDDEN,
            "Zápis vyžaduje potvrzení uživatele, ale klient ho neumí "
            "vyžádat (chybí podpora elicitation). Zápis byl zamítnutý.",
        ) from exc

    if not _is_accepted(result):
        raise ConnectorError(
            ErrorCode.FORBIDDEN, "Zápis nebyl potvrzený uživatelem."
        )


def audit_write(
    tool: str,
    target: WriteTarget,
    fields: Iterable[str],
    *,
    outcome: str = "ok",
) -> None:
    """Zaloguj zápis — **názvy polí, nikdy hodnoty** (ty jsou z definice PII)."""
    logger.info(
        "write tool=%s sub=%s entity=%s id=%s fields=%s outcome=%s",
        tool,
        current_context().principal.sub,
        target.entity,
        target.record_id if target.record_id is not None else "new",
        ",".join(sorted(fields)),
        outcome,
    )


def _audit_quietly(
    tool: str, target: WriteTarget, fields: Iterable[str], *, outcome: str
) -> None:
    """Audit v chybové větvi nesmí zamaskovat původní výjimku.

    `audit_write` sahá na `current_context()`, který může sám hodit
    `ConnectorError("chybí request kontext")` — a ten by nahradil skutečnou
    příčinu selhání zápisu.
    """
    try:
        audit_write(tool, target, fields, outcome=outcome)
    except Exception:  # noqa: BLE001
        logger.warning("audit zápisu selhal")


async def execute_write(
    tool: str,
    target: WriteTarget,
    payload: Mapping[str, Any],
    *,
    apply: Callable[[Mapping[str, Any]], Any],
    product: str,
    fetch_before: Callable[[WriteTarget, Collection[str]], Mapping[str, Any]] | None = None,
    sanitize: Callable[[Any], Any] | None = None,
    budget: WriteBudget = DEFAULT_BUDGET,
    confirm_config_key: str | None = "require_write_confirmation",
) -> Any:
    """Společná cesta všech zápisů. Pořadí vrstev je tu, ne v konektoru."""
    ctx = current_context()
    decision = ctx.policy.write_decision(tool)
    if decision is WriteDecision.DENY:
        raise ConnectorError(
            ErrorCode.FORBIDDEN, "zápis není povolený firemní politikou"
        )

    if not payload:
        raise ConnectorError(
            ErrorCode.INVALID_INPUT, "zápis neobsahuje žádné pole ke změně"
        )

    # Konektorový přepínač smí potvrzení vypnout jen tehdy, když ho politika
    # workspace nevyžaduje. REQUIRE_APPROVAL je override, který se obejít nedá.
    wants_confirm = decision is WriteDecision.REQUIRE_APPROVAL
    if not wants_confirm and confirm_config_key is not None:
        wants_confirm = bool(ctx.config.get(confirm_config_key, True))

    budget.check(ctx.principal.sub)

    before: Mapping[str, Any] = {}
    if fetch_before is not None and target.record_id is not None:
        try:
            before = fetch_before(target, tuple(payload))
        except ConnectorError as exc:
            # A missing target is a definitive business result, not an
            # unavailable diff. Never ask for confirmation of a record that
            # does not exist and never continue to apply when confirmation is
            # disabled. The gateway replaces this typed code with fixed safe
            # model-visible copy, so provider detail is not propagated.
            if exc.code is ErrorCode.NOT_FOUND:
                raise
            if wants_confirm:
                raise ConnectorError(
                    ErrorCode.UPSTREAM_UNAVAILABLE,
                    "Původní hodnoty pro bezpečné potvrzení se nepodařilo načíst. Zápis neproběhl.",
                ) from exc
            logger.warning("nepodařilo se načíst původní hodnoty pro diff")
        except Exception as exc:  # noqa: BLE001
            # Potvrzení slibuje konkrétní diff. Když původní hodnoty nejdou
            # načíst, nesmíme člověku ukázat smyšlené „—“ a pokračovat.
            if wants_confirm:
                raise ConnectorError(
                    ErrorCode.UPSTREAM_UNAVAILABLE,
                    "Původní hodnoty pro bezpečné potvrzení se nepodařilo načíst. Zápis neproběhl.",
                ) from exc
            logger.warning("nepodařilo se načíst původní hodnoty pro diff")

    if wants_confirm:
        await confirm_write(
            target,
            payload,
            before=before,
            product=product,
            mandatory=decision is WriteDecision.REQUIRE_APPROVAL,
        )

    # Započítání až tu: potvrzení prošlo, zápis se opravdu vykoná. Odmítnutý
    # pokus rozpočet nečerpá — jinak by injekce, které člověk desetkrát řekne
    # ne, zablokovala uživateli legitimní zápisy na celé okno.
    budget.consume(ctx.principal.sub)

    try:
        result = apply(payload)
    except Exception:
        _audit_quietly(tool, target, payload, outcome="error")
        raise

    audit_write(tool, target, payload, outcome="ok")
    return sanitize(result) if sanitize is not None else result


__all__ = [
    "DEFAULT_BUDGET",
    "WriteBudget",
    "WriteTarget",
    "audit_write",
    "build_payload",
    "confirm_write",
    "diff_lines",
    "execute_write",
]
