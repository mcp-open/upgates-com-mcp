"""Společná sada testů, kterou si každý konektor pustí proti svému manifestu.

Nahrazuje testy, které jsou dnes rozkopírované po repozitářích — zejména
``test_display_tools_match_registered_tools`` (téměř identický v čtyřech),
kontrolu verze manifest↔pyproject a zapojení ``supports_test`` (obě jen v ares).

Použití v konektoru (jediný soubor ``tests/test_conformance.py``)::

    from openmcp_sdk.testing.conformance import ConnectorConformance

    class TestConformance(ConnectorConformance):
        manifest = "connector.yaml"
        server = "connector.server:mcp"
        test_connection = "connector.server:test_connection"
        pii_policy = "connector.pii:POLICY"
        package = "raynet-mcp"
"""

from __future__ import annotations

import importlib
import re
import subprocess
import sys
import tomllib
from pathlib import Path
from typing import Any

import pytest

from openmcp_sdk.manifest import Manifest, load_manifest

# Shodné s Go `provision.slugRe` — nejpřísnější a závazný validátor.
_GO_SLUG_RE = re.compile(r"^[a-z][a-z0-9-]{1,30}[a-z0-9]$")


def _resolve(target: str) -> Any:
    module_name, _, attr = target.partition(":")
    module = importlib.import_module(module_name)
    return getattr(module, attr) if attr else module


def _enumerate_tools(mcp: Any) -> dict[str, Any]:
    from openmcp_sdk.runtime import _enumerate_tools as enumerate_runtime_tools

    return {tool.name: tool for tool in enumerate_runtime_tools(mcp)}


class ConnectorConformance:
    """Zděď a nastav atributy. Nenastavené kontroly se přeskočí."""

    #: Cesta k manifestu, relativně ke kořeni repozitáře konektora.
    manifest: str = "connector.yaml"
    #: ``modul:atribut`` FastMCP instance, např. ``connector.server:mcp``.
    server: str | None = None
    #: ``modul:atribut`` callbacku ``test_connection``, pokud existuje.
    test_connection: str | None = None
    #: ``modul:atribut`` :class:`~openmcp_sdk.pii.PiiPolicy`, pokud konektor má PII.
    pii_policy: str | None = None
    #: Jméno distribuce v ``pyproject.toml`` (pro kontrolu verze).
    package: str | None = None
    #: Env proměnné potřebné pro local-stdio start (credentials konektora).
    local_env: dict[str, str] = {}

    # -- pomocné ---------------------------------------------------------------
    @pytest.fixture(scope="class")
    @classmethod
    def loaded(cls) -> Manifest:
        return load_manifest(cls.manifest)

    @pytest.fixture(scope="class")
    @classmethod
    def tools(cls) -> dict[str, Any]:
        if cls.server is None:
            pytest.skip("konektor nenastavil `server`")
        return _enumerate_tools(_resolve(cls.server))

    # -- manifest --------------------------------------------------------------
    def test_manifest_loads(self, loaded: Manifest) -> None:
        assert loaded.slug

    def test_slug_matches_go_validator(self, loaded: Manifest) -> None:
        """SDK i Go musí slug přijmout — Go je závazný při onboardingu."""
        assert _GO_SLUG_RE.fullmatch(loaded.slug), (
            f"slug {loaded.slug!r} neprojde Go validátorem "
            "^[a-z][a-z0-9-]{1,30}[a-z0-9]$"
        )

    def test_egress_is_declared(self, loaded: Manifest) -> None:
        """Bez `egress.host` a `port` `provision.ParseSpec` spec odmítne."""
        assert loaded.egress is not None, "chybí blok egress"
        assert loaded.egress.host
        assert loaded.egress.port > 0

    def test_display_tools_are_declared(self, loaded: Manifest) -> None:
        """Prázdné `display.tools` = operator nezaklasifikuje policies.

        Konektor by se nasadil s fail-closed zamítnutými nástroji.
        """
        assert loaded.display is not None and loaded.display.tools, (
            "chybí display.tools — operator by nezaklasifikoval žádný nástroj"
        )

    def test_version_matches_pyproject(self, loaded: Manifest) -> None:
        if self.package is None:
            pytest.skip("konektor nenastavil `package`")
        data = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))
        assert data["project"]["version"] == loaded.version

    # -- manifest ↔ server -----------------------------------------------------
    def test_display_tools_match_registered_tools(
        self, loaded: Manifest, tools: dict[str, Any]
    ) -> None:
        declared = {
            item.name for item in (loaded.display.tools if loaded.display else [])
        }
        registered = set(tools)
        assert declared == registered, (
            f"jen v manifestu: {sorted(declared - registered)}; "
            f"jen v serveru: {sorted(registered - declared)}"
        )

    def test_every_tool_has_explicit_read_only_hint(
        self, tools: dict[str, Any]
    ) -> None:
        """Chybějící anotace = nástroj v read-only režimu tiše zmizí."""
        missing = sorted(
            name
            for name, item in tools.items()
            if item.annotations is None or item.annotations.readOnlyHint is None
        )
        assert not missing, f"nástroje bez readOnlyHint: {missing}"

    def test_supports_write_matches_registered_tools(
        self, loaded: Manifest, tools: dict[str, Any]
    ) -> None:
        mutating = sorted(
            name
            for name, item in tools.items()
            if item.annotations is not None and item.annotations.readOnlyHint is False
        )
        if loaded.capabilities.supports_write:
            assert mutating, "supports_write=true, ale žádný mutující nástroj"
        else:
            assert not mutating, (
                f"supports_write=false, ale mutující nástroje existují: {mutating}"
            )

    def test_supports_test_matches_wiring(self, loaded: Manifest) -> None:
        """`run_connector` na tomto nesouladu padá až při startu."""
        wired = self.test_connection is not None
        assert loaded.capabilities.supports_test == wired, (
            f"capabilities.supports_test={loaded.capabilities.supports_test}, "
            f"ale test_connection {'je' if wired else 'není'} zapojený"
        )

    def test_tool_descriptions_are_not_empty(self, loaded: Manifest) -> None:
        empty = sorted(
            item.name
            for item in (loaded.display.tools if loaded.display else [])
            if not item.description.strip()
        )
        assert not empty, f"display.tools bez popisu: {empty}"

    # -- PII -------------------------------------------------------------------
    def test_pii_policy_matches_manifest(self, loaded: Manifest) -> None:
        """`runtime.pii_salt` a existence politiky musí jít ruka v ruce.

        Salt bez politiky je zbytečný k8s secret; politika bez saltu znamená
        konektor, který při startu spadne na `require_salt()`.
        """
        has_policy = self.pii_policy is not None
        assert loaded.runtime.pii_salt == has_policy, (
            f"runtime.pii_salt={loaded.runtime.pii_salt}, ale pii_policy "
            f"{'je' if has_policy else 'není'} nastavená"
        )

    def test_pii_policy_is_valid(self) -> None:
        if self.pii_policy is None:
            pytest.skip("konektor nemá PII politiku")
        _resolve(self.pii_policy).validate()

    def test_pii_connector_documents_data_handling(self, loaded: Manifest) -> None:
        if not loaded.runtime.pii_salt:
            pytest.skip("konektor nezpracovává osobní údaje")
        assert loaded.display is not None and loaded.display.data_handling.strip(), (
            "konektor zpracovává osobní údaje, ale display.data_handling je prázdné"
        )

    # -- read-only filter ------------------------------------------------------
    def test_read_only_filter_removes_write_tools(
        self, loaded: Manifest, tools: dict[str, Any]
    ) -> None:
        """Bezpečnostní hranice: v read-only režimu nesmí zůstat mutující nástroj.

        Běží v **subprocesu** — `run_connector` mutuje globální instanci
        `mcp` (nástroje odregistruje), takže v procesu se zbytkem testů by to
        prosáklo do nesouvisejících případů.
        """
        if self.server is None:
            pytest.skip("konektor nenastavil `server`")

        common = {
            "manifest_path": self.manifest,
            "server_target": self.server,
            "env": self.local_env,
            "test_connection": self.test_connection,
            "pii_policy": self.pii_policy,
        }
        restricted = set(tools_with_read_only(read_only=True, **common))
        full = set(tools_with_read_only(read_only=False, **common))

        assert restricted, "v read-only režimu nezůstal žádný nástroj"
        assert restricted <= full, (
            f"read-only režim zaregistroval nástroje navyše: {sorted(restricted - full)}"
        )

        mutating = {
            name
            for name, item in tools.items()
            if item.annotations is not None and item.annotations.readOnlyHint is False
        }
        assert not (mutating & restricted), (
            f"mutující nástroje přežily read-only filter: {sorted(mutating & restricted)}"
        )
        if loaded.capabilities.supports_write:
            assert mutating, "supports_write=true, ale žádný mutující nástroj"
            assert mutating <= full, (
                f"write režim nezaregistroval: {sorted(mutating - full)}"
            )


def tools_with_read_only(
    manifest_path: str,
    server_target: str,
    *,
    read_only: bool,
    env: dict[str, str] | None = None,
    test_connection: str | None = None,
    pii_policy: str | None = None,
) -> list[str]:
    """Spusť `run_connector(serve=False)` v subprocesu a vrať názvy nástrojů.

    Subprocess je nutný, ne z opatrnosti: filter odregistruje nástroje
    z globálního `mcp`, což je změna napříč celým procesem.

    ``test_connection`` se musí předat, když ho konektor má — `run_connector`
    jinak padne na invariantu ``capabilities.supports_test``.
    """
    import json
    import os

    manifest = load_manifest(manifest_path)
    script = (
        "import json, importlib;"
        "from openmcp_sdk.runtime import run_connector;"
        f"mod, _, attr = {server_target!r}.partition(':');"
        "mcp = getattr(importlib.import_module(mod), attr);"
        + (
            f"tc_mod, _, tc_attr = {test_connection!r}.partition(':');"
            "tc = getattr(importlib.import_module(tc_mod), tc_attr);"
            if test_connection
            else "tc = None;"
        )
        + (
            f"p_mod, _, p_attr = {pii_policy!r}.partition(':');"
            "pii = getattr(importlib.import_module(p_mod), p_attr);"
            if pii_policy
            else "pii = None;"
        )
        + f"run_connector({manifest_path!r}, mcp, serve=False, test_connection=tc, pii=pii);"
        "from openmcp_sdk.runtime import _enumerate_tools;"
        "print(json.dumps(sorted(tool.name for tool in _enumerate_tools(mcp))))"
    )
    child_env = {
        **os.environ,
        **(env or {}),
        "OPENMCP_MODE": "local-stdio",
        f"{manifest.slug.upper()}_READ_ONLY": "true" if read_only else "false",
        "OPENMCP_PII_SALT": os.environ.get("OPENMCP_PII_SALT", "test-pii-salt"),
    }
    result = subprocess.run(
        [sys.executable, "-c", script],
        capture_output=True,
        text=True,
        env=child_env,
        check=False,
    )
    if result.returncode != 0:
        raise AssertionError(
            f"subprocess selhal (rc={result.returncode}):\n{result.stderr[-2000:]}"
        )
    return json.loads(result.stdout.strip().splitlines()[-1])


__all__ = ["ConnectorConformance", "tools_with_read_only"]
