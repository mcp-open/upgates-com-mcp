"""Testovací dvojníci pro věci, které se jinak testujú těžko."""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from typing import Any, Literal


class FakeOAuth:
    """Náhrada ``DelegatedOAuthClient`` s počítadlem obnovení."""

    def __init__(self, cloud_id: str = "cloud-1", tokens: list[str] | None = None) -> None:
        self.cloud_id = cloud_id
        self._tokens = list(tokens or ["token-1", "token-2"])
        self.invalidated = 0
        self.issued: list[str] = []

    @property
    def provider_name(self) -> str:
        return "fake"

    def access_token(self) -> str:
        token = self._tokens[0]
        self.issued.append(token)
        return token

    def invalidate(self) -> None:
        self.invalidated += 1
        if len(self._tokens) > 1:
            self._tokens.pop(0)


Behaviour = Literal["accept", "decline", "cancel", "unsupported"]


class FakeElicitation:
    """Náhrada fastmcp kontextu pro potvrzování zápisů.

    Bez nej se ``confirm_write`` prakticky nedá otestovat — a je to jediná
    vrstva, která prompt injection reálně zastaví, takže netestovaná být nesmí.
    """

    def __init__(self, behaviour: Behaviour = "accept") -> None:
        self.behaviour: Behaviour = behaviour
        self.messages: list[str] = []

    async def elicit(self, message: str, response_type: Any = None) -> Any:
        self.messages.append(message)
        if self.behaviour == "unsupported":
            raise RuntimeError("klient nepodporuje elicitation")
        if self.behaviour == "accept":
            from fastmcp.server.elicitation import AcceptedElicitation

            return AcceptedElicitation(data=None)
        if self.behaviour == "decline":
            from mcp.server.elicitation import DeclinedElicitation

            return DeclinedElicitation()
        from mcp.server.elicitation import CancelledElicitation

        return CancelledElicitation()


@contextmanager
def elicitation(behaviour: Behaviour = "accept") -> Iterator[FakeElicitation]:
    """Nainstaluj :class:`FakeElicitation` jako aktivní fastmcp kontext.

    Zachytené zprávy jsou v ``fake.messages`` — testy tak můžou ověřit, že se
    člověku ukázal správný diff, nejen že zápis prošel.
    """
    import fastmcp.server.dependencies as deps

    fake = FakeElicitation(behaviour)
    original = deps.get_context
    deps.get_context = lambda: fake  # type: ignore[assignment]
    try:
        yield fake
    finally:
        deps.get_context = original  # type: ignore[assignment]


__all__ = ["Behaviour", "FakeElicitation", "FakeOAuth", "elicitation"]
