"""Pseudonymizace osobních údajů před odesláním do LLM.

Nahrazuje tři kopie (`raynet/pii.py` 353 ř., `dotykacka/pii.py` 227,
`upgates/anonymize.py` 248), jejichž jádro bylo bit-identické. Konektoru
zůstávají jen **tabulky polí** — žádná logika.

Token je jednosměrný: ``<KATEGORIE_<12 hex>>``, kde hex je HMAC-SHA256 z
``"{kategorie}:{hodnota}"`` pod per-tenant klíčem. Nikde nevzniká
re-identifikační mapa, takže token se nedá rozšifrovat zpět.

**Formát tokenu je externě viditelný, dlouhodobě stabilní kontrakt.** Odvození
je záměrně bit-identické s původními implementacemi, aby migrace konektoru
nezměnila ani jeden token — uživatel by jinak najednou viděl jiné ID.

Pořadí vyhodnocení pole je kanonizované na::

    objektové pole → hook konektoru → jména → kategorie → freetext → substring

Raynet měl ``kategorie → freetext``, upgates opačně. Ověřeno: žádný ze tří
konektorů nemá pole zároveň v ``field_category`` i ``freetext_fields``
(pole ``othercontact`` je u raynetu v obou, ale raynet už dnes vyhodnocuje kategorii
dřív), takže sjednocení **nikomu nemění výstup**.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import re
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Final

from openmcp_sdk.context import RequestContext
from openmcp_sdk.envelope import ConnectorError, ErrorCode

SALT_ENV: Final = "OPENMCP_PII_SALT"
TOKEN_HEX_LEN: Final = 12
TOKEN_RE: Final = re.compile(rf"<[A-Z]+_[0-9a-f]{{{TOKEN_HEX_LEN}}}>")

# Regex fallback — zachytí PII i ve volném textu a v neznámých polích.
RE_EMAIL: Final = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
RE_PHONE: Final = re.compile(r"(?<![\w.])(?:\+?\d[\d\s()\-]{7,}\d)(?![\w])")
RE_URL: Final = re.compile(r"https?://[^\s\"'<>]+")
# Pojistka proti falešné shodě data jako telefonu (např. "2022-06-18 13").
RE_DATELIKE: Final = re.compile(r"\d{4}-\d{1,2}-\d{1,2}")

#: Strop registru známých jmen. Po dosažení se nová jména neregistrují, ale
#: přímá NAME pole se tokenizují dál (HMAC registr nepotřebuje) —
#: degraduje se tedy propagace do volného textu, ne redakce.
MAX_KNOWN_NAMES: Final = 50_000

#: Nejkratší jméno, které se smí registrovat pro propagaci do dalších polí.
#: Jednopísmenné hodnoty kolidují s číselníkovými kódy — osoba jménem „A"
#: jinak přepíše každý rating „A" na NAME token. Dvouznaková jména jsou
#: reálná (CJK), proto práh 2 a ne víc.
MIN_KNOWN_NAME_LEN: Final = 2


def require_salt(environ: Mapping[str, str] | None = None) -> str:
    """Vrať salt, nebo vysvětli, proč konektor nemůže běžet.

    Tichý fallback na náhodný per-process salt by zrušil stabilitu tokenů
    a projevilo by se to až po prvním restartu podu — to je horší než hlasitý
    pád při startu.
    """
    salt = (environ if environ is not None else os.environ).get(SALT_ENV, "").strip()
    if not salt:
        raise RuntimeError(
            f"Chybí {SALT_ENV}. Bez něj by tokeny nebyly stabilní napříč "
            f"restarty a pseudonymizace by tiše ztratila smysl."
        )
    return salt


def derive_key(*scope: str, salt: str | None = None) -> bytes:
    """Odvoď HMAC klíč pro daný rozsah izolace.

    ``derive_key(sub)`` dá přesně stejné bajty jako původní implementace
    raynetu a upgates; ``derive_key(sub, cloud_id)`` odpovídá schématu
    dotykačky ``sub:cloud_id``. Jeden podpis, obě sémantiky.

    Vícedílný rozsah je **doporučený** všude, kde existuje skutečný datový
    tenant (cloud, instance): jeden uživatel může propojit jiný tenant a jeho
    tokeny pak nesmí být korelovatelné s předchozím.

    Salt patří do k8s secretu, nikdy do manifestu ani image — jeho únik by
    umožnil re-identifikaci hrubou silou, protože vstupy typu e-mail mají nízkou
    entropii.
    """
    if not scope or any(not part for part in scope):
        raise ValueError("derive_key vyžaduje alespoň jednu neprázdnou část rozsahu")
    resolved = salt if salt is not None else require_salt()
    return hmac.new(
        resolved.encode("utf-8"), ":".join(scope).encode("utf-8"), hashlib.sha256
    ).digest()


def contains_token(value: Any) -> bool:
    """Obsahuje hodnota (i vnořeně) pseudonymizační token?

    Prohledávají se i **klíče** map — custom-field mapy bývají klíčované
    hodnotou, takže token se tam dostane stejně snadno jako do hodnoty.
    """
    if isinstance(value, str):
        return TOKEN_RE.search(value) is not None
    if isinstance(value, bytes | bytearray):
        return TOKEN_RE.search(value.decode("utf-8", "replace")) is not None
    if isinstance(value, Mapping):
        return any(
            contains_token(key) or contains_token(item) for key, item in value.items()
        )
    if isinstance(value, list | tuple | set | frozenset):
        return any(contains_token(item) for item in value)
    return False


def assert_no_tokens(value: Any) -> None:
    """Odmítni zápis, který nese token.

    Tokeny jsou jednosměrné — omylem zapsaný ``<EMAIL_…>`` by v cizím systému
    zůstal navždy a původní hodnota se už nedá dopočítat.
    """
    if contains_token(value):
        raise ConnectorError(
            ErrorCode.INVALID_INPUT,
            "hodnota obsahuje pseudonymizační token — zápis by natrvalo "
            "přepsal skutečný údaj nečitelnou náhradou",
        )


@dataclass(frozen=True, slots=True)
class ConditionalName:
    """Pole, které nese jméno osoby jen při určité hodnotě jiného pole.

    Např. raynet: ``person=true`` znamená, že ``name`` je jméno člověka (OSVČ),
    ne název firmy; ``leadPerson=true`` totéž pro ``companyName``.
    """

    when_field: str
    equals: Any
    field: str
    category: str = "NAME"
    only_when_redact_names: bool = True


def scope_by_sub(ctx: RequestContext) -> tuple[str, ...]:
    return (ctx.principal.sub,)


def scope_by_sub_and_tenant(ctx: RequestContext) -> tuple[str, ...]:
    """Rozsah ``(sub, cloud_id)`` pro delegovaný OAuth."""
    oauth = ctx.oauth
    if oauth is None:
        raise ConnectorError(
            ErrorCode.INTERNAL,
            "tenant rozsah pseudonymizace vyžaduje delegovaný OAuth kontext",
        )
    cloud_id = oauth.cloud_id
    # Bez této kontroly by `None` prošlo jako literál "None" a všichni
    # uživatelé bez cloudu by sdíleli jeden pseudo-tenant — přesně opak
    # toho, k čemu tento rozsah existuje.
    if not isinstance(cloud_id, (str, int)) or not str(cloud_id).strip():
        raise ConnectorError(
            ErrorCode.INTERNAL,
            "tenant rozsah pseudonymizace vyžaduje neprázdné cloud_id",
        )
    return (ctx.principal.sub, str(cloud_id).strip())


@dataclass(frozen=True, slots=True)
class PiiPolicy:
    """Deklarativní popis toho, co je v tomto API osobní údaj."""

    field_category: Mapping[str, str] = field(default_factory=lambda: MappingProxyType({}))
    name_fields: frozenset[str] = frozenset()
    freetext_fields: frozenset[str] = frozenset()
    #: Objektové pole tvaru ``{id, value}`` — tokenizuje se vnitřní ``value``.
    sensitive_object_fields: frozenset[str] = frozenset()
    #: Vnořené pole: ``{"photo": {"filename": "FILE"}}``.
    nested_categories: Mapping[str, Mapping[str, str]] = field(
        default_factory=lambda: MappingProxyType({})
    )
    #: Pole, kterých obsah je záznam osoby — rekurze s person-scope příznakem.
    person_scope_fields: frozenset[str] = frozenset()
    person_scope_name_fields: frozenset[str] = frozenset({"name"})
    #: Substring fallback: ``(("_invoice", "ADDR"), ("_postal", "ADDR"))``.
    #: Chytí ``*_invoice``, ``*_postal`` a custom pole, které přesná shoda
    #: mine a jinak by propadli jen do regex scrubu.
    pattern_category: tuple[tuple[str, str], ...] = ()
    conditional_names: tuple[ConditionalName, ...] = ()

    redact_names_default: bool = False
    propagate_known_names: bool = False
    max_known_names: int = MAX_KNOWN_NAMES
    #: Práh délky pro registraci jména k propagaci. Netýká se tokenizace
    #: samotného NAME pole — krátké jméno se tokenizuje dál, jen se nešíří.
    min_known_name_len: int = MIN_KNOWN_NAME_LEN
    #: Značka před volným textem; ``None`` = vypnuté.
    untrusted_label: str | None = None
    untrusted_min_len: int = 24

    #: Klíč v ``config``, kterým operátor pseudonymizaci vypíná.
    enable_config_key: str | None = "redact_pii"
    names_config_key: str | None = "redact_names"
    tenant_scope: Callable[[RequestContext], tuple[str, ...]] = scope_by_sub

    def validate(self) -> None:
        for category in set(self.field_category.values()) | {
            c for _, c in self.pattern_category
        }:
            if not re.fullmatch(r"[A-Z]+", category):
                raise ValueError(f"kategorie {category!r} musí být UPPERCASE bez podtržítek")
        for key in list(self.field_category) + list(self.name_fields) + list(
            self.freetext_fields
        ):
            if key != key.lower():
                raise ValueError(f"klíč {key!r} musí být lowercase")
        shadowed = sorted(
            key
            for key in self.freetext_fields
            if any(needle in key for needle, _ in self.pattern_category)
        )
        if shadowed:
            raise ValueError(
                "freetext pole odpovídají i substring vzoru "
                f"(pořadí je definované, ale je to téměř jistě překlep): {', '.join(shadowed)}"
            )
        both = sorted(set(self.field_category) & set(self.freetext_fields))
        if both:
            # Není to chyba — pořadí je definované (kategorie vyhrává) —
            # ale téměř vždy je to překlep, tak ať je to vidět.
            raise ValueError(
                "pole jsou zároveň v field_category i freetext_fields "
                f"(kategorie vyhrává, freetext by se neuplatnil): {', '.join(both)}"
            )


class Pseudonymizer:
    """Nahrazuje osobní údaje tokeny odvozenými HMAC-em z hodnoty.

    Instance je určená pro **jeden request** (klíč je per-tenant). Kromě
    registru známých jmen nedrží stav, takže nepotřebuje zámek.

    Konektor může doménové zvláštnosti doplnit přepsáním :meth:`handle_field`.
    """

    #: Sentinel: „tento hook pole nezpracoval, pokračuj standardně".
    UNHANDLED: Final = object()

    def __init__(
        self,
        key: bytes,
        policy: PiiPolicy,
        *,
        redact_names: bool | None = None,
    ) -> None:
        self._key = key
        self.policy = policy
        self.redact_names = (
            policy.redact_names_default if redact_names is None else redact_names
        )
        self._known_names: set[str] = set()

    # -- tokenizácia -----------------------------------------------------------
    def token(self, category: str, value: Any) -> str:
        norm = str(value)
        digest = hmac.new(
            self._key, f"{category}:{norm}".encode("utf-8"), hashlib.sha256
        ).hexdigest()
        stripped = norm.strip()
        if (
            category == "NAME"
            and stripped  # prázdné jméno by v registru matchlo každý blank string
            # Krátká hodnota matchne číselníkový kód (rating „A") dřív než jméno.
            and len(stripped) >= self.policy.min_known_name_len
            and self.policy.propagate_known_names
            and len(self._known_names) < self.policy.max_known_names
        ):
            self._known_names.add(stripped)
        return f"<{category}_{digest[:TOKEN_HEX_LEN]}>"

    # -- text ------------------------------------------------------------------
    def _sub_phone(self, match: re.Match[str]) -> str:
        raw = match.group(0)
        if RE_DATELIKE.search(raw):
            return raw
        if sum(char.isdigit() for char in raw) < 9:
            return raw
        return self.token("PHONE", raw)

    def scrub_text(self, text: str) -> str:
        """E-maily, URL a telefony kdekoli v textu."""
        text = RE_EMAIL.sub(lambda m: self.token("EMAIL", m.group(0)), text)
        text = RE_URL.sub(lambda m: self.token("URL", m.group(0)), text)
        return RE_PHONE.sub(self._sub_phone, text)

    def mark_untrusted(self, text: str) -> str:
        """Označ volný text jako data, ne instrukce.

        Slabá vrstva — model se dá přemluvit i přes značku. Ale nic nestojí
        a zvyšuje laťku: injekce musí přebít explicitní kontext, ne jen
        splynout s okolím.
        """
        label = self.policy.untrusted_label
        if label is None or len(text.strip()) < self.policy.untrusted_min_len:
            return text
        return f"[{label}] {text}"

    def _known_name_token(self, text: str) -> str | None:
        stripped = text.strip()
        if stripped not in self._known_names:
            return None
        return self.token("NAME", stripped)

    def _scrub_string(self, text: str) -> str:
        if self.redact_names and self.policy.propagate_known_names:
            token = self._known_name_token(text)
            if token is not None:
                return token
        return self.scrub_text(text)

    # -- hook pro konektor ------------------------------------------------------
    def handle_field(self, key: str, value: Any, *, person_scope: bool) -> Any:
        """Doménová výjimka. Vrať :attr:`UNHANDLED`, pokud se neuplatní."""
        return self.UNHANDLED

    # -- priechod ---------------------------------------------------------------
    def sanitize(self, data: Any, *, person_scope: bool = False) -> Any:
        """Projdi ``data`` a nahraď PII tokeny.

        ``person_scope=True`` vynutí person-scope už na vrcholu stromu — pro
        endpointy, kde je celá odpověď rovnou seznam osob (zákazníci,
        zaměstnanci) bez obalového klíče z :attr:`PiiPolicy.person_scope_fields`.
        Uvnitř stromu se scope dál řídí obvykle — vnořené pole mimo
        `person_scope_fields` ho zase vypne.
        """
        return self._walk(data, person_scope=person_scope)

    def _walk(self, node: Any, *, person_scope: bool) -> Any:
        if isinstance(node, Mapping):
            out = {
                # Klíč také prochází scrubem: custom-field mapy bývají
                # klíčované hodnotou (e-mailem, telefonem), takže osobní údaj
                # se stejně snadno ocitne v klíči jako v hodnotě.
                (self._scrub_string(key) if isinstance(key, str) else key): (
                    self._handle_field(key, value, person_scope=person_scope)
                    if isinstance(key, str)
                    else self._walk(value, person_scope=person_scope)
                )
                for key, value in node.items()
            }
            for rule in self.policy.conditional_names:
                if rule.only_when_redact_names and not self.redact_names:
                    continue
                target = out.get(rule.field)
                if out.get(rule.when_field) == rule.equals and isinstance(target, str) and target:
                    out[rule.field] = self.token(rule.category, target)
            return out
        # Seznamy i ostatní kontejnery — tvar se zachová, obsah se scrubne.
        # Předtím tudy tuple/set/frozenset propadly nedotčené; `sanitize`
        # je veřejné API a konektor běžně pracuje i s jinými kontejnery než
        # těmi, které přijde z JSON-u.
        if isinstance(node, list):
            return [self._walk(item, person_scope=person_scope) for item in node]
        if isinstance(node, tuple):
            return tuple(self._walk(item, person_scope=person_scope) for item in node)
        if isinstance(node, frozenset):
            return frozenset(self._walk(item, person_scope=person_scope) for item in node)
        if isinstance(node, set):
            return {self._walk(item, person_scope=person_scope) for item in node}
        if isinstance(node, str):
            # Fail-closed: i nevyjmenovaná pole projdou regex scrubem.
            return self._scrub_string(node)
        if isinstance(node, bytes | bytearray):
            scrubbed = self._scrub_string(node.decode("utf-8", "replace"))
            return scrubbed.encode("utf-8")
        return node

    def _handle_field(self, key: str, value: Any, *, person_scope: bool) -> Any:
        lkey = key.lower()
        policy = self.policy

        # 1) Objektové citlivé pole ({id, value}).
        if lkey in policy.sensitive_object_fields and isinstance(value, Mapping):
            # Sourozenecké klíče musí projít `_walk` — jinak by `note` nebo
            # `tel` vedle `value` prošly v otevřené podobě. (Větev 2 níže to
            # dělala správně, tato ne.)
            raw_value = value.get("value")
            out = self._walk(value, person_scope=person_scope)
            if isinstance(out, dict) and isinstance(raw_value, (str, int, float)):
                # Tokenizuje se původní hodnota, ne už zescrubovaná — jinak
                # vzniká HMAC z tokenu a tatáž hodnota dá jiný token podle
                # tvaru odpovědi.
                out["value"] = self.token(lkey.upper(), raw_value)
            return out

        # 2) Vnořené kategorie (např. photo.filename → FILE).
        nested = policy.nested_categories.get(lkey)
        if nested is not None and isinstance(value, Mapping):
            out = self._walk(value, person_scope=person_scope)
            if isinstance(out, dict):
                for inner_key in list(out):
                    category = nested.get(inner_key.lower())
                    if category and isinstance(out[inner_key], str) and out[inner_key]:
                        out[inner_key] = self.token(category, out[inner_key])
            return out

        # 3) Hook konektoru.
        hooked = self.handle_field(key, value, person_scope=person_scope)
        if hooked is not self.UNHANDLED:
            return hooked

        # 4) Jména.
        in_name_field = lkey in policy.name_fields or (
            person_scope and lkey in policy.person_scope_name_fields
        )
        if in_name_field:
            blank = isinstance(value, str) and not value.strip()
            if (
                self.redact_names
                and isinstance(value, (str, int, float))
                and not isinstance(value, bool)
                and value not in (None, "")
                and not blank  # "   " není jméno, jen prázdné pole
            ):
                return self.token("NAME", value)
            if isinstance(value, (Mapping, list)):
                return self._walk(value, person_scope=person_scope)
            return value

        # 5) Záznam osoby → rekurze s příznakem.
        if lkey in policy.person_scope_fields and isinstance(value, (Mapping, list)):
            return self._walk(value, person_scope=True)

        # 6) Kategorie podle přesného názvu.
        category = policy.field_category.get(lkey)
        if category is not None:
            return self._tokenize_by_category(category, value, person_scope=person_scope)

        # 7) Volný text — scrub a značka. Musí být před substring fallbackem:
        #    `description_invoice` je volný text, ne adresa, a tokenizovat ho
        #    celý do jednoho tokenu by zahodilo obsah i `[untrusted]` značku.
        if lkey in policy.freetext_fields and isinstance(value, str):
            return self.mark_untrusted(self._scrub_string(value))

        # 8) Substring fallback — chytí `*_invoice`, `*_postal`, custom pole.
        pattern = self._pattern_category(lkey)
        if pattern is not None:
            return self._tokenize_by_category(pattern, value, person_scope=person_scope)

        return self._walk(value, person_scope=person_scope)

    def _pattern_category(self, lkey: str) -> str | None:
        for needle, category in self.policy.pattern_category:
            if needle in lkey:
                return category
        return None

    def _tokenize_by_category(
        self, category: str, value: Any, *, person_scope: bool
    ) -> Any:
        if isinstance(value, bool) or value is None or value == "":
            return value
        if isinstance(value, (str, int, float)):
            return self.token(category, value)
        if isinstance(value, list):
            return [
                self.token(category, item)
                if isinstance(item, (str, int, float))
                and not isinstance(item, bool)
                and item not in (None, "")
                else self._walk(item, person_scope=person_scope)
                for item in value
            ]
        if isinstance(value, Mapping):
            # Fail-closed: PII pole dodané jako codebook objekt {id, value}
            # by jinak prošlo v otevřené podobě.
            raw_value = value.get("value")
            out = self._walk(value, person_scope=person_scope)
            if isinstance(out, dict) and isinstance(raw_value, (str, int, float)):
                # Původní hodnota, ne zescrubovaná — jinak by HMAC počítal
                # z tokenu a stejný e-mail by měl jiný token podle toho, či
                # přišel skalárně nebo jako codebook objekt.
                out["value"] = self.token(category, raw_value)
            return out
        return self._walk(value, person_scope=person_scope)


def pseudonymizer_for_request(
    policy: PiiPolicy,
    ctx: RequestContext,
    *,
    factory: Callable[..., Pseudonymizer] = Pseudonymizer,
) -> Pseudonymizer | None:
    """Postav pseudonymizér pro aktuální request, nebo ``None`` když je vypnutý."""
    config = ctx.config
    if policy.enable_config_key is not None and not bool(
        config.get(policy.enable_config_key, True)
    ):
        return None
    redact_names = policy.redact_names_default
    if policy.names_config_key is not None:
        redact_names = bool(config.get(policy.names_config_key, redact_names))
    key = derive_key(*policy.tenant_scope(ctx))
    return factory(key, policy, redact_names=redact_names)


__all__ = [
    "MAX_KNOWN_NAMES",
    "MIN_KNOWN_NAME_LEN",
    "RE_DATELIKE",
    "RE_EMAIL",
    "RE_PHONE",
    "RE_URL",
    "SALT_ENV",
    "TOKEN_HEX_LEN",
    "TOKEN_RE",
    "ConditionalName",
    "PiiPolicy",
    "Pseudonymizer",
    "assert_no_tokens",
    "contains_token",
    "derive_key",
    "pseudonymizer_for_request",
    "require_salt",
    "scope_by_sub",
    "scope_by_sub_and_tenant",
]
