"""Výměna delegovaného OAuth tokenu pro Dotykačku.

Dotykačka vydává dlouhodobý refresh token daného uživatele. Access token
platný pro konkrétní cloud se získá takto::

    POST https://api.dotykacka.cz/v2/signin/token
    Authorization: User {refresh_token}
    Content-Type: application/json

    {"_cloudId": "{cloud_id}"}

    -> 201 {"accessToken": "..."}

Volání API pak používají ``Authorization: Bearer {accessToken}`` vůči
``https://api.dotykacka.cz/v2`` s cestami vázanými na cloud
``/clouds/{cloud_id}/...``. Vydaný token platí zhruba hodinu; odpověď
neobsahuje žádné explicitní TTL, takže volající se spoléhají na
:data:`DEFAULT_EXPIRES_IN`.
"""

from __future__ import annotations

from dataclasses import dataclass

import httpx

from openmcp_sdk.envelope import ConnectorError, ErrorCode
from openmcp_sdk.http import map_http_exc, raise_for_status

#: Konzervativní výchozí životnost (55 min), když výměna neuvede TTL.
DEFAULT_EXPIRES_IN = 3300


@dataclass(frozen=True)
class DotykackaProvider:
    name: str = "dotykacka"
    signin_url: str = "https://api.dotykacka.cz/v2/signin/token"
    base_url: str = "https://api.dotykacka.cz/v2"
    timeout: float = 10.0

    def exchange(self, refresh_token: str, cloud_id: str) -> tuple[str, int]:
        headers = {
            "Authorization": f"User {refresh_token}",
            "Content-Type": "application/json",
        }
        try:
            response = httpx.post(
                self.signin_url,
                headers=headers,
                json={"_cloudId": cloud_id},
                timeout=self.timeout,
            )
        except httpx.HTTPError as exc:
            raise map_http_exc(exc) from exc

        # 401 zde znamená, že refresh token byl odvolán; raise_for_status jej
        # mapuje na FORBIDDEN a zneplatní cache přihlašovacích údajů daného uživatele.
        raise_for_status(response)

        try:
            data = response.json()
        except ValueError:
            raise ConnectorError(
                ErrorCode.UPSTREAM_ERROR, "OAuth token exchange vrátil neplatné JSON"
            ) from None

        token = data.get("accessToken") if isinstance(data, dict) else None
        if not isinstance(token, str) or not token:
            raise ConnectorError(
                ErrorCode.UPSTREAM_ERROR, "OAuth token exchange nevrátil accessToken"
            )

        expires_in = data.get("expiresIn")
        if isinstance(expires_in, bool) or not isinstance(expires_in, int):
            ttl = DEFAULT_EXPIRES_IN
        else:
            ttl = expires_in if expires_in > 0 else DEFAULT_EXPIRES_IN
        return token, ttl
