"""Strukturovaný výstup konektoru, provenance a typované veřejné chyby."""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from enum import Enum
from typing import Literal

from pydantic import AnyHttpUrl, BaseModel, ConfigDict, Field, TypeAdapter
from pydantic import field_validator

_UTC_SECONDS_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")
_SOURCE_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,127}$")
_HTTP_URL = TypeAdapter(AnyHttpUrl)


class ErrorCode(str, Enum):
    INVALID_INPUT = "invalid_input"
    # A syntactically valid lookup that did not resolve to an upstream record.
    # Keep this distinct from INVALID_INPUT so MCP clients can recommend a
    # search/current ID instead of asking the user to repair valid arguments.
    NOT_FOUND = "not_found"
    # Safe-test specific failures are explicit so the control plane can give
    # the user a corrective action without parsing localized human messages.
    CREDENTIAL_INVALID = "credential_invalid"
    INSTANCE_UNKNOWN = "instance_unknown"
    PROVIDER_PERMISSION_DENIED = "provider_permission_denied"
    UPSTREAM_UNAVAILABLE = "upstream_unavailable"
    UPSTREAM_ERROR = "upstream_error"
    RATE_LIMITED = "rate_limited"
    INTERNAL = "internal"
    FORBIDDEN = "forbidden"


class ConnectorError(Exception):
    """Typovaná chyba, kterou lze bezpečně vystavit přes MCP nebo HTTP odpověď."""

    def __init__(
        self, code: ErrorCode, message: str, *, status: int | None = None
    ) -> None:
        if not isinstance(code, ErrorCode):
            raise TypeError("code musí být ErrorCode")
        if not isinstance(message, str):
            raise TypeError("message musí být string")
        # Veřejné chyby drž na jednom řádku a omezené délky. Volající se
        # přesto musí vyhnout vkládání textu upstream výjimky; SDK helpery
        # to nikdy nedělají.
        message = " ".join(message.split()).strip()
        if not message:
            message = "chyba konektora"
        if len(message) > 1024:
            message = f"{message[:1021]}..."
        self.code = code
        self.message = message
        # HTTP stav upstreamu, když ho známe. ZÁMĚRNĚ mimo serializovanou
        # zprávu — je to diagnostika pro volajícího v procesu (např.
        # `test_connection` klasifikuje 401 vs 403 bez parsování textu),
        # ne součást veřejného kontraktu, který vidí model.
        self.status = status
        super().__init__(
            json.dumps(
                {"error": {"code": code.value, "message": message}},
                ensure_ascii=False,
            )
        )


def now_utc_iso() -> str:
    return (
        datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    )


class Provenance(BaseModel):
    model_config = ConfigDict(extra="forbid")

    source_id: str
    source_url: str
    retrieved_at: str
    freshness: Literal["live", "cached"] = "live"

    @field_validator("source_id")
    @classmethod
    def _valid_source_id(cls, value: str) -> str:
        if not _SOURCE_ID_RE.fullmatch(value):
            raise ValueError("source_id musí být bezpečný lowercase identifikátor")
        return value

    @field_validator("source_url")
    @classmethod
    def _valid_source_url(cls, value: str) -> str:
        _HTTP_URL.validate_python(value)
        return value

    @field_validator("retrieved_at")
    @classmethod
    def _valid_retrieved_at(cls, value: str) -> str:
        if not _UTC_SECONDS_RE.fullmatch(value):
            raise ValueError(
                "retrieved_at musí být UTC ISO-8601 s přesností na sekundy a Z"
            )
        # Regex kontroluje tvar; fromisoformat navíc odmítne nemožná data.
        datetime.fromisoformat(value.replace("Z", "+00:00"))
        return value


class EnvelopeBase(BaseModel):
    model_config = ConfigDict(extra="forbid")

    provenance: Provenance
    warnings: list[str] = Field(default_factory=list)
