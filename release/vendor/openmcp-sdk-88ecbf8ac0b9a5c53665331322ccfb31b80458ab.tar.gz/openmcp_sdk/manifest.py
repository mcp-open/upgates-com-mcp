"""Přísné schéma ``connector.yaml`` a konverze hodnot."""

from __future__ import annotations

import re
from typing import Any, Literal, Self

import yaml
from packaging.version import InvalidVersion, Version
from pydantic import BaseModel, ConfigDict, Field as PydField
from pydantic import ValidationError, field_validator, model_validator

_KEY_RE = re.compile(r"^[a-z][a-z0-9_]{0,63}$")
# Shodné s Go ``provision.slugRe`` (api/internal/provision/spec.go). Go je
# přísnější (3–32 znaků, musí začínat písmenem) a je závazný — je to jediný
# validátor, který běží při onboardingu. Kdyby SDK zůstalo volnější,
# `openmcp-sdk validate` by řeklo OK na slug, který API vzápětí odmítne.
_SLUG_RE = re.compile(r"^[a-z][a-z0-9-]{1,30}[a-z0-9]$")
_INT_RE = re.compile(r"^[+-]?\d+$")
_HTTP_METHODS = {"GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"}

# Cesty, na kterých SDK skutečně servíruje health endpoint (viz
# ``transport/http.py``). ``runtime.health_path`` se proti tomuto validuje —
# renderer z ní dělá httpGet probe, takže neexistující cesta = pod, který se
# nikdy nedostane do ready. Při přidání další health route rozšiř i toto.
SERVED_HEALTH_PATHS = frozenset({"/healthz"})


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class Field(StrictModel):
    key: str
    label: str = ""
    type: Literal["string", "int", "bool", "enum", "directory", "file"] = "string"
    secret: bool = False
    required: bool = False
    default: Any = None
    choices: list[str] = PydField(default_factory=list)
    multiple: bool = False
    hint: str = ""

    @field_validator("key")
    @classmethod
    def _valid_key(cls, value: str) -> str:
        if not _KEY_RE.fullmatch(value):
            raise ValueError(
                "key musí být snake_case identifikátor s nejvýše 64 znaky"
            )
        return value

    @model_validator(mode="after")
    def _valid_definition(self) -> Self:
        if self.type == "enum":
            if not self.choices:
                raise ValueError(f"enum pole {self.key!r} musí mít choices")
            if len(set(self.choices)) != len(self.choices):
                raise ValueError(f"enum pole {self.key!r} má duplicitní choices")
        elif self.choices:
            raise ValueError(f"choices jsou povolené jen pro enum pole {self.key!r}")
        if self.multiple and self.type not in {"directory", "file"}:
            raise ValueError(
                f"multiple je povolené jen pro directory/file pole {self.key!r}"
            )
        if self.secret and self.type != "string":
            raise ValueError(f"secret pole {self.key!r} musí mít type=string")
        if self.default is not None:
            try:
                self.parse(self.default)
            except ValueError as exc:
                raise ValueError(f"neplatný default pole {self.key!r}: {exc}") from exc
        return self

    def parse(self, value: Any) -> str | int | bool | list[str]:
        """Převeď hodnotu manifestu na typ pole bez benevolentních truthiness pravidel."""

        if self.type in {"directory", "file"}:
            if self.multiple:
                if not isinstance(value, list) or not value:
                    raise ValueError("očekává se neprázdný seznam cest")
                parsed: list[str] = []
                for item in value:
                    if not isinstance(item, str) or not item.strip():
                        raise ValueError("každá cesta musí být neprázdný string")
                    parsed.append(item.strip())
                return parsed
            if not isinstance(value, str) or not value.strip():
                raise ValueError("očekává se neprázdná cesta")
            return value.strip()
        if self.type in ("string", "enum"):
            if not isinstance(value, str):
                raise ValueError("očekává se string")
            value = value.strip()
            if self.type == "enum" and value not in self.choices:
                raise ValueError(f"povolené hodnoty: {', '.join(self.choices)}")
            return value
        if self.type == "bool":
            if isinstance(value, bool):
                return value
            if (
                isinstance(value, int)
                and not isinstance(value, bool)
                and value in (0, 1)
            ):
                return bool(value)
            if isinstance(value, str):
                normalized = value.strip().lower()
                if normalized in {"1", "true", "yes", "on"}:
                    return True
                if normalized in {"0", "false", "no", "off"}:
                    return False
            raise ValueError("očekává se true/false")
        if isinstance(value, bool):
            raise ValueError("očekává se celé číslo")
        if isinstance(value, int):
            return value
        if isinstance(value, str) and _INT_RE.fullmatch(value.strip()):
            return int(value.strip())
        raise ValueError("očekává se celé číslo")


class Capabilities(StrictModel):
    default_read_only: bool = True
    supports_write: bool = False
    supports_test: bool = False


class Auth(StrictModel):
    """Autentizační kontrakt konektoru.

    ``credentials`` (výchozí) zachovává historické chování: per-user secrets
    žijí v ``Manifest.credentials`` a čtou se přímo z Vaultu.

    ``oauth_delegated`` popisuje konektor, jehož upstream se volá s
    krátkodobým access tokenem vyraženým z per-user refresh tokenu. Operátor
    zaregistruje OAuth aplikaci (``operator_fields`` jako ``client_id`` /
    ``client_secret``); platforma provede uživatelský consent flow a zapíše
    výsledné ``runtime_secrets`` (např. ``refresh_token`` + ``cloud_id``)
    do per-user Vault blobu místo credentials ve stylu ``api_key``.
    """

    type: Literal["credentials", "oauth_delegated"] = "credentials"
    provider: str | None = None
    operator_fields: list[Field] = PydField(default_factory=list)
    runtime_secrets: list[str] = PydField(default_factory=list)

    @field_validator("runtime_secrets")
    @classmethod
    def _valid_runtime_secrets(cls, values: list[str]) -> list[str]:
        for value in values:
            if not _KEY_RE.fullmatch(value):
                raise ValueError(
                    f"runtime_secret {value!r} musí být snake_case identifikátor"
                )
        if len(set(values)) != len(values):
            raise ValueError("runtime_secrets obsahuje duplicity")
        return values

    @model_validator(mode="after")
    def _valid_auth(self) -> Self:
        operator_keys = [field.key for field in self.operator_fields]
        duplicates = sorted({key for key in operator_keys if operator_keys.count(key) > 1})
        if duplicates:
            raise ValueError(
                f"duplicitní auth.operator_fields keys: {', '.join(duplicates)}"
            )
        if self.type == "oauth_delegated":
            if not self.provider:
                raise ValueError("oauth_delegated auth vyžaduje provider")
            keys = {field.key for field in self.operator_fields}
            missing = {"client_id", "client_secret"} - keys
            if missing:
                raise ValueError(
                    "oauth_delegated operator_fields musí obsahovat "
                    f"{', '.join(sorted(missing))}"
                )
            secret_field = next(
                field for field in self.operator_fields if field.key == "client_secret"
            )
            if not secret_field.secret:
                raise ValueError("oauth_delegated client_secret musí mít secret=true")
            if not self.runtime_secrets:
                raise ValueError("oauth_delegated auth vyžaduje neprázdné runtime_secrets")
        else:  # credentials
            if self.provider is not None:
                raise ValueError("auth.provider je povolený jen pro oauth_delegated")
            if self.operator_fields:
                raise ValueError(
                    "auth.operator_fields jsou povolené jen pro oauth_delegated"
                )
            if self.runtime_secrets:
                raise ValueError(
                    "auth.runtime_secrets jsou povolené jen pro oauth_delegated"
                )
        return self


class EgressRule(StrictModel):
    host: str
    port: int = PydField(default=443, ge=1, le=65535)
    path_prefix: str = ""
    methods: list[str] = PydField(default_factory=lambda: ["GET"])

    def __getitem__(self, key: str) -> Any:
        """Zachovej read API ve stylu slovníku z 0.1, přitom vracej typovaný model."""

        if key not in type(self).model_fields:
            raise KeyError(key)
        return getattr(self, key)

    def get(self, key: str, default: Any = None) -> Any:
        try:
            return self[key]
        except KeyError:
            return default

    @field_validator("host")
    @classmethod
    def _valid_host(cls, value: str) -> str:
        if (
            not value
            or len(value) > 253
            or "://" in value
            or "/" in value
            or any(char.isspace() for char in value)
        ):
            raise ValueError("host musí být hostname bez schématu, portu a cesty")
        return value.lower()

    @field_validator("path_prefix")
    @classmethod
    def _valid_path_prefix(cls, value: str) -> str:
        if value and (not value.startswith("/") or ".." in value.split("/")):
            raise ValueError("path_prefix musí být absolutní cesta bez '..'")
        return value.rstrip("/") if value != "/" else value

    @field_validator("methods")
    @classmethod
    def _valid_methods(cls, values: list[str]) -> list[str]:
        normalized = [value.upper() for value in values]
        if not normalized or any(value not in _HTTP_METHODS for value in normalized):
            raise ValueError("methods obsahuje nepodporovanou HTTP metodu")
        if len(set(normalized)) != len(normalized):
            raise ValueError("methods obsahuje duplicity")
        return normalized


class Runtime(StrictModel):
    """Provisioning kontrakt pro connector-operator (app-driven onboarding).

    Zrcadlí Go strukturu ``provision.Runtime`` (``api/internal/provision/spec.go``)
    pole po poli včetně sémantiky „nezadáno". Defaulty se tu ZÁMĚRNĚ nedoplňují:
    ``None``/``""`` znamená „renderer si doplní svůj default" (replicas → 2,
    prázdná health_path → tcpSocket, vault_ttl → SDK default 60 s). Kdyby SDK
    doplnilo vlastní defaulty, oba modely by se znovu rozešly — přesně to je
    důvod, proč tento model vzniká.
    """

    replicas: int | None = PydField(default=None, ge=0)
    pii_salt: bool = False
    health_path: str = ""
    vault_ttl: int | None = PydField(default=None, ge=0)

    @field_validator("health_path")
    @classmethod
    def _valid_health_path(cls, value: str) -> str:
        if not value:
            return value
        if not value.startswith("/") or ".." in value.split("/"):
            raise ValueError("runtime.health_path musí být absolutní cesta bez '..'")
        if value not in SERVED_HEALTH_PATHS:
            # Renderer z této hodnoty udělá httpGet probe. Cesta, kterou SDK
            # neservíruje, dá pod, který se nikdy nedostane do ready — a to se
            # projeví až při rolloutu, ne tady.
            raise ValueError(
                f"runtime.health_path {value!r} SDK neservíruje "
                f"(dostupné: {', '.join(sorted(SERVED_HEALTH_PATHS))})"
            )
        return value


class DisplayTool(StrictModel):
    name: str
    description: str = ""

    @field_validator("name")
    @classmethod
    def _valid_name(cls, value: str) -> str:
        if not re.fullmatch(r"[a-zA-Z][a-zA-Z0-9_.-]{0,127}", value):
            raise ValueError("display.tools.name má neplatný formát")
        return value


class DisplayField(StrictModel):
    key: str
    label: str
    # Lokalizovaná nápověda k poli. Bez ní zbýval jen `Field.hint` z kořene
    # manifestu, psaný jedním jazykem — a protože API lokalizací hint vždy
    # přepíše (`catalog/localization.go`), pole bez překladu zůstalo v UI
    # úplně bez nápovědy. Volitelná, aby starší manifesty a
    # `display.schema_version: 0` zůstaly načitatelné.
    hint: str = ""


class DisplayLocale(StrictModel):
    name: str
    description: str
    capabilities: list[str]
    permissions: list[str]
    data_handling: str
    example_query: str
    fields: list[DisplayField] = PydField(default_factory=list)
    tools: list[DisplayTool] = PydField(default_factory=list)
    limitations: list[str] = PydField(default_factory=list)


class Display(StrictModel):
    # Legacy runtime manifests remain loadable so an SDK patch release does not
    # crash already deployed connectors. Platform publication is stricter and
    # requires schema_version=1 plus complete CS/SK locales (see cli.py and API).
    schema_version: int = 0
    capabilities: list[str] = PydField(default_factory=list)
    permissions: list[str] = PydField(default_factory=list)
    data_handling: str = ""
    example_query: str = ""
    tools: list[DisplayTool] = PydField(default_factory=list)
    locales: dict[str, DisplayLocale] = PydField(default_factory=dict)

    @model_validator(mode="after")
    def _valid_locales(self) -> Self:
        if self.schema_version == 0 and not self.locales:
            return self
        if self.schema_version != 1:
            raise ValueError("display.schema_version musí být 1")
        tool_names = [tool.name for tool in self.tools]
        if len(tool_names) != len(set(tool_names)):
            raise ValueError("display.tools obsahuje duplicitní name")
        expected_tools = set(tool_names)
        for locale_name in ("cs", "sk"):
            locale = self.locales.get(locale_name)
            if locale is None:
                raise ValueError(f"display.locales.{locale_name} chybí")
            if not all(
                (
                    locale.name.strip(),
                    locale.description.strip(),
                    locale.capabilities,
                    locale.permissions,
                    locale.data_handling.strip(),
                    locale.example_query.strip(),
                )
            ):
                raise ValueError(f"display.locales.{locale_name} není úplný")
            localized_tools = [tool.name for tool in locale.tools]
            if len(localized_tools) != len(set(localized_tools)) or set(localized_tools) != expected_tools:
                raise ValueError(
                    f"display.locales.{locale_name}.tools musí přesně pokrýt display.tools"
                )
            if any(not tool.description.strip() for tool in locale.tools):
                raise ValueError(
                    f"display.locales.{locale_name}.tools obsahuje prázdný description"
                )
        return self


class Manifest(StrictModel):
    slug: str
    name: str
    version: str
    category: str = ""
    summary: str = ""
    sdk_min_version: str = "0.0.0"
    credentials: list[Field] = PydField(default_factory=list)
    user_config: list[Field] = PydField(default_factory=list)
    operator_config: list[Field] = PydField(default_factory=list)
    capabilities: Capabilities = PydField(default_factory=Capabilities)
    auth: Auth = PydField(default_factory=Auth)
    display: Display | None = None
    egress: EgressRule | None = None
    runtime: Runtime = PydField(default_factory=Runtime)

    @field_validator("slug")
    @classmethod
    def _valid_slug(cls, value: str) -> str:
        if not _SLUG_RE.fullmatch(value):
            raise ValueError(
                "slug musí být lowercase DNS-safe identifikátor: 3–32 znaků, "
                "začíná písmenem, končí alfanumericky (^[a-z][a-z0-9-]{1,30}[a-z0-9]$)"
            )
        return value

    @field_validator("version", "sdk_min_version")
    @classmethod
    def _valid_version(cls, value: str) -> str:
        try:
            Version(value)
        except InvalidVersion as exc:
            raise ValueError("očekává se platná PEP 440/SemVer verze") from exc
        return value

    @field_validator("egress", mode="before")
    @classmethod
    def _empty_egress_is_none(cls, value: Any) -> Any:
        return None if value == {} else value

    @model_validator(mode="after")
    def _valid_fields(self) -> Self:
        groups = self.credentials + self.user_config + self.operator_config
        keys = [field.key for field in groups]
        duplicates = sorted({key for key in keys if keys.count(key) > 1})
        if duplicates:
            raise ValueError(f"duplicitní manifest keys: {', '.join(duplicates)}")
        for field in self.credentials:
            if field.type in {"directory", "file"}:
                raise ValueError(
                    f"credentials pole {field.key!r} nesmí být directory/file"
                )
            if field.secret and field.default is not None:
                raise ValueError(f"secret pole {field.key!r} nesmí mít default v YAML")
        for field in self.user_config + self.operator_config:
            if field.secret:
                raise ValueError(
                    f"secret=true je povolené jen v credentials ({field.key!r})"
                )
        for field in self.operator_config:
            if field.type in {"directory", "file"}:
                raise ValueError(
                    f"operator_config pole {field.key!r} nesmí být directory/file"
                )
        if self.auth.type == "oauth_delegated":
            if self.credentials:
                raise ValueError(
                    "oauth_delegated auth nesmí deklarovat credentials[]"
                )
            overlap = sorted(set(self.auth.runtime_secrets) & set(keys))
            if overlap:
                raise ValueError(
                    "auth.runtime_secrets kolidují s manifest keys: "
                    f"{', '.join(overlap)}"
                )
        if self.display is not None and self.display.schema_version == 1:
            expected_fields = {field.key for field in self.credentials + self.user_config}
            for locale_name in ("cs", "sk"):
                localized_fields = self.display.locales[locale_name].fields
                localized_keys = [field.key for field in localized_fields]
                if len(localized_keys) != len(set(localized_keys)) or set(localized_keys) != expected_fields:
                    raise ValueError(
                        f"display.locales.{locale_name}.fields musí přesně pokrýt credentials a user_config"
                    )
                if any(not field.label.strip() for field in localized_fields):
                    raise ValueError(
                        f"display.locales.{locale_name}.fields obsahuje prázdný label"
                    )
        if not self.capabilities.supports_write:
            # Konektor bez deklarované write schopnosti nesmí manifestem
            # tvrdit opak. Skutečný invariant (žádný registrovaný mutující
            # nástroj) se dá ověřit až proti běžícímu serveru — dělá to
            # `run_connector` při startu. Tady zůstávají dvě statické kontroly.
            #
            # POZOR: NEOMEZOVAT `egress.methods` na GET — read-only konektor
            # legitimně používá POST na vyhledávání (ares má `[GET, POST]`
            # a `supports_write: false`). Metoda upstreamu nevypovídá o tom,
            # jestli konektor zapisuje do cizích dat.
            if not self.capabilities.default_read_only:
                raise ValueError(
                    "capabilities: supports_write=false a default_read_only=false "
                    "si protiřečí — konektor bez zápisu nemůže mít zápis jako default"
                )
            dead = [
                field.key
                for field in self.operator_config
                if field.key == "require_write_confirmation"
            ]
            if dead:
                raise ValueError(
                    "operator_config.require_write_confirmation nemá smysl při "
                    "supports_write=false — byl by to mrtvý přepínač v UI"
                )
        return self

    def env_names(self) -> dict[str, str]:
        """Názvy proměnných prostředí pro credentials a uživatelskou konfiguraci."""

        return {
            field.key: f"{self.slug}_{field.key}".upper()
            for field in self.credentials + self.user_config
        }

    def operator_env_names(self) -> dict[str, str]:
        return {
            field.key: f"{self.slug}_{field.key}".upper()
            for field in self.operator_config
        }

    def runtime_secret_env_names(self) -> dict[str, str]:
        """Názvy proměnných prostředí pro local-stdio runtime secrets delegovaného OAuth."""

        return {
            key: f"{self.slug}_{key}".upper() for key in self.auth.runtime_secrets
        }


def load_manifest(path: str) -> Manifest:
    try:
        with open(path, encoding="utf-8") as file:
            data = yaml.safe_load(file)
    except yaml.YAMLError as exc:
        raise ValueError(f"neplatný YAML v manifestu {path}: {exc}") from exc
    except OSError as exc:
        raise ValueError(
            f"manifest {path} se nedá načíst: {exc.strerror or 'I/O chyba'}"
        ) from exc

    if not isinstance(data, dict):
        raise ValueError(f"manifest {path} musí být YAML mapa")

    try:
        return Manifest.model_validate(data)
    except ValidationError as exc:
        raise ValueError(f"neplatný manifest {path}: {exc}") from exc
