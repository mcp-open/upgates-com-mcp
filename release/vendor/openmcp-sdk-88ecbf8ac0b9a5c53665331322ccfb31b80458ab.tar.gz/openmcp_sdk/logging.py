"""Strukturované logování s vícevrstvou redakcí tajemství a PII."""

from __future__ import annotations

import json
import logging
import os
import re
import sys
import time

_LOG_FORMAT = "%(asctime)s %(levelname)s %(name)s %(message)s"
_EMAIL_RE = re.compile(r"(?<![\w.+-])[\w.+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}(?![\w.-])")
_BEARER_RE = re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._~+/=-]+")
_AUTHORIZATION_RE = re.compile(
    r"(?i)([\"']?(?:proxy-)?authorization[\"']?\s*[:=]\s*[\"']?)"
    r"(?:[A-Za-z][A-Za-z0-9._~-]*\s+)?([^\s,;\"'}]+)"
)
_SENSITIVE_PAIR_RE = re.compile(
    r"(?i)\b(api[_-]?key|access[_-]?token|refresh[_-]?token|token|password|secret)"
    r"(\s*[\"']?\s*[:=]\s*[\"']?)([^\s,;\"'}]+)"
)


def redact(value: str) -> str:
    # Covers provider-specific schemes (for example Dotykačka ``User``) and
    # HTTP Basic in addition to Bearer.
    value = _AUTHORIZATION_RE.sub(r"\1<redacted>", value)
    value = _BEARER_RE.sub("Bearer <redacted>", value)
    value = _SENSITIVE_PAIR_RE.sub(r"\1\2<redacted>", value)
    return _EMAIL_RE.sub("<EMAIL>", value)


class _RedactingTextFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        return redact(super().format(record))


class _JsonFormatter(logging.Formatter):
    def __init__(self, component: str) -> None:
        super().__init__()
        self._component = component

    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "time": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created))
            + f".{int(record.msecs):03d}Z",
            "level": record.levelname,
            "component": self._component,
            "logger": record.name,
            "msg": redact(record.getMessage()),
        }
        if record.exc_info:
            payload["exc"] = redact(self.formatException(record.exc_info))
        return json.dumps(payload, ensure_ascii=False)


def setup(level: str | int = "INFO", component: str | None = None) -> None:
    component = component or os.getenv("OPENMCP_COMPONENT", "connector")
    handler = logging.StreamHandler(stream=sys.stderr)
    if os.getenv("OPENMCP_LOG_FORMAT", "json").lower() == "text":
        handler.setFormatter(_RedactingTextFormatter(_LOG_FORMAT))
    else:
        handler.setFormatter(_JsonFormatter(component))
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(level)
    # httpx logs the complete request URL at INFO, including query values.
    # Connector search filters commonly contain names, phone numbers and
    # company names, which cannot be reliably redacted by a generic regexp.
    # Keep transport failures, but never emit successful request URLs.
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)


def safe(value: str | None, keep: int = 2) -> str:
    """Zamaskuj hodnotu pro explicitní diagnostické logování.

    ``keep=0`` hodnotu úplně zamaskuje; záporné hodnoty se odmítají, místo aby
    produkovaly překvapivé výřezy, které by mohly prozradit původní tajemství.
    """

    if keep < 0:
        raise ValueError("keep nesmí být záporné")
    if not value:
        return ""
    if keep == 0 or len(value) <= keep * 2:
        return "*" * len(value)
    return f"{value[:keep]}{'*' * (len(value) - keep * 2)}{value[-keep:]}"
