"""openmcp_sdk.identity.base — IdentityProvider kontrakt."""

from __future__ import annotations

from typing import Mapping, Protocol

from openmcp_sdk.context import Principal


class IdentityProvider(Protocol):
    def principal_from_headers(self, headers: Mapping[str, str]) -> Principal: ...
