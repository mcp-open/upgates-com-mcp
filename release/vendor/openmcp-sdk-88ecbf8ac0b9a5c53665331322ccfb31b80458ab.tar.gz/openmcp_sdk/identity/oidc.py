"""Self-hosted OIDC identita odvozená pouze z ověřených JWT claims."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Any

from fastmcp.server.auth import JWTVerifier
from fastmcp.server.dependencies import get_access_token

from openmcp_sdk.context import Principal
from openmcp_sdk.envelope import ConnectorError, ErrorCode


class OidcIdentity:
    def __init__(
        self,
        issuer: str,
        jwks_uri: str,
        audience: str,
        token_getter: Callable[[], Any] | None = None,
    ) -> None:
        if not issuer or not jwks_uri or not audience:
            raise ValueError("OIDC issuer, JWKS URI a audience nesmí být prázdné")
        self.issuer = issuer
        self.jwks_uri = jwks_uri
        self.audience = audience
        self._token_getter = token_getter

    def verifier(self) -> JWTVerifier:
        return JWTVerifier(
            jwks_uri=self.jwks_uri,
            issuer=self.issuer,
            audience=self.audience,
        )

    def principal_from_headers(self, headers: Mapping[str, str]) -> Principal:
        # FastMCP's AuthenticationMiddleware ověří bearer token dřív, než
        # proběhne OpenMCP ContextMiddleware. V self-hosted módu se nikdy
        # nesmí spadnout zpět na hlavičky X-OpenMCP-*, které kontroluje klient.
        del headers
        token = (
            get_access_token() if self._token_getter is None else self._token_getter()
        )
        if token is None:
            raise ConnectorError(ErrorCode.FORBIDDEN, "chybí ověřená identita")
        claims = token.claims
        sub = claims.get("sub")
        if not isinstance(sub, str) or not sub:
            raise ConnectorError(ErrorCode.FORBIDDEN, "JWT neobsahuje platný sub claim")
        email = claims.get("email")
        if email is not None and not isinstance(email, str):
            raise ConnectorError(
                ErrorCode.FORBIDDEN, "JWT obsahuje neplatný email claim"
            )
        credential_version = claims.get("openmcp_credential_version")
        if credential_version is not None and (
            isinstance(credential_version, bool)
            or not isinstance(credential_version, int)
        ):
            raise ConnectorError(
                ErrorCode.FORBIDDEN,
                "JWT obsahuje neplatnou verzi přihlašovacích údajů",
            )
        owner_kind = claims.get("openmcp_credential_owner_kind")
        owner_id = claims.get("openmcp_credential_owner_id")
        if owner_kind is not None and not isinstance(owner_kind, str):
            raise ConnectorError(ErrorCode.FORBIDDEN, "JWT obsahuje neplatného vlastníka")
        if owner_id is not None and not isinstance(owner_id, str):
            raise ConnectorError(ErrorCode.FORBIDDEN, "JWT obsahuje neplatného vlastníka")
        return Principal(sub, email, credential_version, owner_kind, owner_id)
