"""Identita potvrzená gateway OpenMCP.

Samotná hlavička se subjektem není bezpečnostní hranicí. Hostované konektory
proto vyžadují i sdílený interní token, který vkládá gateway a který se
porovnává v konstantním čase. Přímý přístup k podu tak nemůže vydávat se za
jiný subjekt.
"""

from __future__ import annotations

from collections.abc import Mapping
from secrets import compare_digest

from openmcp_sdk.context import Principal
from openmcp_sdk.envelope import ConnectorError, ErrorCode

_SUB_HEADER = "x-openmcp-sub"
_PROOF_HEADER = "x-openmcp-gateway-token"
_CREDENTIAL_VERSION_HEADER = "x-openmcp-credential-version"
_CREDENTIAL_OWNER_KIND_HEADER = "x-openmcp-credential-owner-kind"
_CREDENTIAL_OWNER_ID_HEADER = "x-openmcp-credential-owner-id"


class GatewayIdentity:
    def __init__(self, shared_secret: str) -> None:
        if not isinstance(shared_secret, str) or len(shared_secret) < 32:
            raise ValueError("gateway shared secret musí mít alespoň 32 znaků")
        self._shared_secret = shared_secret

    def principal_from_headers(self, headers: Mapping[str, str]) -> Principal:
        lowered = {key.lower(): value for key, value in headers.items()}
        proof = lowered.get(_PROOF_HEADER, "")
        if not compare_digest(proof, self._shared_secret):
            raise ConnectorError(
                ErrorCode.FORBIDDEN, "nedůvěryhodný požadavek gateway"
            )
        sub = lowered.get(_SUB_HEADER)
        if not sub:
            raise ConnectorError(ErrorCode.FORBIDDEN, "chybí ověřená identita")
        raw_version = lowered.get(_CREDENTIAL_VERSION_HEADER)
        owner_kind = lowered.get(_CREDENTIAL_OWNER_KIND_HEADER)
        owner_id = lowered.get(_CREDENTIAL_OWNER_ID_HEADER)
        credential_version: int | None = None
        if raw_version is not None:
            # Strict decimal syntax: signs, whitespace, zero and oversized
            # integers are rejected instead of being coerced.
            if not raw_version.isascii() or not raw_version.isdecimal():
                raise ConnectorError(
                    ErrorCode.FORBIDDEN, "neplatná verze přihlašovacích údajů"
                )
            credential_version = int(raw_version)
        return Principal(
            sub,
            credential_version=credential_version,
            credential_owner_kind=owner_kind,
            credential_owner_id=owner_id,
        )
