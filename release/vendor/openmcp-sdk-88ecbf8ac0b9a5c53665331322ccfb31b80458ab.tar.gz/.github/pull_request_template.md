## Proč

<!-- Jaký problém to řeší. Ne co kód dělá — to je vidět z diffu. -->

## Dopad na konektory

<!-- Musí konektor po této změně něco udělat? Pokud ano, jak. Pokud ne, napište „žádný". -->

## Kontrolní seznam

- [ ] `ruff check openmcp_sdk tests` prochází
- [ ] `pytest -q` prochází
- [ ] `python -m build --wheel` prochází
- [ ] Změna má test, který bez ní padá
- [ ] Změna manifestu, identity, transportu nebo veřejného API má záznam v `CHANGELOG.md`
- [ ] Nové veřejné API je popsané v `README.md`
- [ ] V diffu nejsou tajemství, `.env` soubory ani produkční logy
