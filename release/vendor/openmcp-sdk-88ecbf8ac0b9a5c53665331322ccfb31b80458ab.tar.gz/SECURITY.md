# Bezpečnostní politika

## Hlášení zranitelnosti

Nálezy **neposílejte do veřejných issue ani pull requestů**. Použijte jeden
z těchto kanálů:

- [GitHub Security Advisory](https://github.com/mcp-open/openmcp-sdk/security/advisories/new) — preferovaná cesta
- e-mail: **security@openmcp.cz**

Do hlášení uveďte verzi SDK, kroky k reprodukci a odhad dopadu. **Nikdy
nevkládejte skutečné tokeny, API klíče, refresh tokeny ani osobní údaje** —
stačí popis, kde a jak jsou zasažené.

Na první reakci se snažíme odpovědět do 5 pracovních dnů. Do vyřešení nálezu
prosíme o nezveřejňování detailů.

## Podporované verze

Opravy dostávají poslední dvě minor verze. Bezpečnostní oprava se popisuje
v `CHANGELOG.md` a vyžaduje aktualizaci konektorů, které SDK připínají přes
`.sdk-ref` nebo commit v `pyproject.toml`.

| Verze | Stav |
|---|---|
| 0.4.x | podporovaná |
| 0.3.x | podporovaná (jen bezpečnostní opravy) |
| ≤ 0.2.x | nepodporovaná |

## Co SDK považuje za bezpečnostní hranici

Tyto vlastnosti jsou záměrné a jejich porušení je zranitelnost, ne chyba
v konfiguraci:

- **Identita není hlavička.** V režimu `hosted` musí každý request nést sdílené
  tajemství gatewaye, které se porovnává v konstantním čase dřív, než se sáhne
  na jakékoli tajemství. V `self-hosted` je zdrojem identity výhradně ověřený
  OIDC access token; klientské hlavičky `X-OpenMCP-*` se jako záloha nepoužijí.
- **Přesná verze přihlašovacích údajů.** Runtime nikdy nečte z Vaultu `latest` —
  jen verzi, kterou určí control plane. Rozpracovaná rotace se tak nemůže
  dostat do provozu.
- **Fail-closed read-only.** Chybějící nebo nejednoznačná anotace nástroje
  znamená „mutující"; v read-only instanci se takový nástroj odstraní.
- **Tělo upstream odpovědi nejde do chybové zprávy.** Mohlo by nést text
  napsaný cizím uživatelem a putovalo by přímo do kontextu modelu.
- **Tajemství se nelogují.** Logging se nastavuje jako první krok startu, aby
  ani chyby při inicializaci neunikly bez redakce.
- **TLS Vaultu se nedá vypnout.** SDK nenabízí přepínač, který by ověření
  certifikátu nebo hostname obešel.
- **Jednosměrná pseudonymizace.** Tokeny osobních údajů vznikají HMAC-SHA256
  a nikde nevzniká re-identifikační mapa.

Nález, který některou z těchto hranic obchází, hlaste prosím výše uvedeným
kanálem.
