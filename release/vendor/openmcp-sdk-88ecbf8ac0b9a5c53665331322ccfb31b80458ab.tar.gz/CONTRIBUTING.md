# Jak přispívat

Díky za zájem. SDK je jádro, na kterém stojí všechny konektory OpenMCP —
změna se propíše do každého z nich, proto jsou nároky na příspěvky vyšší než
u běžné knihovny.

## Prostředí

```bash
uv venv -p 3.13 && . .venv/bin/activate
pip install -e '.[test]' ruff==0.15.22 build==1.5.0
```

Podporovaný Python je 3.12 a novější; CI staví na 3.12, 3.13 a 3.14.

## Před odesláním změny

```bash
ruff check openmcp_sdk tests
pytest -q
python -m build --wheel
```

Všechno tři musí projít — CI spouští totéž a nic navíc nepovoluje.

## Co od změny čekáme

- **Test, který bez opravy padá.** U oprav chyb i u nových funkcí. Testy jsou
  v `tests/`, pojmenované podle modulu.
- **Popis proč, ne co.** Komentář i zpráva commitu mají vysvětlit důvod
  rozhodnutí; co kód dělá, je vidět z kódu. Komentáře a dokumentace jsou česky.
- **Záznam v `CHANGELOG.md`** u každé změny manifestu, identity, transportu
  nebo veřejného API — včetně migrační poznámky, pokud konektor musí něco
  udělat.
- **Zpětná kompatibilita.** Konektory připínají SDK na commit. Rozbíjející
  změnu doprovoďte bumpem minor verze v `openmcp_sdk/_version.py` a jasným
  postupem migrace.
- **Veřejné API patří do README.** Co není zdokumentované, neexistuje.

## Co do repozitáře nepatří

Tajemství, soubory `.env`, produkční logy, dumpy zákaznických dat a odkazy na
interní infrastrukturu.

## Bezpečnostní změny

Úpravy identity, práce s Vaultem, pseudonymizace nebo mapování chyb mají
přímý bezpečnostní dopad — přečtěte si nejdřív [SECURITY.md](SECURITY.md),
kde jsou vypsané hranice, které SDK garantuje. Zranitelnost nikdy nehlaste
veřejným issue ani PR.
