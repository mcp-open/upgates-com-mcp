import pytest

from openmcp_sdk.context import (
    AccessPolicy,
    Principal,
    RequestContext,
    WriteDecision,
    require_write_access,
    reset_context,
    set_context,
)
from openmcp_sdk.envelope import ConnectorError, ErrorCode
from openmcp_sdk.write import (
    WriteBudget,
    WriteTarget,
    audit_write,
    build_payload,
    diff_lines,
    execute_write,
)


@pytest.fixture
def ctx_factory():
    """Nastaví request kontext pro test.

    Při async testech běží tělo v samostatném anyio kontextu, takže token
    vytvořený uvnitř se v teardownu (zpět v hlavním kontextu) resetovat nedá —
    a ani netřeba: contextvar nastavený v tom kontextu s ním i zanikne.
    Při sync testech reset proběhne normálně.
    """
    tokens = []

    def make(policy: AccessPolicy | None = None, **config):
        ctx = RequestContext(
            principal=Principal(sub="user-1"),
            config=config,
            policy=policy or AccessPolicy(mode="allow_write"),
        )
        tokens.append(set_context(ctx))
        return ctx

    yield make
    for token in reversed(tokens):
        try:
            reset_context(token)
        except ValueError:
            pass


# -- vada 8: approval_required se choval jako read_only ------------------------


def test_approval_required_no_longer_means_read_only():
    """Regrese: do 0.4 `approval_required` zápis rovnou zamítlo.

    Workspace, který si vyžádal „zápis s potvrzením", tiše dostal „žádný
    zápis" — a pole `require_approval` nečetl nikdo.
    """
    policy = AccessPolicy(mode="approval_required")
    assert policy.write_decision("update_x") is WriteDecision.REQUIRE_APPROVAL
    assert policy.can_call("update_x", read_only=False) is True


@pytest.mark.parametrize(
    "policy,expected",
    [
        (AccessPolicy(mode="allow_write"), WriteDecision.ALLOW),
        (AccessPolicy(mode="read_only"), WriteDecision.DENY),
        (AccessPolicy(mode="disabled"), WriteDecision.DENY),
        (AccessPolicy(mode="approval_required"), WriteDecision.REQUIRE_APPROVAL),
        (
            AccessPolicy(mode="allow_write", require_approval=True),
            WriteDecision.REQUIRE_APPROVAL,
        ),
        (
            AccessPolicy(mode="allow_write", allowed_tools=frozenset({"iny"})),
            WriteDecision.DENY,
        ),
    ],
)
def test_write_decision_matrix(policy, expected):
    assert policy.write_decision("update_x") is expected


def test_require_write_access_is_stricter_than_can_call(ctx_factory):
    """Kdo volá jen `require_write_access`, nemá jak potvrzení vyžádat.

    Proto propouští pouze ALLOW — jinak by při `approval_required` prošel
    zápis nepotvrzený.
    """
    ctx_factory(AccessPolicy(mode="approval_required"))
    with pytest.raises(ConnectorError) as excinfo:
        require_write_access("update_x")
    assert excinfo.value.code is ErrorCode.FORBIDDEN


def test_require_write_access_allows_plain_allow_write(ctx_factory):
    ctx_factory(AccessPolicy(mode="allow_write"))
    require_write_access("update_x")


# -- build_payload -------------------------------------------------------------


def test_build_payload_drops_none_and_keeps_falsy():
    assert build_payload(a=1, b=None, c="", d=0, e=False) == {
        "a": 1,
        "c": "",
        "d": 0,
        "e": False,
    }


def test_build_payload_rejects_pseudonymisation_token():
    with pytest.raises(ConnectorError) as excinfo:
        build_payload(email="<EMAIL_a8e7085b246f>")
    assert excinfo.value.code is ErrorCode.INVALID_INPUT


def test_build_payload_rejects_nested_token():
    with pytest.raises(ConnectorError):
        build_payload(contact={"emails": ["<EMAIL_a8e7085b246f>"]})


# -- WriteBudget ---------------------------------------------------------------


def test_budget_blocks_after_limit():
    budget = WriteBudget(limit=3, window_s=300, _clock=lambda: 0.0)
    for _ in range(3):
        budget.check("user-1")
        budget.record("user-1")
    with pytest.raises(ConnectorError) as excinfo:
        budget.check("user-1")
    assert excinfo.value.code is ErrorCode.FORBIDDEN


def test_check_alone_never_consumes_budget():
    """`check` je otázka, ne zápis do historie.

    Oddělení od `record` je to, co brání tomu, aby odmítnuté potvrzení
    minulo rozpočet.
    """
    budget = WriteBudget(limit=1, window_s=300, _clock=lambda: 0.0)
    for _ in range(50):
        budget.check("user-1")
    assert budget._log == {}


def test_reset_clears_history():
    budget = WriteBudget(limit=1, window_s=300, _clock=lambda: 0.0)
    budget.record("user-1")
    budget.reset()
    budget.check("user-1")


def test_budget_window_slides():
    now = [0.0]
    budget = WriteBudget(limit=2, window_s=100, _clock=lambda: now[0])
    budget.record("user-1")
    budget.record("user-1")
    with pytest.raises(ConnectorError):
        budget.check("user-1")
    now[0] = 101.0
    budget.check("user-1")  # staré záznamy vypadly z okna


def test_budget_is_per_principal():
    budget = WriteBudget(limit=1, window_s=300, _clock=lambda: 0.0)
    budget.record("user-1")
    budget.check("user-2")
    with pytest.raises(ConnectorError):
        budget.check("user-1")


# -- diff ----------------------------------------------------------------------


def test_diff_lines_marks_missing_before():
    lines = diff_lines({"a": "staré"}, {"a": "nové", "b": "pridané"})
    assert lines == ["  a: 'staré' → 'nové'", "  b: '—' → 'pridané'"]


# -- execute_write -------------------------------------------------------------


class _Elicit:
    """Náhrada fastmcp kontextu s řiditelnou odpovědí."""

    def __init__(self, behaviour="accept"):
        self.behaviour = behaviour
        self.messages: list[str] = []

    async def elicit(self, message, response_type=None):
        self.messages.append(message)
        if self.behaviour == "unsupported":
            raise RuntimeError("klient elicitation nevie")

        class _Accepted:
            action = "accept"

        class _Declined:
            action = "decline"

        return _Accepted() if self.behaviour == "accept" else _Declined()


@pytest.fixture
def elicit(monkeypatch):
    holder = {}

    def install(behaviour="accept"):
        fake = _Elicit(behaviour)
        holder["fake"] = fake
        import fastmcp.server.dependencies as deps

        monkeypatch.setattr(deps, "get_context", lambda: fake)
        # `confirm_write` importuje typy při importu modulu; když fastmcp typy
        # existují, náš duck-type by neprošel — vypneme je pro test.
        import openmcp_sdk.write as write_mod

        monkeypatch.setattr(write_mod, "_ACCEPTED", ())
        return fake

    return install


@pytest.mark.anyio
async def test_execute_write_denied_by_policy(ctx_factory, elicit):
    elicit()
    ctx_factory(AccessPolicy(mode="read_only"))
    with pytest.raises(ConnectorError) as excinfo:
        await execute_write(
            "update_x",
            WriteTarget("company", 1),
            {"name": "A"},
            apply=lambda body: {"ok": True},
            product="TEST",
        )
    assert excinfo.value.code is ErrorCode.FORBIDDEN


@pytest.mark.anyio
async def test_execute_write_happy_path_with_confirmation(ctx_factory, elicit):
    fake = elicit("accept")
    ctx_factory(AccessPolicy(mode="allow_write"))
    applied = {}

    result = await execute_write(
        "update_company",
        WriteTarget("company", 7),
        {"name": "Nové"},
        apply=lambda body: applied.update(body) or {"id": 7},
        fetch_before=lambda target, fields: {"name": "Staré"},
        product="TEST CRM",
    )
    assert result == {"id": 7}
    assert applied == {"name": "Nové"}
    assert "company #7" in fake.messages[0]
    assert "'Staré' → 'Nové'" in fake.messages[0]


@pytest.mark.anyio
async def test_execute_write_declined_does_not_apply(ctx_factory, elicit):
    elicit("decline")
    ctx_factory(AccessPolicy(mode="allow_write"))
    calls = []

    with pytest.raises(ConnectorError):
        await execute_write(
            "update_x",
            WriteTarget("company", 1),
            {"a": 1},
            apply=lambda body: calls.append(body),
            product="TEST",
        )
    assert calls == []


@pytest.mark.anyio
async def test_execute_write_fails_closed_without_elicitation(ctx_factory, elicit):
    """Klient bez podpory elicitation → zápis se NEPROVEDE."""
    elicit("unsupported")
    ctx_factory(AccessPolicy(mode="allow_write"))
    calls = []

    with pytest.raises(ConnectorError) as excinfo:
        await execute_write(
            "update_x",
            WriteTarget("company", 1),
            {"a": 1},
            apply=lambda body: calls.append(body),
            product="TEST",
        )
    assert excinfo.value.code is ErrorCode.FORBIDDEN
    assert calls == []


@pytest.mark.anyio
async def test_connector_switch_can_skip_confirmation(ctx_factory, elicit):
    fake = elicit("accept")
    ctx_factory(AccessPolicy(mode="allow_write"), require_write_confirmation=False)

    await execute_write(
        "update_x",
        WriteTarget("company", 1),
        {"a": 1},
        apply=lambda body: {"ok": True},
        product="TEST",
    )
    assert fake.messages == []


@pytest.mark.anyio
async def test_workspace_policy_overrides_connector_switch(ctx_factory, elicit):
    """`require_approval` musí přebít vypnutý konektorový přepínač.

    Jinak by to pole zůstalo dekorací: operátor workspace nemá jak potvrzení
    vynutit, když ho operátor konektoru vypnul.
    """
    fake = elicit("accept")
    ctx_factory(
        AccessPolicy(mode="allow_write", require_approval=True),
        require_write_confirmation=False,
    )

    await execute_write(
        "update_x",
        WriteTarget("company", 1),
        {"a": 1},
        apply=lambda body: {"ok": True},
        product="TEST",
    )
    assert len(fake.messages) == 1
    assert "politika" in fake.messages[0]


@pytest.mark.anyio
async def test_approval_required_mode_also_forces_confirmation(ctx_factory, elicit):
    fake = elicit("accept")
    ctx_factory(AccessPolicy(mode="approval_required"), require_write_confirmation=False)

    await execute_write(
        "update_x",
        WriteTarget("company", 1),
        {"a": 1},
        apply=lambda body: {"ok": True},
        product="TEST",
    )
    assert len(fake.messages) == 1


@pytest.mark.anyio
async def test_failed_before_fetch_does_not_block_write(ctx_factory, elicit):
    """Diff je nice-to-have; jeho selhání nesmí zablokovat zápis."""
    fake = elicit("accept")
    ctx_factory(AccessPolicy(mode="allow_write"))

    def boom(target, fields):
        raise RuntimeError("upstream detail nedostupný")

    result = await execute_write(
        "update_x",
        WriteTarget("company", 1),
        {"a": 1},
        apply=lambda body: {"ok": True},
        fetch_before=boom,
        product="TEST",
    )
    assert result == {"ok": True}
    assert "'—' → 1" in fake.messages[0]


@pytest.mark.anyio
async def test_budget_is_checked_before_confirmation(ctx_factory, elicit):
    """Strop musí zabrat dřív, než začneme otravovat člověka potvrzováním."""
    fake = elicit("accept")
    ctx_factory(AccessPolicy(mode="allow_write"))
    budget = WriteBudget(limit=0, window_s=300, _clock=lambda: 0.0)

    with pytest.raises(ConnectorError):
        await execute_write(
            "update_x",
            WriteTarget("company", 1),
            {"a": 1},
            apply=lambda body: {"ok": True},
            product="TEST",
            budget=budget,
        )
    assert fake.messages == []


@pytest.mark.anyio
async def test_result_is_sanitized(ctx_factory, elicit):
    elicit("accept")
    ctx_factory(AccessPolicy(mode="allow_write"))

    result = await execute_write(
        "update_x",
        WriteTarget("company", 1),
        {"a": 1},
        apply=lambda body: {"email": "a@b.cz"},
        sanitize=lambda data: {"email": "<EMAIL_x>"},
        product="TEST",
    )
    assert result == {"email": "<EMAIL_x>"}


@pytest.mark.anyio
async def test_create_has_no_before_fetch(ctx_factory, elicit):
    fake = elicit("accept")
    ctx_factory(AccessPolicy(mode="allow_write"))
    calls = []

    await execute_write(
        "create_x",
        WriteTarget("company", None),
        {"name": "Nová"},
        apply=lambda body: {"id": 1},
        fetch_before=lambda target, fields: calls.append(target) or {},
        product="TEST",
    )
    assert calls == []
    assert "nový záznam (company)" in fake.messages[0]


# -- typová detekce souhlasu ---------------------------------------------------
#
# Testy výše mají `_ACCEPTED` vypnuté, takže cvičí duck-type fallback.
# Tyto dva cvičí skutečnou typovou cestu — kvůli ní se vada opravovala
# (raynet porovnával `type(result).__name__`, což je křehké vůči přejmenování
# i vůči podtřídám).


@pytest.mark.anyio
async def test_real_accepted_elicitation_type_is_recognised(ctx_factory, monkeypatch):
    from fastmcp.server.elicitation import AcceptedElicitation

    import fastmcp.server.dependencies as deps

    class _Ctx:
        async def elicit(self, message, response_type=None):
            return AcceptedElicitation(data=None)

    monkeypatch.setattr(deps, "get_context", lambda: _Ctx())
    ctx_factory(AccessPolicy(mode="allow_write"))

    result = await execute_write(
        "update_x",
        WriteTarget("company", 1),
        {"a": 1},
        apply=lambda body: {"ok": True},
        product="TEST",
    )
    assert result == {"ok": True}


@pytest.mark.anyio
async def test_declined_elicitation_type_is_rejected(ctx_factory, monkeypatch):
    from mcp.server.elicitation import DeclinedElicitation

    import fastmcp.server.dependencies as deps

    class _Ctx:
        async def elicit(self, message, response_type=None):
            return DeclinedElicitation()

    monkeypatch.setattr(deps, "get_context", lambda: _Ctx())
    ctx_factory(AccessPolicy(mode="allow_write"))
    calls = []

    with pytest.raises(ConnectorError):
        await execute_write(
            "update_x",
            WriteTarget("company", 1),
            {"a": 1},
            apply=lambda body: calls.append(body),
            product="TEST",
        )
    assert calls == []


def test_accepted_type_is_resolved_at_import_time():
    """Rozchod s fastmcp má spadnout při buildu, ne při prvním zápisu."""
    import openmcp_sdk.write as write_mod

    assert write_mod._ACCEPTED, "fastmcp elicitation typy se nenaimportovaly"


# -- audit ---------------------------------------------------------------------


def test_audit_logs_field_names_never_values(ctx_factory, caplog):
    ctx_factory()
    with caplog.at_level("INFO"):
        audit_write("update_x", WriteTarget("company", 3), {"email": "tajne@x.cz"})
    logged = caplog.text
    assert "email" in logged
    assert "tajne@x.cz" not in logged
