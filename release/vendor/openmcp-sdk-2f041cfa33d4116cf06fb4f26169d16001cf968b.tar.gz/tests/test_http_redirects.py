"""Same-origin přesměrování v ``UpstreamClient.request``.

Výchozí chování zůstává fail-closed (přesměrování = chyba). Opt-in
``same_origin_redirects`` následuje Location jen na stejném originu —
klient s Basic auth nesmí credentials odnést jinam.
"""

from __future__ import annotations

import httpx
import pytest

from openmcp_sdk.envelope import ConnectorError, ErrorCode
from openmcp_sdk.http import UpstreamClient


def _client(handler: httpx.MockTransport) -> UpstreamClient:
    return UpstreamClient(
        base_url="https://api.example.com/v1",
        transport=handler,
        sleep=lambda _: None,
    )


def test_redirect_is_an_error_by_default() -> None:
    transport = httpx.MockTransport(
        lambda request: httpx.Response(
            301, headers={"Location": "https://api.example.com/v1/canonical"}
        )
    )
    with _client(transport) as client, pytest.raises(ConnectorError) as excinfo:
        client.request("GET", "/thing")
    assert excinfo.value.status == 301


def test_same_origin_redirect_is_followed_when_opted_in() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/canonical"):
            return httpx.Response(200, json={"ok": True})
        return httpx.Response(
            301, headers={"Location": "https://api.example.com/v1/canonical?x=1"}
        )

    with _client(httpx.MockTransport(handler)) as client:
        response = client.request("GET", "/thing", same_origin_redirects=1)
    assert response.status_code == 200
    # Query nese cílová URL — původní parametry se neduplikují.
    assert str(response.request.url).endswith("/canonical?x=1")


def test_relative_redirect_is_same_origin_by_definition() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/canonical"):
            return httpx.Response(200, json={"ok": True})
        return httpx.Response(302, headers={"Location": "/v1/canonical"})

    with _client(httpx.MockTransport(handler)) as client:
        response = client.request("GET", "/thing", same_origin_redirects=1)
    assert response.status_code == 200


def test_cross_origin_redirect_is_never_followed() -> None:
    transport = httpx.MockTransport(
        lambda request: httpx.Response(
            301, headers={"Location": "https://evil.example.net/v1/steal"}
        )
    )
    with _client(transport) as client, pytest.raises(ConnectorError) as excinfo:
        client.request("GET", "/thing", same_origin_redirects=3)
    assert excinfo.value.status == 301


def test_userinfo_cannot_disguise_a_foreign_host() -> None:
    """`https://api.example.com@evil.net/` míří na evil.net, ne na náš origin.

    Klasický trik na porovnávání URL podle prefixu: očekávaný host se schová
    do userinfo. Kontrola musí koukat na `hostname`, ne na `netloc`.
    """
    transport = httpx.MockTransport(
        lambda request: httpx.Response(
            301, headers={"Location": "https://api.example.com@evil.example.net/steal"}
        )
    )
    with _client(transport) as client, pytest.raises(ConnectorError) as excinfo:
        client.request("GET", "/thing", same_origin_redirects=3)
    assert excinfo.value.status == 301


def test_same_host_but_different_port_is_a_foreign_origin() -> None:
    transport = httpx.MockTransport(
        lambda request: httpx.Response(
            301, headers={"Location": "https://api.example.com:8443/v1/canonical"}
        )
    )
    with _client(transport) as client, pytest.raises(ConnectorError) as excinfo:
        client.request("GET", "/thing", same_origin_redirects=3)
    assert excinfo.value.status == 301


def test_redirect_budget_is_bounded() -> None:
    transport = httpx.MockTransport(
        lambda request: httpx.Response(
            301, headers={"Location": "https://api.example.com/v1/loop"}
        )
    )
    with _client(transport) as client, pytest.raises(ConnectorError) as excinfo:
        client.request("GET", "/thing", same_origin_redirects=2)
    assert excinfo.value.status == 301


def test_redirect_opt_in_is_get_only() -> None:
    transport = httpx.MockTransport(lambda request: httpx.Response(200))
    with _client(transport) as client, pytest.raises(ConnectorError) as excinfo:
        client.request("POST", "/thing", json={}, same_origin_redirects=1)
    assert excinfo.value.code is ErrorCode.INTERNAL
