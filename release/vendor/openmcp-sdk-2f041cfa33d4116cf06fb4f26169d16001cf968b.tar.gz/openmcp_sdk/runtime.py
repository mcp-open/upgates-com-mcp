"""Bootstrapping konektoru, volba režimu a fail-closed filtrování nástrojů."""

from __future__ import annotations

import asyncio
import logging
import os
from collections.abc import Mapping
from concurrent.futures import ThreadPoolExecutor
from typing import Any, NamedTuple
from urllib.parse import urlsplit

from packaging.version import Version

from openmcp_sdk._version import __version__
from openmcp_sdk.identity.gateway import GatewayIdentity
from openmcp_sdk.identity.oidc import OidcIdentity
from openmcp_sdk.identity.stdio import StdioIdentity
from openmcp_sdk.logging import setup as log_setup
from openmcp_sdk.manifest import Field, Manifest, load_manifest
from openmcp_sdk.pii import require_salt
from openmcp_sdk.secrets.base import resolve_operator_config
from openmcp_sdk.secrets.env import EnvProvider
from openmcp_sdk.secrets.vault import VaultProvider
from openmcp_sdk.transport.http import build_http_app
from openmcp_sdk.transport.stdio import run_stdio

logger = logging.getLogger(__name__)


def _needs_vault(manifest: Manifest) -> bool:
    """Je pro tento konektor potřeba číst per-user Vault blob?

    Konektory s delegovaným OAuth nedeklarují žádné ``credentials``, ale přesto
    ukládají per-user runtime secrets (refresh_token, cloud_id) do Vaultu.
    """

    return bool(
        manifest.credentials
        or manifest.user_config
        or manifest.auth.type == "oauth_delegated"
    )


def _check_sdk_version(manifest: Manifest) -> None:
    if Version(manifest.sdk_min_version) > Version(__version__):
        raise RuntimeError(
            f"connector {manifest.slug} vyžaduje openmcp_sdk>={manifest.sdk_min_version}, "
            f"běžící verze je {__version__}"
        )


def _require_env(environ: Mapping[str, str], mode: str, *keys: str) -> None:
    missing = [key for key in keys if not str(environ.get(key, "")).strip()]
    if missing:
        raise RuntimeError(
            f"OPENMCP_MODE={mode} vyžaduje proměnné prostředí: {', '.join(missing)}"
        )


def _strict_bool(value: Any, name: str) -> bool:
    try:
        return bool(Field(key=name.lower(), type="bool").parse(value))
    except ValueError as exc:
        raise RuntimeError(f"{name} má neplatnou boolean hodnotu") from exc


def _resolve_read_only(manifest: Manifest, environ: Mapping[str, str]) -> bool:
    field = next(
        (item for item in manifest.operator_config if item.key == "read_only"), None
    )
    if field is not None:
        value = resolve_operator_config(manifest, environ).get("read_only")
        return manifest.capabilities.default_read_only if value is None else bool(value)

    env_key = f"{manifest.slug}_READ_ONLY".upper()
    override = environ.get(env_key)
    if override is not None:
        return _strict_bool(override, env_key)
    return manifest.capabilities.default_read_only


def _enumerate_tools(mcp: Any) -> list[Any]:
    if hasattr(mcp, "list_tools_sync"):
        return list(mcp.list_tools_sync())

    async def fetch() -> Any:
        if hasattr(mcp, "get_tools"):
            return await mcp.get_tools()
        return await mcp.list_tools()

    def run() -> Any:
        return asyncio.run(fetch())

    try:
        asyncio.get_running_loop()
    except RuntimeError:
        tools = run()
    else:
        # run_connector je záměrně synchronní, ale vkládající kód ho může
        # volat, i když už jiná smyčka běží. Krátce žijící pomocné vlákno
        # se vyhne neplatnému vnořenému volání asyncio.run().
        with ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="openmcp-tools"
        ) as pool:
            tools = pool.submit(run).result()
    return list(tools.values()) if isinstance(tools, Mapping) else list(tools)


#: Od této verze manifestu jsou startovací kontroly tvrdé. Níže jen varují,
#: takže se konektory dají překlápět po jednom — manifest si nese vlastní
#: migrační přepínač v `sdk_min_version`.
_STRICT_CHECKS_FROM = Version("0.4.0")


def _strict_checks(manifest: Manifest) -> bool:
    """Má se nesoulad hlásit jako chyba, nebo zatím jen varovat?

    Porovnává se `base_version`, aby se `0.4.0rc1` — tedy manifest, který se
    k přísné verzi výslovně hlásí — nepovažoval za starší než `0.4.0`.
    """
    return (
        Version(manifest.sdk_min_version).base_version
        >= _STRICT_CHECKS_FROM.base_version
    )


def _validate_tool_wiring(manifest: Manifest, tools: list[Any]) -> list[str]:
    """Nesoulady mezi manifestem a skutečně zaregistrovanými nástroji."""
    problems: list[str] = []
    registered = {tool.name for tool in tools}

    declared = {
        item.name for item in (manifest.display.tools if manifest.display else [])
    }
    if declared:
        if missing := sorted(declared - registered):
            problems.append(
                f"v display.tools, ale nezaregistrované: {', '.join(missing)}"
            )
        if extra := sorted(registered - declared):
            problems.append(
                f"zaregistrované, ale chybí v display.tools: {', '.join(extra)}"
            )

    # Chybějící anotace znamená, že read-only filter nástroj fail-closed
    # odstraní — navenek to vypadá jako „ztratil se mi nástroj", ne jako chyba.
    unannotated = sorted(
        tool.name
        for tool in tools
        if getattr(getattr(tool, "annotations", None), "readOnlyHint", None) is None
    )
    if unannotated:
        problems.append(f"bez readOnlyHint anotace: {', '.join(unannotated)}")

    mutating = sorted(
        tool.name
        for tool in tools
        if getattr(getattr(tool, "annotations", None), "readOnlyHint", None) is False
    )
    if manifest.capabilities.supports_write and not mutating:
        problems.append("capabilities.supports_write=true, ale žádný mutující nástroj")
    if not manifest.capabilities.supports_write and mutating:
        problems.append(
            f"capabilities.supports_write=false, ale mutující nástroje: {', '.join(mutating)}"
        )
    return problems


def _apply_read_only_filter(
    manifest: Manifest, mcp: Any, environ: Mapping[str, str]
) -> None:
    if not _resolve_read_only(manifest, environ):
        return
    for tool in _enumerate_tools(mcp):
        annotations = getattr(tool, "annotations", None)
        # MCP anotace jsou jen doporučující. Pro bezpečnostní hranici je nutné
        # absenci nebo nejednoznačnou hodnotu považovat za mutující (fail closed).
        if getattr(annotations, "readOnlyHint", None) is not True:
            mcp.remove_tool(tool.name)


def _parse_allowed_origins(raw: str) -> list[str]:
    origins: list[str] = []
    for item in raw.split(","):
        value = item.strip().rstrip("/")
        if not value:
            continue
        parsed = urlsplit(value)
        if (
            parsed.scheme not in {"http", "https"}
            or not parsed.hostname
            or parsed.username is not None
            or parsed.password is not None
            or parsed.path not in {"", "/"}
            or parsed.query
            or parsed.fragment
        ):
            raise RuntimeError(f"neplatný CORS origin: {value!r}")
        origin = f"{parsed.scheme}://{parsed.netloc}"
        if origin not in origins:
            origins.append(origin)
    if not origins:
        raise RuntimeError("OPENMCP_ALLOWED_ORIGINS nesmí být prázdné")
    return origins


def _int_env(environ: Mapping[str, str], key: str, default: int, minimum: int) -> int:
    raw = environ.get(key, str(default))
    try:
        value = int(raw)
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"{key} musí být celé číslo") from exc
    if value < minimum:
        raise RuntimeError(f"{key} musí být >= {minimum}")
    return value


def _float_env(environ: Mapping[str, str], key: str, default: float) -> float:
    raw = environ.get(key, str(default))
    try:
        value = float(raw)
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"{key} musí být číslo") from exc
    if value < 0:
        raise RuntimeError(f"{key} nesmí být záporné")
    return value


class RunResult(NamedTuple):
    """Návratová hodnota ``serve=False``.

    NamedTuple záměrně — dosavadní rozbalení na 3-tuple funguje dál.
    """

    identity: Any
    credentials: Any
    transport: str


def run_connector(
    manifest_path: str,
    mcp: Any,
    *,
    argv_env: Mapping[str, str] | None = None,
    serve: bool = True,
    test_connection: Any = None,
    pii: Any = None,
    log_component: str | None = None,
    public_safe_test: Any = None,
) -> RunResult | None:
    argv_env = os.environ if argv_env is None else argv_env
    manifest = load_manifest(manifest_path)
    _check_sdk_version(manifest)

    # 1) Logging jako úplně první krok — jinak běží start bez redakce tajemství.
    #    Dosud si to musel zavolat konektor sám a dělal to jediný (upgates),
    #    navíc na úrovni importu `server.py`, což je špatná vrstva.
    # Prázdný string je v k8s i docker-compose běžný způsob, jak proměnnou
    # „nenastavit" — ber ho jako nenastavené, ne jako neplatný bool.
    log_setup_raw = (argv_env.get("OPENMCP_LOG_SETUP") or "").strip()
    if not log_setup_raw or _strict_bool(log_setup_raw, "OPENMCP_LOG_SETUP"):
        log_setup(
            level=argv_env.get("OPENMCP_LOG_LEVEL", "INFO"),
            component=log_component or manifest.slug,
        )

    # 2) PII salt fail-closed. Bez něj by tokeny nebyly stabilní napříč
    #    restarty a projevilo by se to až po prvním restartu podu.
    #
    #    Nesoulad manifest ↔ předaná politika je ošetřen stejně jako ostatní
    #    startovací kontroly: nemigrovaný konektor (`sdk_min_version < 0.4`)
    #    dostane varování, ne pád. Bez toho by bump SDK shodil start
    #    konektorům, které parametr `pii=` ještě neznají — a jejich testy by to
    #    nezachytily, protože `run_connector` nevolají.
    if manifest.runtime.pii_salt != (pii is not None):
        detail = (
            f"connector {manifest.slug}: runtime.pii_salt="
            f"{str(manifest.runtime.pii_salt).lower()}, ale pii politika "
            f"{'není' if pii is None else 'je'} předaná — salt bez politiky je "
            "zbytečný secret, politika bez saltu shodí start"
        )
        if _strict_checks(manifest):
            raise RuntimeError(detail)
        logger.warning(
            "%s (od sdk_min_version %s je to chyba)", detail, _STRICT_CHECKS_FROM
        )
    if manifest.runtime.pii_salt:
        require_salt(argv_env)

    has_test = test_connection is not None
    if manifest.capabilities.supports_test != has_test:
        expected = "true" if has_test else "false"
        raise RuntimeError(
            f"connector {manifest.slug}: capabilities.supports_test musí být {expected}, "
            "aby manifest a test_connection implementace zůstaly ve shodě"
        )

    mode = argv_env.get("OPENMCP_MODE", "local-stdio")
    internal_token: str | None = None

    if mode == "local-stdio":
        identity: Any = StdioIdentity()
        creds: Any = EnvProvider(manifest, argv_env)
        creds.resolve(identity.principal_from_headers({}))
        transport_kind = "stdio"
    elif mode == "hosted":
        _require_env(argv_env, mode, "OPENMCP_INTERNAL_TOKEN")
        if public_safe_test is not None:
            _require_env(argv_env, mode, "OPENMCP_PUBLIC_SAFE_TEST_TOKEN")
        internal_token = argv_env["OPENMCP_INTERNAL_TOKEN"]
        identity = GatewayIdentity(internal_token)
        if _needs_vault(manifest):
            _require_env(argv_env, mode, "VAULT_ADDR")
            creds = VaultProvider(
                manifest,
                addr=argv_env["VAULT_ADDR"],
                role=argv_env.get("VAULT_ROLE", manifest.slug),
                mount=argv_env.get("VAULT_MOUNT", "secret"),
                ttl=_float_env(argv_env, "VAULT_TTL", 60),
                timeout=_float_env(argv_env, "VAULT_TIMEOUT", 10),
                ca_cert=argv_env.get("VAULT_CACERT"),
                require_https=(
                    False
                    if "VAULT_REQUIRE_HTTPS" not in argv_env
                    else _strict_bool(
                        argv_env["VAULT_REQUIRE_HTTPS"], "VAULT_REQUIRE_HTTPS"
                    )
                ),
                environ=argv_env,
                max_cache_entries=_int_env(argv_env, "VAULT_CACHE_MAX", 1024, 1),
            )
        else:
            creds = EnvProvider(manifest, argv_env)
        transport_kind = "http"
    elif mode == "self-hosted":
        _require_env(argv_env, mode, "OIDC_ISSUER", "OIDC_JWKS_URI")
        if _needs_vault(manifest):
            _require_env(argv_env, mode, "VAULT_ADDR")
        if has_test:
            _require_env(argv_env, mode, "OPENMCP_INTERNAL_TOKEN")
            internal_token = argv_env["OPENMCP_INTERNAL_TOKEN"]
        identity = OidcIdentity(
            issuer=argv_env["OIDC_ISSUER"],
            jwks_uri=argv_env["OIDC_JWKS_URI"],
            audience=argv_env.get("OIDC_AUDIENCE", manifest.slug),
        )
        if _needs_vault(manifest):
            creds = VaultProvider(
                manifest,
                addr=argv_env["VAULT_ADDR"],
                role=argv_env.get("VAULT_ROLE", manifest.slug),
                mount=argv_env.get("VAULT_MOUNT", "secret"),
                ttl=_float_env(argv_env, "VAULT_TTL", 60),
                timeout=_float_env(argv_env, "VAULT_TIMEOUT", 10),
                ca_cert=argv_env.get("VAULT_CACERT"),
                require_https=(
                    False
                    if "VAULT_REQUIRE_HTTPS" not in argv_env
                    else _strict_bool(
                        argv_env["VAULT_REQUIRE_HTTPS"], "VAULT_REQUIRE_HTTPS"
                    )
                ),
                environ=argv_env,
                max_cache_entries=_int_env(argv_env, "VAULT_CACHE_MAX", 1024, 1),
            )
        else:
            creds = EnvProvider(manifest, argv_env)
        transport_kind = "http"
    else:
        raise RuntimeError(f"neznámý OPENMCP_MODE: {mode!r}")

    # 3) Kontrola manifest ↔ zaregistrované nástroje. Běží PŘED filtrem, jinak
    #    by se porovnávalo s už ořezanou množinou.
    problems = _validate_tool_wiring(manifest, _enumerate_tools(mcp))
    if problems:
        detail = f"connector {manifest.slug}: " + "; ".join(problems)
        if _strict_checks(manifest):
            raise RuntimeError(detail)
        logger.warning(
            "%s (od sdk_min_version %s je to chyba)", detail, _STRICT_CHECKS_FROM
        )

    _apply_read_only_filter(manifest, mcp, argv_env)

    if not serve:
        return RunResult(identity, creds, transport_kind)

    if transport_kind == "stdio":
        run_stdio(mcp, identity, creds, manifest)
        return None

    import uvicorn

    allowed_origins = _parse_allowed_origins(
        argv_env.get(
            "OPENMCP_ALLOWED_ORIGINS",
            "https://claude.ai,https://claude.com",
        )
    )
    auth = identity.verifier() if isinstance(identity, OidcIdentity) else None
    app = build_http_app(
        mcp,
        identity,
        creds,
        allowed_origins,
        auth=auth,
        test_connection=test_connection,
        manifest=manifest,
        test_auth_token=internal_token,
        operator_env=argv_env,
        credential_version_test=(mode == "hosted" and _needs_vault(manifest)),
        public_safe_test=public_safe_test if mode == "hosted" else None,
        public_safe_test_token=argv_env.get("OPENMCP_PUBLIC_SAFE_TEST_TOKEN"),
    )
    port = _int_env(argv_env, "PORT", 8000, 1)
    if port > 65535:
        raise RuntimeError("PORT musí být <= 65535")
    uvicorn.run(app, host="0.0.0.0", port=port)
    return None
