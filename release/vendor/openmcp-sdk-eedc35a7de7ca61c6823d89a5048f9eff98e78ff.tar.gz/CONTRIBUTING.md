# Contributing

Před odesláním změny spusťte:

```bash
python -m ruff check openmcp_sdk tests
python -m pytest -q
python -m build --wheel
```

Veřejné API musí být zdokumentováno v README a pokryto testem. Změny
manifestu, identity nebo transportu musí obsahovat migrační poznámku v
`CHANGELOG.md`. Do repozitáře nepatří secrets, soubory `.env` ani produkční
logy.
