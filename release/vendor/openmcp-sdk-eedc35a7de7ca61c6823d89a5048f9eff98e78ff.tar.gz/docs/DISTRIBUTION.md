# Distribuční adaptéry a release gate

SDK vytváří klientské adaptéry z jednoho `connector.yaml` a samostatného
`distribution.yaml`. Tyto soubory mají rozdílné role:

- `connector.yaml` je runtime a provisioning kontrakt;
- `distribution.yaml` určuje distribuční režim a přesné klientské povrchy;
- `release-gate.yaml` váže hotové artefakty na SBOM, content manifest, scan,
  podpis, provenance a dependency locky.

Oddělení je záměrné. `connector.yaml` čte také striktní Go provisioner, takže
release metadata nesmí měnit jeho schéma.

## Pravdivé cílové povrchy

| Režim | Výstup | Co výstup není |
|---|---|---|
| `local` | Claude Desktop MCPB 0.4 staging a následně `.mcpb` | remote OpenMCP connector |
| `remote` + OpenAI | operator handoff pro plugin submission a tool scan | lokální executable nebo importovatelný `.mcpb` |
| `remote` + Gemini | operator bundle Gemini CLI Extension s instalací z ověřeného Git tagu nebo rozbalené složky | přímý ZIP install, lokální MCP server nebo automaticky důvěryhodný server |

Remote URL musí být konkrétní OpenMCP workspace URL
`https://…/w/<workspace>/mcp`. Template URL pro OpenAI smí obsahovat právě
`{workspace}`; nejde o zákaznický secret. Review workspace musí obsahovat jen
release, jehož tool snapshot se odesílá ke kontrole.

Implementace sleduje aktuální upstream kontrakty:

- [MCPB manifest 0.4](https://github.com/modelcontextprotocol/mcpb/blob/main/schemas/mcpb-manifest-v0.4.schema.json)
- [OpenAI app/plugin submission](https://developers.openai.com/apps-sdk/deploy/submission)
- [OpenAI MCP OAuth metadata](https://developers.openai.com/apps-sdk/build/auth)
- [Gemini CLI Extension reference](https://github.com/google-gemini/gemini-cli/blob/main/docs/extensions/reference.md)
- [Gemini remote MCP OAuth](https://github.com/google-gemini/gemini-cli/blob/main/docs/tools/mcp-server.md)

Tyto externí kontrakty jsou proměnlivé. Jejich verze a klientský E2E se musí
znovu ověřit před každým veřejným vydáním.

## Remote příklad

```yaml
schema_version: 1
mode: remote
display_name: OpenMCP ARES
description: Čtení veřejných údajů přes vzdálený OpenMCP workspace.
license: Apache-2.0
publisher:
  name: OpenMCP
  homepage: https://openmcp.cz
  support: https://openmcp.cz/podpora
  documentation: https://openmcp.cz/dokumentace
  privacy_policy: https://openmcp.cz/soukromi
  repository: https://github.com/mcp-open/ares-mcp
remote:
  mcp_server_url: https://mcp.openmcp.cz/w/review-ares/mcp
  template_mcp_server_url: https://mcp.openmcp.cz/w/{workspace}/mcp
  oauth_scopes: [mcp]
  adapters: [openai, gemini]
```

```bash
adapter_staging="$(mktemp -d)"
openmcp-sdk render-adapters connector.yaml distribution.yaml \
  --output "$adapter_staging"
```

Renderer:

- odmítne ne-HTTPS URL, query, fragment, userinfo a jiný route tvar;
- vyžaduje přesně externí scope `mcp`; OpenMCP authorization server vydává
  vlastní rotující refresh token bez OIDC `offline_access`;
- vytváří oba remote adaptéry, nikdy MCPB;
- přidá explicitní read-only OpenAI anotace;
- do Gemini extension nepřidává `trust`;
- do Gemini extension nevkládá review workspace; instalace si přes secure
  extension setting vyžádá přesnou workspace URL;
- odmítne neprázdný output, aby se do release nepřimíchaly staré soubory;
- vytváří deterministický Gemini ZIP.

OpenAI `submission.json` je označený
`artifact_kind: operator_handoff, installable: false`. Nelze jej prezentovat
jako zákaznický download. Handoff zároveň explicitně vyžaduje konkrétní živý
review endpoint, externí demo credentials, ChatGPT web/mobile E2E, ověřenou
organizaci i doménu a živou privacy policy.

## Local MCPB příklad

```yaml
schema_version: 1
mode: local
display_name: OpenMCP Local Files — read-only
description: Čtení souborů jen ve složkách vybraných uživatelem.
license: Apache-2.0
publisher:
  name: OpenMCP
  homepage: https://openmcp.cz
  support: https://openmcp.cz/podpora
  documentation: https://openmcp.cz/dokumentace
  privacy_policy: https://openmcp.cz/soukromi
  repository: https://github.com/mcp-open/local-files-mcp
claude_mcpb:
  source_root: .
  include: [dist, package.json, package-lock.json]
  server:
    type: node
    entry_point: dist/index.js
    command: node
    args:
      - "${__dirname}/dist/index.js"
      - "${user_config.allowed_directories}"
  platforms: [darwin, win32]
  runtime_version: ">=20.0.0"
```

```bash
adapter_staging="$(mktemp -d)"
openmcp-sdk render-adapters connector.yaml distribution.yaml \
  --output "$adapter_staging"
openmcp-sdk pack-mcpb "$adapter_staging/claude-mcpb" \
  --mcpb-bin /opt/pinned-tools/mcpb \
  --output release/dist/openmcp-local-files-1.0.0.mcpb
```

Lokální renderer kopíruje pouze explicitní allowlist. Symlinky, VCS/cache
adresáře a soubory připomínající secrets odmítá. Credentials se mapují do
MCPB `user_config`; citlivé stringy dostanou `sensitive: true`. V1 vyžaduje
obě ověřované platformy `darwin` a `win32` a nepovoluje Linux claim.
V1 podporuje pouze hostitelský `node` runtime s explicitními `package.json`,
`package-lock.json`, předem sestaveným `dist/*.js|mjs|cjs` entry pointem a
přesnou `${__dirname}` argumentovou šablonou. `node_modules` se do balíku
nekopíruje; produkční build musí všechny runtime závislosti zahrnout do
jednoho kontrolovatelného `dist` výstupu. UV, binary, system Python a delegated
OAuth local balíky se fail-closed odmítají.

`connector.yaml` pro Local Files deklaruje `allowed_directories` jako
`user_config` s `type: directory`, `multiple: true`, `required: true` a bez
defaultu. Renderer ho vytvoří jako nativní MCPB picker. Directory/file hodnoty
se nikdy nevkládají do environmentu; server je dostane pouze jako poziční
argumenty za entry pointem. Seznam argumentů musí přesně a ve stejném pořadí
pokrýt všechna directory/file pole manifestu.

`pack-mcpb` vždy spustí upstream `mcpb validate` a teprve potom `mcpb pack`.
CI musí instalovat konkrétní připnutou verzi CLI.

## Provenance a gate

Pro každý artefakt je potřeba:

1. přesný dependency lock nebo commit pin;
2. přesný content manifest, který znovu ověří SHA-256 každé archive položky
   a build inputu;
3. Syft SPDX 2.3 SBOM rozbaleného payloadu a dependency locku;
4. Trivy JSON vulnerability, secret a misconfiguration report nad stejným
   scan rootem; report musí obsahovat deklarované dependency targety a hash
   content manifestu;
5. keyless Cosign bundle podpisu artefaktu;
6. SLSA provenance statement s artifact SHA-256, source commitem, builder
   identitou a hashy locků;
7. keyless Cosign bundle podpisu provenance;
8. volitelný časově omezený HIGH approval, který je také v provenance locks.

Pro MCPB se nejprve rozbalí přesný hotový artefakt do čistého scan rootu.
`package-lock.json` se přidá jako `build-inputs/package-lock.json`, protože
upstream MCPB jej z runtime balíku záměrně vynechává. Následně:

```bash
openmcp-sdk build-contents-manifest \
  --artifact release/dist/openmcp-local-files-1.0.0.mcpb \
  --artifact-name release/dist/openmcp-local-files-1.0.0.mcpb \
  --build-input package-lock.json=package-lock.json \
  --output release/evidence/claude.contents.json

trivy fs --scanners vuln,secret,misconfig --format json \
  --output release/evidence/claude.trivy.raw.json "$scan_root"
openmcp-sdk bind-trivy-report \
  --report release/evidence/claude.trivy.raw.json \
  --artifact-name release/dist/openmcp-local-files-1.0.0.mcpb \
  --contents-manifest release/evidence/claude.contents.json \
  --required-target build-inputs/package-lock.json \
  --output release/evidence/claude.trivy.json
```

```bash
openmcp-sdk build-provenance \
  --artifact release/dist/openmcp-ares-0.2.1-gemini.zip \
  --artifact-name release/dist/openmcp-ares-0.2.1-gemini.zip \
  --source-repository https://github.com/mcp-open/ares-mcp \
  --source-commit "$GITHUB_SHA" \
  --builder-identity \
    https://github.com/mcp-open/ares-mcp/.github/workflows/distribution-release.yml@refs/heads/main \
  --invocation-id "$GITHUB_SERVER_URL/$GITHUB_REPOSITORY/actions/runs/$GITHUB_RUN_ID" \
  --target gemini_remote \
  --lock .sdk-ref=.sdk-ref \
  --output release/evidence/gemini.provenance.json

cosign sign-blob --yes \
  --bundle release/evidence/gemini.sigstore.json \
  release/dist/openmcp-ares-0.2.1-gemini.zip
cosign sign-blob --yes \
  --bundle release/evidence/gemini.provenance.sigstore.json \
  release/evidence/gemini.provenance.json

openmcp-sdk verify-release release-gate.yaml \
  --root . \
  --source-commit "$GITHUB_SHA" \
  --cosign-bin /opt/pinned-tools/cosign \
  --output release/release-evidence.json
```

Gate selže, pokud:

- chybí artifact, lock, SBOM, content manifest, scan, podpis nebo provenance;
- některá evidence cesta vede přes symlink nebo mimo root;
- SBOM není úplný SPDX 2.3 dokument;
- content manifest neodpovídá každé položce přesného artefaktu a build inputu;
- Trivy report nepatří přesnému artefaktu, není svázaný s content manifestem
  nebo neobsahuje povinný dependency target;
- existuje `CRITICAL` nebo jakýkoli detekovaný secret;
- `HIGH` nemá právě jedno neexpirované schválení pro přesný artifact digest;
- HIGH approval není mezi provenance locky;
- keyless podpis nemá přesnou workflow identitu a OIDC issuer;
- provenance neobsahuje přesný artifact digest, source commit, builder a locky.

Neexistuje `--skip-signature`, `--allow-critical` ani jiný produkční bypass.
Výsledný `release-evidence.json` je teprve release kandidát; workflow ho má
také podepsat a uchovat spolu s artefakty. Veřejné CTA je povolené až po
clean-machine klientském E2E a zápisu kompatibility do platformového release
registru.

## Withdrawal

Stažení vydání je samostatná, auditovatelná operace. Nevytváří se přepsáním
nebo smazáním původního evidence. Z přesného podepsaného
`release-evidence.json` se vytvoří nový statement:

```bash
openmcp-sdk withdraw-release \
  --evidence release/release-evidence.json \
  --evidence-bundle release/release-evidence.sigstore.json \
  --release-reference openmcp-ares@0.2.1 \
  --reason "Bezpečnostní incident vyžaduje okamžité stažení vydání." \
  --actor security@example.com \
  --certificate-identity \
    https://github.com/mcp-open/ares-mcp/.github/workflows/distribution-release.yml@refs/heads/main \
  --oidc-issuer https://token.actions.githubusercontent.com \
  --incident-url https://openmcp.cz/incidents/INC-123 \
  --output release/release-withdrawal.json

cosign sign-blob --yes \
  --bundle release/release-withdrawal.sigstore.json \
  release/release-withdrawal.json
```

Statement obsahuje SHA-256 původního release evidence a přesné targety,
artifact paths a digesty. Původní evidence podpis se musí ověřit před
vytvořením withdrawal; withdrawal statement se musí podepsat schválenou
operator identitou a teprve následně aplikovat do release registra. Samotné
skrytí download CTA není withdrawal.
