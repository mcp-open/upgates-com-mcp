# Security policy

Nahlášení bezpečnostních problémů neposílejte do veřejných issue. Pošlete
je maintainerům projektu soukromým kanálem a uveďte verzi SDK, reprodukci a
dopad. Do reportu nevkládejte tokeny, API klíče ani osobní údaje.

Podporovány jsou poslední dvě minor verze SDK. Opravy bezpečnostních chyb se
publikují v changelogu a vyžadují aktualizaci konektorů.
